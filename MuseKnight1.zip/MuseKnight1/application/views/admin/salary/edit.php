<?php $this->load->view("admin/nav"); ?>
<?php $this->load->view("layouts/header"); ?>

<div class="container-fluid" style="padding-left: 20%; padding-right: 5%; padding-top: 3%;">
    <form method="POST" id="edit_form" action="<?= base_url('admin/salary/update/'.$salary['id']) ?>">
    <form method="POST" action="<?=base_url('admin/salary/submit_payment')?>" enctype="multipart/form-data" onsubmit="return validateForm();">
        <div style="align-items: center; display: flex; justify-content:space-between; margin-bottom:20px;">
            <div style="font-weight: 600; font-size:20px">Salary Detail</div>
            <div>
                <a href="<?= base_url('admin/salary/list') ?>" class="btn btn-secondary">Back</a>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </div>
        <div class="card shadow">
            <div style="padding: 30px;">
                <div class="row" style="text-align: start; margin-bottom:10px" >
                    <div class="col-6 form-group mb-2">
                        <label for="commission_rate" style="font-weight: 500;" class="mb-2">Commission Rate</label>
                        <input disabled type="text" id="commission_rate" class="form-control" name="commission_rate" value="<?= $salary['commission_rate'] * 100 ?>%">
                    </div>
                    <div class="col-6 form-group mb-2">
                        <label for="total_amount" style="font-weight: 500;" class="mb-2">Total Amount</label>
                        <input disabled type="text" id="total_amount" class="form-control" name="total_amount" value="<?= $salary['total_amount'] ?>">
                    </div>
                    <div class="col-6 form-group mb-2">
                        <label for="month" style="font-weight: 500;" class="mb-2">Salary Month</label>
                        <input disabled type="text" id="month" class="form-control" name="month" value="<?= $salary['month'] ?>">
                    </div>
                    <div class="col-6 form-group mb-2">
                        <label for="status" style="font-weight: 500;" class="mb-2">Status</label>
                        <select name="status" id="status" class="form form-select">
                            <option value="<?= $salary['status'] ?>" <?= ($salary['status'] == 0) ? 'selected' : '' ?>>Pending</option>
                            <option value="<?= $salary['status'] ?>" <?= ($salary['status'] == 1) ? 'selected' : '' ?>>Paid</option>
                        </select>
                    </div>
                    <label class="control-label">Select File</label>
                    <input id="receipt" name="receipt" type="file">
                </div>
                <div style="text-align: end;">
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </form>
</div>
<script>
$(document).ready(function() {
    $("#input-b5").fileinput({showCaption: false, dropZoneEnabled: false});
});
</script>