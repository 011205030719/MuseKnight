<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
    <style>
        .table-col{
            padding-top: 5px; 
            padding-bottom: 5px;
        }
        .table-row:hover{
            background-color: rgb(240, 240, 240);
        }
    </style>
</head>

<body>
    <div class="container" style="margin-top: 75px;">
        <div style="text-align:end; width:100%;">
            <a class="btn btn-primary" href="<?= base_url('CRUD/create') ?>" class="">Add New User</a>
        </div>
        <div class="card shadow mb-3" style="margin-top: 25px;">
            <div class="card-header text-center">Read ALL User</div>
            <div class="card-body">
                <div style="border: 2px solid lightgray; border-radius:15px; padding:10px;">
                    <table style="width:100%;">
                        <tr>
                            <th style="border-bottom: 1.5px solid lightgray; width: 10%;">ID</th>
                            <th style="border-bottom: 1.5px solid lightgray; width: 35%;">Name</th>
                            <th style="border-bottom: 1.5px solid lightgray; width: 20%;">Email</th>
                            <th style="border-bottom: 1.5px solid lightgray; width: 15%;">Created Date</th>
                            <th style="border-bottom: 1.5px solid lightgray; width: 20%;">Action</th>
                        </tr>
                        <?php foreach($users as $user){ ?>
                            <tr class="table-row">
                                <td class="table-col"><?= $user['id'] ?></td>
                                <td class="table-col"><?= $user['name'] ?></td>
                                <td class="table-col"><?= $user['email'] ?></td>
                                <td class="table-col"><?= $user['created_date'] ?></td>
                                <td class="table-col">
                                    <a href="<?= base_url('CRUD/edit/' . $user['id']) ?>" class="btn btn-success">Edit</a>
                                    <a href="<?= base_url('CRUD/delete/' . $user['id']) ?>" class="btn btn-danger">Delete</a>
                                </td>
                            </tr>
                        <?php } ?>
                    </table>    
                </div>
            </div>
        </div>
    </div>
</body>

</html>