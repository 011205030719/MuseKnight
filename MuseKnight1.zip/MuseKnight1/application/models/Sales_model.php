<?php
class Sales_model extends MY_Model {
    protected $table = 'sales'; // Adjust the table name accordingly

    public function __construct(){
        $this->set_table('sales');
        $this->load->model("student_model");
    }

    public function getStudentIdByUserId($user_id) {
        $this->db->select('student_id');
        $this->db->where('student_id', $user_id);
        $query = $this->db->get($this->table);

        if ($query->num_rows() > 0) {
            $row = $query->row();
            return $row->student_id;
        }

        return false; // Return false if not found
    }

    public function getPaymentSerialByUserId($user_id) {
        $where = array('student_id' => $user_id, 'is_deleted' => 0);
        $result = $this->get_where($where);
    
    
        // Check if the result is not empty and has a serial
        return !empty($result) && isset($result[0]['serial']) ? $result[0]['serial'] : 'No Payment Available';
    }

    public function store()
    {
        if ($this->input->post()) {
            // add student serial id
            $serials = $this->Sales_model->getIDKeyArray('serial');
        // Get the subject ID and teacher ID from the form data
        $subject_id = $this->input->post('subject_id');
        $sales_id = $this->input->post('id');
        $student_id = $this->input->post('student_id'); // Adjust accordingly

        // store data
        $sql = array(
            'serial' => $serial,
            'subject_fee' => $this->input->post('subject_fee'),
            'status' => $this->input->post('status'),
        );

        // Insert student data
        $this->Sales_model->insert($sql);

        // Get the student ID of the newly inserted student
        $id = $this->db->insert_id();

        // Now, insert into the student_subject table
        $student_subject_data = array(
            'subject_id' => $subject_id,
            'sales_id' => $id,
            'student_id' => $student_id,
            // Add other relevant data for the student_subject table
        );

        $this->db->insert('sales', $sales_data);

        redirect(base_url('admin/payment/list')); // calling route
    }
    }

    public function getSalesDetails($sales_id) {
        // Query the database to retrieve sales details based on the provided $sales_id
        $this->db->select('*');
        $this->db->from('sales');
        $this->db->where('id', $sales_id); // Assuming 'id' is the primary key for sales
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return array(); // Return an empty array if no data is found
        }
    }

    public function getSalesDataForStudent($student_id) {
        $this->db->select('sales.*, student.name as student_name');
        $this->db->from('sales');
        $this->db->join('student', 'sales.student_id = student.id', 'left');
        $this->db->where('sales.is_deleted', 0);
        $this->db->where('sales.student_id', $student_id); // Filter by student_id
        $query = $this->db->get();
        
        return $query->result_array();
    }



    
    public function getPaymentSerialByUserAndSubject($user_id, $subject_id) {
        $where = array(
            'student_id' => $user_id,
            'subject_id' => $subject_id,
            'is_deleted' => 0
        );
        $result = $this->get_where($where);
    
        // Check if the result is not empty and has a serial
        return !empty($result) && isset($result[0]['serial']) ? $result[0]['serial'] : 'No Payment Available';
    }
    
    public function getPaymentStatus($user_id, $subject_id) {
        $where = array(
            'student_id' => $user_id,
            'subject_id' => $subject_id,
            'is_deleted' => 0
        );
        $result = $this->get_where($where);
        if (!empty($result)) {
            $status = $result[0]['status'];

            // Assuming '1' represents approval status, modify this according to your actual status values
            if ($status == 1) {
                return 1;
            } else {
                return 0;
            }
        }

   
        return -1;
    }
    

    

    public function getPaymentStatusForStudent($student_id) {
        $this->db->select('subject_id, status');
        $this->db->where('student_id', $student_id);
        $this->db->where('is_deleted', 0);
        $query = $this->db->get('sales');

        $status_map = array();
        foreach ($query->result_array() as $row) {
            $status_map[$row['subject_id']] = $row['status'];
        }

        return $status_map;
    }

 

    public function getSerialNumbersForStudent($student_id) {
        $this->db->select('serial');
        $this->db->from('sales');
        $this->db->where('student_id', $student_id);
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            $result = $query->result_array();
            return array_column($result, 'serial');
        }

        return [];
    }


    public function getSubjectDetails($subject_id) {
        $this->db->where('id', $subject_id);
        $query = $this->db->get('subjects');

        if ($query->num_rows() > 0) {
            return $query->row_array();
        } else {
            return false;
        }
    }

 
    public function getPaymentDateForSubject($user_id, $subject_id) {
        $where = array(
            'student_id' => $user_id,
            'subject_id' => $subject_id,
            'is_deleted' => 0
        );

        $result = $this->get_where($where);

        if (!empty($result) && !empty($result[0]['payment_date'])) {
            return $result[0]['payment_date'];
        }

        return null;
    }

    public function getUnpaidSalesForStudent($student_id) {
        $this->db->select('subject_id, subject_fee');
        $this->db->where('student_id', $student_id);
        $this->db->where('status', 0); 
        $query = $this->db->get('sales');
        return $query->result_array();
    }

    public function getUnpaidSalesByStudentAndSubject($student_id, $subject_id) {
        $this->db->select('subject_fee');
        $this->db->where('student_id', $student_id);
        $this->db->where('subject_id', $subject_id);
        $this->db->where('status', 0); 
        $query = $this->db->get('sales');
        return $query->result_array();
    }

    public function getPaymentSerialBySubject($student_id, $subject_id) {
        $where = array(
            'student_id' => $student_id,
            'subject_id' => $subject_id,
            'is_deleted' => 0
        );
        $result = $this->get_where($where);

        return !empty($result) && isset($result[0]['serial']) ? $result[0]['serial'] : 'No Payment Available';
    }
    public function get_sales_with_status($studentId) {
        $this->db->select('*');
        $this->db->from('sales');
        $this->db->where('student_id', $studentId);
        $this->db->where_in('status', array(0, 2));
        $this->db->where('is_deleted', 0);
        $this->db->order_by('created_date', 'desc');

        $query = $this->db->get();
        return $query->result_array();
    }
}

    
?>