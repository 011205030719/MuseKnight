<?php

class CRUD extends CI_Controller {
    public $data;

    // Predefine function in controller
	public function __construct()
	{    
        parent::__construct();
        $this->load->model("User_model");
	}

    ////////////////////////////////////// Create::START \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
    public function create()
    {
		$this->load->view('main/create'); // return view
    }
    public function store()
    {
        if ($this->input->post()) {
            $sql = array(
                'name' => $this->input->post('name'),
                'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
                'email' => $this->input->post('email'),
            );

            $this->User_model->insert($sql);
            redirect(base_url('CRUD/index')); // calling route
        }
    }
    ////////////////////////////////////// Create::END \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ////////////////////////////////////// Read::START \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
	public function index()
	{
        // get more than one data
        $this->data['users'] = $this->User_model->get_where(array('is_deleted'=> 0));
        // link view
		$this->load->view('main/read', $this->data); // return view
	}
    ////////////////////////////////////// Read::END \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ////////////////////////////////////// Update::START \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
    public function edit($id){
        $this->data['user'] = $this->User_model->getOne(array(
            'id' => $id,
            'is_deleted'=> 0
        ));

        $this->load->view("main/update",$this->data); // return view
    }
    public function update($id){
        if ($this->input->post()) {
            $sql = array(
                'name' => $this->input->post('name'),
                'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
                'email' => $this->input->post('email'),
                'modified_date' => date('Y-m-d H:i:s'),
            );

            $this->User_model->update(array('id'=>$id), $sql);

            redirect(base_url('CRUD/index')); // calling route
            
        }
    }
    ////////////////////////////////////// Update::END \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

    ////////////////////////////////////// Delete::START \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
    public function delete($id){
        // $this->User_model->delete(array('id'=>$id)); //delete database data
        $this->User_model->update(array('id'=>$id), array('is_deleted'=>1)); // change deleted status
        redirect(base_url('CRUD/index')); // calling route
    }
    ////////////////////////////////////// Delete::END \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
}
