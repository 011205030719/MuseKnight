<?php $this->load->view("admin/nav"); ?>
<?php $this->load->view("layouts/header"); ?>


<div class="container-fluid" style="padding-left: 20%; padding-right: 5%; padding-top: 3%;">
    <div class="header" style=" width:100%;">
        <div style="padding:10px 0px; font-weight:600;">
            <span>Home / </span>
            <a href="<?= base_url($folder_name.'/subject/list') ?>" style="text-decoration:none; color:black;">Subject List</a>
            <span>/</span>
            <a href="<?= base_url($folder_name.'/subject/edit') ?>" style="text-decoration:none; color:black;">Subject Edit</a>
        </div>
    <div>
    <form method="POST" id="create_form" action="<?=base_url('admin/subject/update/'.$subject['id'])?>">
        <!-- <div style="text-align: end; margin-bottom:20px;">
            <a href="<?=base_url('admin/subject/list')?>" class="btn btn-secondary">Back</a>
            <button type="submit" class="btn btn-primary">Save Changes</button>
        </div> -->
        <div class="card shadow">
            <div style="padding: 30px;">
                <div class="row" style="text-align: start; margin-bottom:10px" >
                    <div class="col-6 form-group mb-2">
                        <label for="code" style="font-weight: 500;" class="mb-2">Code</label>
                        <input readonly type="text" id="code" class="form-control bg-light" name="code" value="<?= $subject['code'] ?>">
                    </div>
                    <div class="col-6 form-group mb-2">
                        <label for="title" style="font-weight: 500;" class="mb-2">Title</label>
                        <input readonly type="text" id="title" class="form-control bg-light" name="title" value="<?= $subject['title'] ?>">
                    </div>
                    <div class="col-6 form-group mb-2">
                        <label for="description" style="font-weight: 500;" class="mb-2">Description</label>
                        <input required type="text" id="description" class="form-control" name="description" value="<?= $subject['description'] ?>">
                    </div>
                    <div class="col-6 form-group mb-2">
                        <label for="fee" style="font-weight: 500;" class="mb-2">Tuition Fees</label>
                        <input readonly type="text" id="fee" class="form-control bg-light" name="fee" value="<?= $subject['fee'] ?>">
                    </div>
                </select>
                    </div>

                </div>
                <div style="text-align: end;">
                    <a href="<?=base_url('admin/subject/list')?>" class="btn btn-secondary">Back</a>
                    <button type="submit" class="btn btn-primary" style="margin:1%;">Save changes</button>
                </div>
            </div>
        </div>
    </form>
</div>