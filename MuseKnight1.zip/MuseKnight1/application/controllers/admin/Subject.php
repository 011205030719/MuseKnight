
<?php

class Subject extends MY_Controller {

    // Predefine function in controller
	public function __construct()
	{
        parent::__construct();
        // $this->data['invalid'] = 0;
        $this->data['folder_name'] = 'admin';
        $this->load->model("Subject_model");
        // $this->load->model("Teacher_model"); // Load Subject_model
        $this->auth_validate();
	}

    public function index(){
        $this->data['subjects'] = $this->Subject_model->get_where(array('is_deleted'=>0));
        // $this->data['teachers'] = $this->Teacher_model->get_where(array('is_deleted'=>0));
        $this->load->view("admin/subject/list",$this->data);
    }

    public function store(){
        if ($this->input->post()) {
            
            $code = ''; // initialize $code as an empty string
            if ($codeArray = $this->Subject_model->getIDKeyArray('code')) {
                $largestNumber = 0;
                foreach ($codeArray as $cd) {
                    $matches = [];
                    if (preg_match('/(\d+)/', $cd, $matches)) {
                        $number = intval($matches[0]);
                        if ($number > $largestNumber) {
                            $largestNumber = $number;
                        }
                    }
                }
                $code = 'SJ' . str_pad(($largestNumber + 1), 5, '0', STR_PAD_LEFT);
            }
            
            $sql = array(
                'code' => $code,
                'title' => $this->input->post('title'),
                'description' => $this->input->post('description'),
                'fee' => $this->input->post('fee'),
            );
            
            $this->Subject_model->insert($sql);
            
            redirect(base_url('admin/subject/list')); // calling route
        }
    }
    public function edit($id){
        $this->load->model("Teacher_model");
        $this->data['subject'] = $this->Subject_model->getOne(array('id'=>$id,'is_deleted'=>0));
        // $this->data['teacher'] = $this->Teacher_model->getOne(array('id'=>$id,'is_deleted'=>0));
        $this->load->view("admin/subject/edit",$this->data);
    }
    public function update($id){
        if ($this->input->post()) {
            $sql = array(
                'title' => $this->input->post('title'),
                'fee' => $this->input->post('fee'),
                'description' => $this->input->post('description'),
                'modified_date' => date('Y-m-d H:i:s'),
            );

            $this->Subject_model->update(array('id'=>$id), $sql);

            redirect(base_url('admin/subject/list')); // calling route
            
        }
    }
    public function delete($id){
        // $this->User_model->delete(array('id'=>$id)); //delete database data
        $this->Subject_model->update(array('id'=>$id), array('is_deleted'=>1));
        redirect(base_url('admin/subject/list')); // calling route
    }
}
