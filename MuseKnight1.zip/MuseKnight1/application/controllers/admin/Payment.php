<?php

class Payment extends MY_Controller {

    // Predefine function in controller
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('tuition');
        $this->data['folder_name'] = 'admin';
        $this->load->model("Sales_model");
        $this->load->model("StudentSubject_model");
        $this->load->model("Student_model");
        $this->load->model("Subject_model");
        $this->auth_validate();
    }
    

    public function index() {
        // Fetch all students
        $this->data['students'] = $this->Student_model->get_where(array('is_deleted' => 0));
    
        // Fetch all subjects
        $this->data['subjects'] = $this->Subject_model->get_where(array('is_deleted' => 0));
    
        // Fetch all student_subjects
        $this->data['student_subjects'] = $this->StudentSubject_model->get_where(array('is_deleted' => 0));
    
        // Additional data fetching if needed
        $this->data['sales'] = $this->Sales_model->get_where(array('is_deleted' => 0));
    
        // Load the view
        $this->load->view("admin/payment/list", $this->data);
    }    
    
    
    public function store() {
        if ($this->input->post()) {
            $student_id = $this->input->post('student_id');
            $subject_id = $this->input->post('subject_id');
            $student_subject_id = $this->input->post('student_subject_id');
    
            if ( empty($student_id) || empty($subject_id)) {
                redirect(base_url('admin/payment/invoice?error=foreign_key_empty'));
                return;
            }
    
            $subject_fee = $this->input->post('subject_fee');
    
            // Store data in student_subject table
            $student_subject_data = array(
                'student_id' => $student_id,
                'student_subject_id' => $student_subject_id,
                'subject_id' => $subject_id,
                'subject_fee' => $subject_fee,
            );
    
            $sales_id = $this->Sales_model->insert($sales_data);
    
            // Retrieve the subject_id from the student_subject record
            $student_id = $this->Sales_model->getOne(array('id' => $sales_id, 'is_deleted' => 0))['student_id'];
    
            // Store data in sales table
            $sales_data = array(
                'serial' => $serial,
                'student_id' => $student_id,
                'subject_id' => $subject_id, // Use the correct subject_id from the student_subject record
                'subject_fee' => $fee, // Use the correct subject_id from the student_subject record
                'month' => '', // Add handling as required
                'payment_method' => '', // Add handling as required
                'payment_date' => '', // Add handling as required
            );
    
            $this->Sales_model->insert($sales_data);
    
            redirect(base_url('admin/payment/list')); // Redirect to the lesson list page
        }
    }

    public function edit($id){
        $this->load->model("Sales_model");
        $this->data['sales'] = $this->Sales_model->getOne(array('id'=>$id,'is_deleted'=>0));
        // $this->data['teacher'] = $this->Teacher_model->getOne(array('id'=>$id,'is_deleted'=>0));
        $this->load->view("admin/payment/invoice",$this->data);
    }

    public function update($id){
        if ($this->input->post()) {
            $sql = array(
                'payment_method' => $this->input->post('payment_method'),
                'status' => $this->input->post('status'),
                'modified_date' => date('Y-m-d H:i:s'),
            );

            $this->Subject_model->update(array('id'=>$id), $sql);

            redirect(base_url('admin/payment/invoice')); // calling route
            
        }
    }
   
    
    public function gateway() {
        $sales_id = $this->input->get('sales_id');
        $this->data['sales'] = $this->Sales_model->getSalesDetails($sales_id);
        $unpaidSubjects = [];
    
        foreach ($this->data['sales'] as $sale) {
            if ($sale['status'] == 0) {
                $subject = $this->Subject_model->getOne(array('id' => $sale['subject_id'], 'is_deleted' => 0));
                if (!empty($subject) && isset($subject['name'])) {
                    $unpaidSubjects[] = $subject['name'] . ' (' . $sale['month'] . ')';
                }
            }
        }
    
        $this->data['unpaidSubjects'] = $unpaidSubjects;
        $this->load->view("admin/payment/gateway", $this->data);
    }

    public function invoice($id, $is_print = false) {
        $this->data['sale'] = $this->Sales_model->getOne(array('id' => $id, 'is_deleted' => 0));
        $this->data['subjects'] = json_decode($this->data['sale']['subject_detail']);
        $this->data['student'] = $this->Student_model->getOne(array('id' => $this->data['sale']['student_id'], 'is_deleted' => 0));
        $this->data['subject_title'] = $this->Subject_model->getIDKeyArray();
        $this->data['is_print'] = $is_print;
        $this->load->view("admin/payment/invoice", $this->data);
    }   
    
    
    
    
    public function updateStatus($id) {
        $this->data['sale'] = $this->Sales_model->update(array('id' => $id, 'is_deleted' => 0),array('status'=>1));
        
        $old_sales = $this->Sales_model->getOne(array('id' => $id, 'is_deleted' => 0));
        
        $nextMonth = new DateTime($old_sales['month']);
        $nextMonth->modify('+1 month');
        $insert_month = $nextMonth->format('F');
        
        $sales_serials = $this->Sales_model->getIDKeyArray('serial');
        $largestNumber = 0;
        foreach ($sales_serials as $str) {
            $matches = [];
            if (preg_match('/(\d+)/', $str, $matches)) {
                $number = intval($matches[0]);
                if ($number > $largestNumber) {
                    $largestNumber = $number;
                }
            }
        }
        $sale_serial = 'PM' . str_pad(($largestNumber + 1), 5, '0', STR_PAD_LEFT);

        $new_sales_sql = array(
            'serial' => $sale_serial,
            'student_id' => $old_sales['student_id'],
            'subject_detail' => $old_sales['subject_detail'],
            'total_amount' => $old_sales['total_amount'],
            'month' => $insert_month,
            'status' => 0,
            'is_deleted' => 0,
        );
        $this->Sales_model->insert($new_sales_sql);

        redirect(base_url('admin/payment/invoice/'.$id)); // calling route
    }
    
    public function calculateTotalTuition() {
        $user_id = $this->session->userdata('user_id');
        $sales = $this->Sales_model->getSalesForStudent($user_id);
        return calculateTotalTuition($sales);
    }
    
    
    
}
