<?php
class Payment extends MY_Controller {

    // Predefine function in controller
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('tuition');
        $this->data['folder_name'] = 'student';
        $this->load->model("Sales_model");
        $this->load->model("StudentSubject_model");
        $this->load->model("Student_model");
        $this->load->model("Subject_model");
        $this->auth_validate();
    }

    // public function index() {
    //     // Fetch all students
    //     $this->data['students'] = $this->Student_model->get_where(array('is_deleted' => 0));
    
    //     // Fetch all subjects
    //     $this->data['subjects'] = $this->Subject_model->get_where(array('is_deleted' => 0));
    
    //     // Fetch all student_subjects
    //     $this->data['student_subjects'] = $this->StudentSubject_model->get_where(array('is_deleted' => 0));
    
    //     // Additional data fetching if needed
    //     $this->data['sales'] = $this->Sales_model->get_where(array('is_deleted' => 0));
    
    //     // Load the view
    //     $this->load->view("student/payment/list", $this->data);
    // }
    
    public function index() {
        
        $user_id = $this->session->userdata('user_id');
        $this->data['student'] = $this->Student_model->get_where(array('id'=> $user_id, 'is_deleted' => 0));
        $this->data['subjects'] = $this->Subject_model->getIDKeyArray();
        
        $this->data['Incompleted_sale'] = $this->Sales_model->getOne(array('student_id'=>$user_id, 'month'=> date("F"), 'status'=>0, 'is_deleted' => 0));
        $this->data['Incompleted_sale_detail'] = $this->StudentSubject_model->get_where(array('student_id'=>$user_id, 'status'=>0, 'is_deleted' => 0));

        $this->data['sales'] = $this->Sales_model->get_where(array('student_id'=>$user_id, 'status !='=>0, 'is_deleted' => 0));
        $this->data['student_subjects'] = $this->StudentSubject_model->get_where(array('student_id'=>$user_id, 'status !='=> 1, 'is_deleted' => 0));
    
        // Load the view
        $this->load->view("student/payment/list", $this->data);
    }

    public function SubmitPayment() {

        $payment_method = $this->input->post('payment_method');
        $image = $this->input->post('image');

        $user_id = $this->session->userdata('user_id');
        
        // Upload Image
        $config['upload_path'] = FCPATH. 'assets/img/payment_invoice/';
        $config['allowed_types'] = 'jpg|jpeg|png';
        $config['max_size'] = 2048;
        $this->load->library('upload', $config);

        if ($this->upload->do_upload('image')) {
            $data = $this->upload->data();
            $image_name = $data['file_name'];

            $sql = array(
                'payment_method' => $payment_method,
                'payment_date' => date("Y-m-d H:i:s"),
                'status' => 2, //Pending
                'image' => $image_name,
                'modified_date' => date("Y-m-d H:i:s")
            );
        
            $this->Sales_model->update(array('student_id'=>$user_id, 'month'=> date("F"), 'status'=>0, 'is_deleted' => 0),$sql);

            redirect(base_url('student/dashboard'));
        } else {
            $error = array('error' => $this->upload->display_errors());
            var_dump($error);
            throw new Exception("Error!");
        }
    }
    public function gateway() {
        $user_id = $this->session->userdata('user_id');
        $this->data['sales'] = $this->Sales_model->getSalesForStudent($user_id);
        $unpaidSubjects = [];
    
        foreach ($this->data['sales'] as $sale) {
            if ($sale['status'] == 0) {
                $subject = $this->Subject_model->getOne(array('id' => $sale['subject_id'], 'is_deleted' => 0));
                if (!empty($subject) && isset($subject['name'])) {
                    $unpaidSubjects[] = $subject['name'] . ' (' . $sale['month'] . ')';
                }
            }
        }
    
        $this->data['unpaidSubjects'] = $unpaidSubjects;
        $this->load->view("student/payment/gateway", $this->data);
    }
    
    public function calculateTotalTuition() {
        $user_id = $this->session->userdata('user_id');
        $sales = $this->Sales_model->getSalesForStudent($user_id);
        return calculateTotalTuition($sales);
    }
}
