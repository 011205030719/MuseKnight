<?php
class StudentSubject_model extends MY_Model {
    public function __construct(){
        $this->set_table('student_subject');
    }
    public function getStudentsByTeacherId($teacher_id) {
        $this->db->select('student_id');
        $this->db->from('student_subject');
        $this->db->where('teacher_id', $teacher_id);
        $query = $this->db->get();
        
        $student_ids = array();
        foreach ($query->result_array() as $row) {
            $student_ids[] = $row['student_id'];
        }
        
        return $student_ids;
    }

        public function getStudentSubjectsByTeacher($teacherId) {
            // Define the database query to retrieve student_subject data by teacher
            $query = $this->db->get_where('student_subject', array('teacher_id' => $teacherId, 'is_deleted' => 0));
            
            return $query->result_array(); // You can adjust this to your needs
        }
    
    
    // public function getStudentsByTeacherAndSubject($teacher_id, $subject_id) {
    //     $this->db->select('student_subject.student_id'); // Specify the table for student_id
    //     $this->db->from('student_subject');
    //     $this->db->join('teacher_subject', 'student_subject.teacher_id = teacher_subject.id');
    //     $this->db->where('teacher_subject.teacher_id', $teacher_id);
    //     $this->db->where('teacher_subject.subject_id', $subject_id);
    //     $query = $this->db->get();
    
    //     $student_ids = array();
    //     foreach ($query->result_array() as $row) {
    //         $student_ids[] = $row['student_id'];
    //     }
    
    //     return $student_ids;
    // }

    public function getStudentIds($teacher_id, $subject_id) {
        $this->db->select('student_id');
        $this->db->where('teacher_id', $teacher_id);
        $this->db->where('subject_id', $subject_id);
        $query = $this->db->get('student_subject');

        // Check if the query was successful
        if ($query) {
            // Extract student IDs from the result
            $student_ids = array();
            foreach ($query->result() as $row) {
                $student_ids[] = $row->student_id;
            }
            return $student_ids;
        } else {
            return array();
        }
    }
    public function getStudentsByTeacherAndSubject($teacher_id, $subject_id) {
        $this->db->select('student_id, grade_level, fee');
        $this->db->where('teacher_id', $teacher_id);
        $this->db->where('subject_id', $subject_id);
        $this->db->where('is_deleted', 0);
        $query = $this->db->get('student_subject');

        return $query->result();
    }

    // StudentSubject_model.php

public function getStudentsByTeacher($teacher_id) {
    $this->db->select('student_id, grade_level, fee');
    $this->db->where('teacher_id', $teacher_id);
    $this->db->where('is_deleted', 0);
    $query = $this->db->get('student_subject');

    return $query->result();
}
public function getStudentsBySubjectAndTeacher($subject_id, $teacher_id) {
    // Define the database query to retrieve student_subject data by subject and teacher
    $query = $this->db->get_where('student_subject', array('subject_id' => $subject_id, 'teacher_id' => $teacher_id, 'is_deleted' => 0));

    $student_ids = array();
    foreach ($query->result_array() as $row) {
        $student_ids[] = $row['student_id'];
    }

    return $student_ids;
}
public function getStudentBySubject($subject_id) {
    // Define the database query to retrieve student_subject data by subject and teacher
    $query = $this->db->get_where('student_subject', array('subject_id' => $subject_id,  'is_deleted' => 0));

    $student_ids = array();
    foreach ($query->result_array() as $row) {
        $student_ids[] = $row['student_id'];
    }

    return $student_ids;
}
    // Count the number of active students for a given subject
    public function countWhere($where)
    {
        $this->db->where($where);
        $this->db->from('student_subject');
        return $this->db->count_all_results();
    }   
    public function get_subject_student_counts() {
        $this->db->select('s.subject_id, sub.title as subject_title, COUNT(s.student_id) as total_students');
        $this->db->from('student_subject s');
        $this->db->join('subject sub', 's.subject_id = sub.id', 'left');
        $this->db->where('s.is_deleted', 0);
        $this->db->group_by('s.subject_id, sub.title');
    
        return $this->db->get()->result_array();
    }
    public function get_subject_fees_counts() {
        $this->db->select('ss.subject_id, s.title as subject_title, SUM(ss.fee) as total_fee');
        $this->db->from('student_subject ss');
        $this->db->join('subject s', 'ss.subject_id = s.id', 'left');
        $this->db->where('ss.is_deleted', 0);
        $this->db->group_by('ss.subject_id, s.title');
    
        return $this->db->get()->result_array();
    }
    
    
    public function hasRecordedTimeRange($teacherId, $day)
    {
        // Query to check if there is a recorded time range for the teacher on the given day
        $this->db->where('teacher_id', $teacherId);
        $this->db->where('day', $day);
        $this->db->where('is_deleted', 0);
    
        $query = $this->db->get('student_subject');
    
        return $query->num_rows() > 0;
    }
    
    public function getOccupiedTimeRanges($teacherId, $day)
    {
        // Query to get occupied time ranges for the teacher on the given day
        $this->db->select('time_range');
        $this->db->where('teacher_id', $teacherId);
        $this->db->where('day', $day);
        $this->db->where('is_deleted', 0);
    
        $query = $this->db->get('student_subject');
    
        $occupiedTimeRanges = array();
        foreach ($query->result() as $row) {
            $occupiedTimeRanges[] = $row->time_range;
        }
    
        return $occupiedTimeRanges;
    }

    public function hasRecordedTimeRangeForDay($studentId, $day)
{
    $this->db->where('student_id', $studentId);
    $this->db->where('day', $day);
    $this->db->where('is_deleted', 0);

    $query = $this->db->get('student_subject');

    return $query->num_rows() > 0;
}

public function getOccupiedTimeRangesForDay($studentId, $day)
{
    $this->db->select('time_range');
    $this->db->where('student_id', $studentId);
    $this->db->where('day', $day);
    $this->db->where('is_deleted', 0);

    $query = $this->db->get('student_subject');

    $occupiedTimeRanges = array();
    foreach ($query->result() as $row) {
        $occupiedTimeRanges[] = $row->time_range;
    }

    return $occupiedTimeRanges;
}

    
    public function updateSubject($where, $data)
{
    $this->db->where($where);
    $this->db->update('student_subject', $data);
}



}
