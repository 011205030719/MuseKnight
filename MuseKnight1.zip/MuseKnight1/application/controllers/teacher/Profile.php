    <?php

    class Profile extends MY_Controller {

        // Predefine function in controller
        public function __construct()
        {
            parent::__construct();
            // $this->data['invalid'] = 0;
            $this->data['folder_name'] = 'teacher';
            $this->load->model("Teacher_model");
            $this->load->model("Subject_model");
            $this->auth_validate();
        }

        public function index(){
            $this->data['teachers'] = $this->Teacher_model->get_where(array('is_deleted'=>0));
            $this->data['subjects'] = $this->Subject_model->get_where(array('is_deleted'=>0));
            $this->data['id'] = null; // Ensure $id is defined (it might not be relevant for the index view)
            $this->load->view("teacher/profile/list", $this->data);
        }
        

        

        public function store() {
            if ($this->input->post()) {
                
                // add teacher serial id
                $serials = $this->Teacher_model->getIDKeyArray('serial');
                if ($serials) {
                    $largestNumber = 0;
                    foreach ($serials as $str) {
                        $matches = [];
                        if (preg_match('/(\d+)/', $str, $matches)) {
                            $number = intval($matches[0]);
                            if ($number > $largestNumber) {
                                $largestNumber = $number;
                            }
                        }
                    }
                    $serial = 'TC' . str_pad(($largestNumber + 1), 3, '0', STR_PAD_LEFT);
                }
        
                // Get the selected subject_id from the form data
                $selectedSubjects = $this->input->post('subject_id');
        
                // store data in teacher table
                $teacherData = array(
                    'serial' => $serial,
                    'name' => $this->input->post('name'),
                    'password' => $this->input->post('password'),
                    'mobile' => $this->input->post('mobile'),
                    'gender_status' => $this->input->post('gender_status'),
                    'status' => $this->input->post('status'),
                    'commission_rate' => $this->input->post('commission_rate'),
                );
        
                $teacherId = $this->Teacher_model->insert($teacherData);
        
                // Handle multiple subjects
                foreach ($selectedSubjects as $subjectId) {
                    $this->Teacher_model->insertTeacherSubject($teacherId, $subjectId);
                }
        
                redirect(base_url('teacher/profile/list'));
            }
        }

        public function updateProfileImage()
        {
            $image = $this->input->post('image');
            $user_id = $this->session->userdata('user_id');
        
            // Upload Image
            $config['upload_path'] = FCPATH . 'assets/img/profiles/';
            $config['allowed_types'] = 'jpg|jpeg|png';
            $config['max_size'] = 2048;
            $this->load->library('upload', $config);
        
            if ($this->upload->do_upload('image')) {
                $data = $this->upload->data();
                $image_name = $data['file_name'];
        
                $sql = array(
                    'image' => $image_name,
                );
        
                $this->Teacher_model->update(array('id' => $user_id, 'is_deleted' => 0), $sql);
        
                // Redirect to the 'student/profile/list' page
                redirect(base_url('teacher/profile/index'));
            } else {
                $error = array('error' => $this->upload->display_errors());
                var_dump($error);
                throw new Exception("Error!");
            }
        }
        
        public function viewPDF($teacherId) {
            // Get the teacher information including the PDF filename
            $teacher = $this->Teacher_model->getTeacherById($teacherId);
        
            // Check if the teacher and the PDF file exist
            if ($teacher && $teacher['cert']) {
                $pdfPath = FCPATH . 'assets/document/' . $teacher['cert'];
        
                // Check if the file exists
                if (file_exists($pdfPath)) {
                    header('Content-Type: application/pdf');
                    header('Content-Disposition: inline; filename="' . $teacher['cert'] . '"');
                    header('Content-Transfer-Encoding: binary');
                    header('Accept-Ranges: bytes');
                    readfile($pdfPath);
                } else {
                    // PDF file not found
                    show_404();
                }
            } else {
                // Teacher or PDF information not found
                show_404();
            }
        }
        
        
        public function edit($id){
            $this->data['teacher'] = $this->Teacher_model->getOne(array('id'=>$id,'is_deleted'=>0));
            $this->data['subjects'] = $this->Subject_model->get_where(array('is_deleted' => 0));
            $this->data['id'] = $id; // Add this line to pass $id to the view
            $this->load->view("teacher/profile/edit",$this->data);
        }
        
        // public function update_password() {
        //     $id = $this->session->userdata('teacher_id'); // Change this line based on where you store the teacher's ID

        //     if (!$id) {
        //         show_404(); // Or handle the absence of ID in a different way
        //         return;
        //     }
        //     if ($this->input->is_ajax_request()) {
        //         $new_password = $this->input->post('new_password');
        
        //         // Check password format for the new password
        //         if (!$this->isValidPasswordFormat($new_password)) {
        //             echo json_encode(array('status' => 'error', 'message' => 'Incorrect new password format.'));
        //             return;
        //         }
        
        //         // Update the password in the database
        //         $hashed_new_password = password_hash($new_password, PASSWORD_BCRYPT);
        //         $sql = array(
        //             'password' => $hashed_new_password,
        //             'modified_date' => date('Y-m-d H:i:s'),
        //         );
        
        //         $this->Teacher_model->update(array('id' => $id), $sql);
        
        //         // Send a success response
        //         echo json_encode(array('status' => 'success', 'message' => 'Password updated successfully.'));
        //     } else {
        //         show_404();
        //     }
        // }
        
        
        
        // private function isValidPasswordFormat($password) {
        //     // Implement your password format validation logic here
        //     // For example, check length, presence of letters and numbers, etc.
        //     return strlen($password) >= 8 && preg_match('/[a-zA-Z]/', $password) && preg_match('/\d/', $password);
        // }
        
        public function update($id) {
            if ($this->input->post()) {
                $sql = array(
                    'password' => $this->input->post('new_password'),
                    'modified_date' => date('Y-m-d H:i:s'),
                );
                // Update the teacher's data
                $this->Teacher_model->update(array('id' => $id), $sql);
        
                // Set a success message
                $this->session->set_flashdata('success_message', 'Password updated successfully.');
        
                redirect(base_url('teacher/profile/index')); // calling route
            }
        }
        
        
        
        
        
        public function delete($id){
            // $this->User_model->delete(array('id'=>$id)); //delete database data
            $this->Teacher_model->update(array('id'=>$id), array('is_deleted'=>1));
            redirect(base_url('teacher/profile/list')); // calling route
        }


        
        
    }













