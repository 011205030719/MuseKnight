<?php

class Annoucement extends MY_Controller
{

    // Predefine function in controller
    public function __construct()
    {
        parent::__construct();
        $this->data['folder_name'] = 'admin';
        $this->load->model("Admin_model");
        $this->load->model("Teacher_model");
        $this->load->model("StudentSubject_model");
        $this->load->model("Student_model");
        $this->load->model("Subject_model");
        $this->load->model("Annoucement_model");
        $this->load->model("TeacherSubject_model");
        $this->auth_validate();
        // Fetch and set teacher names in $this->data['subject titial']
        $subjects = $this->Subject_model->get_all(); // Replace with your actual method to get teachers
        $this->data['subject'] = [];
        foreach ($subjects as $subject) {
            $this->data['subject']= $subject['title'];
        }
        // Send email to selected students
        $this->load->library('PHPMailer_Lib');
    }
    public function subjectList()
    {
        $all_subjects = $this->Subject_model->get_all();
    
        foreach ($all_subjects as &$subject) {
            $subject_id = $subject['id'];
    
            // Calculate total active teachers for the subject
            $totalActiveTeachers = $this->TeacherSubject_model->countWhere(['subject_id' => $subject_id, 'status' => 0, 'is_deleted' => 0]);
            $subject['totalActiveTeachers'] = $totalActiveTeachers;
    
            // Calculate total active students for the subject
            $totalActiveStudents = $this->StudentSubject_model->countWhere(['subject_id' => $subject_id, 'status' => 0, 'is_deleted' => 0]);
            $subject['totalActiveStudents'] = $totalActiveStudents;
        }
    
        $this->data['subjects'] = $all_subjects;
    
        $this->load->view("admin/annoucement/subject_list", $this->data);
    }
    
    
    

    
    
        

    public function index($id)
    {
        $admin_id = $this->session->userdata('user_id');
         // Subject
         $this->data['subject'] = $this->Subject_model->getOne(array('id' => $id, 'is_deleted' => 0));
         $student_ids = $this->StudentSubject_model->getIDKeyArray('student_id',array('subject_id' => $id, 'status'=>0, 'is_deleted' => 0));
         $this->data['students'] = $this->Student_model->get_wherein(array('is_deleted'=>0) , 'id', $student_ids);
         
        $this->data['teachers'] = $this->Teacher_model->get_where(array('is_deleted' => 0));
        $this->data['subjects'] = $this->Subject_model->get_where(array('is_deleted' => 0));
        $this->data['student_subjects'] = $this->StudentSubject_model->get_where(array('is_deleted' => 0));
        $this->data['teacher_subjects'] = $this->TeacherSubject_model->get_where(array('is_deleted' => 0));
        $this->data['students'] = $this->Student_model->get_where(array('is_deleted' => 0));

        // Annoucment
        $all_announcements = $this->Annoucement_model->get_where(array('subject_id' => $id, 'is_deleted' => 0));

        foreach ($all_announcements as $announcementKey => $announcement) {
            $sender_id = $announcement['sender_id'];
            $sender_type = $announcement['sender_type'];
            
            // Fetch the name based on sender_type and sender_id
            if ($sender_type == 'admin') {
                // For admin sender, you can directly use 'Admin' as the sender name
                $all_announcements[$announcementKey]['senderName'] = 'Admin';
            } elseif ($sender_type == 'teacher') {
                $sender_info = $this->Teacher_model->getOne(array('id' => $sender_id, 'is_deleted' => 0));
                if ($sender_info) {
                    // Assign the sender's name to the announcement
                    $all_announcements[$announcementKey]['senderName'] = $sender_info['name'];
                } else {
                    // Handle the case when the sender's info is not found
                    $all_announcements[$announcementKey]['senderName'] = 'Unknown name';
                }
            } else {
                // Handle additional sender types if needed
                // $sender_info = $this->AdditionalSenderModel->getOne(array('id' => $sender_id, 'is_deleted' => 0));
                // $all_announcements[$announcementKey]['senderName'] = $sender_info ? $sender_info['name'] : 'Unknown name';
            }
        }
        
        $this->data['annoucements'] = $all_announcements; // Assign the modified array back
        

        $this->load->view("admin/annoucement/list", $this->data);
        
    }

    // public function subjectFile(){
    //     $this->load->view("admin/annoucement/subjectFile",$this->data);
    // }


    public function add_annoucement_view($subject_id, $teacher_id = null)
    {
        $admin_id = $this->session->userdata('user_id');
    
        // Fetch subjects associated with the teacher from the teacher_subject table
        $teacher_subjects = $this->TeacherSubject_model->get_where(array('teacher_id' => $teacher_id, 'is_deleted' => 0));
    
        // Extract subject IDs from the teacher_subjects
        $subject_ids = array();
        foreach ($teacher_subjects as $teacher_subject) {
            $subject_ids[] = $teacher_subject['subject_id'];
        }
    
        // Load the Subject_model to fetch subjects data
        $this->load->model("Subject_model");
        $this->data['subject'] = $this->Subject_model->getOne(array('id' => $subject_id, 'is_deleted' => 0));
    
        // Load the StudentSubject_model to fetch students associated with the teacher
        $this->load->model("StudentSubject_model");
        $student_ids = $this->StudentSubject_model->getStudentsByTeacherId($teacher_id);
    
        // Load the Student_model to fetch student data
        $this->load->model("Student_model");
        $this->data['students'] = $this->Student_model->get_students_by_ids($student_ids);
    
        $this->data['subject_id'] = $subject_id;
        $this->data['teacher_id'] = $teacher_id;
        $this->data['sender_type'] = 'teacher';
        $this->data['receiver_type'] = 'student';
    
        // Load the Annoucement_model to fetch announcements data
        $this->data['announcements'] = $this->Annoucement_model->get_where(array('is_deleted' => 0));
    
        $this->load->view("admin/annoucement/add_annoucement", $this->data);
    }


    // public function addAnnoucement()
    // {
    //     // Insert the announcement into the database
    //     $data = array(
    //         'sender_id' => $this->input->post('sender_id'),
    //         'sender_type' => $this->input->post('sender_type'),
    //         'subject_id' => $this->input->post('subject_id'),
    //         'title' => $this->input->post('title'),
    //         'description' => $this->input->post('description')
    //     );

    //     // Insert the data into the announcement model (adjust the model name)
    //     $this->Annoucement_model->insert($data);

    //     // Redirect to the list of announcements or any other page
    //     redirect('teacher/annoucement/list');
    // }

    public function addAnnoucement()
{
    // Get form data
    $subject_id = $this->input->post('subject_id');
    $title = $this->input->post('title');
    $description = $this->input->post('description');
    $select_all = $this->input->post('select_all');
    $selected_students = $this->input->post('students');
    $selected_teachers = $this->input->post('teachers');

     // Get the selected students (as an array)
     $select_all = $this->input->post('select_all');
     $subject_title = $this->Subject_model->getSubjectTitleById($subject_id);


    // Get student IDs based on the selection
    if ($select_all === 'on') {
        $student_ids = $this->StudentSubject_model->getStudentBySubject($subject_id);
        $teacher_ids = $this->TeacherSubject_model->getTeacherBySubject($subject_id);
    } else {
        $student_ids = !empty($selected_students) ? $selected_students : [];
        $teacher_ids = !empty($selected_teachers) ? $selected_teachers : [];
    }

    // Send emails to selected students
    if (!empty($student_ids)) {
        $studentMail  = $this->phpmailer_lib->load();
         // SMTP Configuration
         $studentMail ->isSMTP();
         $studentMail ->Host = 'smtp.gmail.com';
         $studentMail ->SMTPAuth = true;
         $studentMail ->Username = 'muijing0112@gmail.com';
         $studentMail ->Password = 'hrqy kpzo jptn yaor';
         $studentMail ->SMTPSecure = 'tls';
         $studentMail ->Port = 587;
 
         // Email Configuration
         $studentMail->setFrom('muijing0112@gmail.com', 'MuseKnight');
        // Loop through selected students and send an email to each student
        foreach ($student_ids as $student_id) {
            
            $student_email = $this->Student_model->getStudentEmailById($student_id);

            // Compose and send the email to student
            $studentMail->addAddress($student_email); // Recipient email
            $studentMail->Subject = 'MuseKnight - New Announcement Available!';
            $studentMail->Body = '
                <html>
                <head>
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            background-color: #f4f4f4;
                            color: #333;
                            margin: 0;
                            padding: 20px;
                        }

                        .container {
                            max-width: 600px;
                            margin: 0 auto;
                            background-color: #fff;
                            padding: 20px;
                            border-radius: 8px;
                            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                        }

                        h1 {
                            color: #333;
                            text-align: center;
                        }

                        p {
                            margin-bottom: 15px;
                        }

                        a {
                            color: #007BFF;
                            text-decoration: none;
                            font-weight: bold;
                        }

                        a:hover {
                            text-decoration: underline;
                        }

                        .footer {
                            margin-top: 20px;
                            padding-top: 10px;
                            border-top: 1px solid #ccc;
                            text-align: center;
                        }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <h1 style="color: #007BFF; text-align: center;">MuseKnight - New Announcement Available!</h1>
                        <p>
                            Dear Student,
                            <br>
                            We are pleased to inform you that a new announcement has been posted on our website.
                        </p>

                        <p>
                            <strong>Subject:</strong> ' . $subject_title  . '
                            <br>
                            <strong>Announcement Title:</strong> ' . $title  . '
                            <br>
                            <strong>Announcement Content:</strong> ' . $description . '
                        </p>

                        <p>
                            To view the announcement, please visit the website at the following link:
                            <br>
                            <a href="http://museknight1.local/" target="_blank">http://museknight1.local/</a>
                        </p>

                        <p>
                            Thank you for staying updated with our latest information.
                        </p>

                        <div class="footer">
                            Sincerely,
                            <br>
                            [Admin]
                            <br>
                            [MuseKnight]
                        </div>
                    </div>
                </body>
                </html>
            ';
            $studentMail->isHTML(true);


            if (!$studentMail->send()) {
                log_message('error', 'Email could not be sent to student ' . $student_id . ': ' . $studentMail->ErrorInfo);
            }
            // Clear recipients for the next iteration
            $studentMail->clearAddresses();
        }
    }
    //////////////////////// Send emails to selected teachers\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
    if (!empty($teacher_ids)) {
        $teacherMail  = $this->phpmailer_lib->load();
         // SMTP Configuration
         $teacherMail ->isSMTP();
         $teacherMail ->Host = 'smtp.gmail.com';
         $teacherMail ->SMTPAuth = true;
         $teacherMail ->Username = 'muijing0112@gmail.com';
         $teacherMail ->Password = 'hrqy kpzo jptn yaor';
         $teacherMail ->SMTPSecure = 'tls';
         $teacherMail ->Port = 587;
         
 
         // Email Configuration
         $teacherMail ->setFrom('muijing0112@gmail.com', 'MuseKnight');
         $teacher_ids = array_unique($teacher_ids);
        // Loop through selected students and send an email to each student
        foreach ($teacher_ids as $teacher_id) {
            $teacherEmail = $this->Teacher_model->getTeacherEmailById($teacher_id);

            // Compose and send the email to student
            $teacherMail ->addAddress($teacherEmail); // Recipient email
            $teacherMail ->Subject = 'MuseKnight - New Announcement Available!';
            $teacherMail ->Body = '
                <html>
                <head>
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            background-color: #f4f4f4;
                            color: #333;
                            margin: 0;
                            padding: 20px;
                        }
            
                        .container {
                            max-width: 600px;
                            margin: 0 auto;
                            background-color: #fff;
                            padding: 20px;
                            border-radius: 8px;
                            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                        }
            
                        h1 {
                            color: #333;
                            text-align: center;
                        }
            
                        p {
                            margin-bottom: 15px;
                        }
            
                        a {
                            color: #007BFF;
                            text-decoration: none;
                            font-weight: bold;
                        }
            
                        a:hover {
                            text-decoration: underline;
                        }
            
                        .footer {
                            margin-top: 20px;
                            padding-top: 10px;
                            border-top: 1px solid #ccc;
                            text-align: center;
                        }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <h1 style="color: #007BFF; text-align: center;">MuseKnight - New Announcement Available!</h1>
                        <p>
                            Dear Teacher,
                            <br>
                            We are pleased to inform you that a new announcement has been posted on our website.
                        </p>
            
                        <p>
                            <strong>Subject:</strong>  ' . $subject_title  . '
                            <br>
                            <strong>Announcement Title:</strong> ' . $title  . '
                            <br>
                            <strong>Announcement Content:</strong> ' . $description . '
                        </p>
            
                        <p>
                            To view the announcement, please visit the website at the following link:
                            <br>
                            <a href="http://museknight1.local/" target="_blank">http://museknight1.local/</a>
                        </p>
            
                        <p>
                            Thank you for staying updated with our latest information.
                        </p>
            
                        <div class="footer">
                            Sincerely,
                            <br>
                            [Admin]
                            <br>
                            [MuseKnight]
                        </div>
                    </div>
                </body>
                </html>
            ';
            $teacherMail ->isHTML(true);
            

            if (!$teacherMail ->send()) {
                log_message('error', 'Email could not be sent to teacher ' . $teacher_id . ': ' . $teacherMail->ErrorInfo);
            }
        }
    }

    // Create a single announcement for all selected students
    $data = array(
        'sender_id' => '1',
        'sender_type' => 'admin', // Change this to 'admin'
        'subject_id' => $subject_id,
        'title' => $title,
        'description' => $description
    );
    

    // Insert the data into the Annoucement_model
    $this->Annoucement_model->insert($data);

    // Redirect to the list of announcements or any other page
    redirect('admin/annoucement/list/' . $subject_id);
}
     
}
