<?php $this->load->view("teacher/nav"); ?>
<?php $this->load->view("layouts/header"); ?>

<style>
  input {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
}

/* Style the submit button */
input[type=submit] {
  background-color: #04AA6D;
  color: white;
}

/* Style the container for inputs */
.container {
  background-color: #fff;
  padding: 10px;
}

/* The message box is shown when the user clicks on the password field */
#message {
  display:none;
  background: #f1f1f1;
  color: #000;
  position: relative;
  padding: 20px;
  margin-top: 10px;
}

#message p {
  padding: 10px 35px;
  font-size: 11px;
}

/* Add a green text color and a checkmark when the requirements are right */
.valid {
  color: green;
}

.valid:before {
  position: relative;
  left: -35px;
  content: "✔";
}

/* Add a red text color and an "x" when the requirements are wrong */
.invalid {
  color: red;
}

.invalid:before {
  position: relative;
  left: -35px;
  content: "✖";
}
  .toast {
    position: fixed;
    top: 16px;
    right: 16px;
    min-width: 300px;
    padding: 16px;
    background-color: #28a745;
    color: #fff;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    display: none;
    z-index: 1000;
  }

  .student-profile .card {
    border-radius: 10px;
  }

  .student-profile .card .card-header .profile_img {
    width: 150px;
    height: 150px;
    object-fit: cover;
    margin: 10px auto;
    border: 10px solid #ccc;
    border-radius: 50%;
  }

  .student-profile .card h3 {
    font-size: 20px;
    font-weight: 700;
  }

  .student-profile .card p {
    font-size: 16px;
    color: #000;
  }

  .student-profile .table th,
  .student-profile .table td {
    font-size: 14px;
    padding: 5px 10px;
    color: #000;
  }

  .edit-password {
    margin-left: 5px;
    /* Adjust the spacing as needed */
    color: #007bff;
    /* Change the color to your preferred color */
    text-decoration: none;
  }

  .profile-pic-wrapper {
    width: 100%;
    position: relative;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }

  .pic-holder {
    text-align: center;
    position: relative;
    border-radius: 50%;
    width: 220px;
    height: 220px;
    overflow: hidden;
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 20px;
  } 

  /* Snackbar css */
  .snackbar {
    visibility: hidden;
    min-width: 250px;
    background-color: #333;
    color: #fff;
    text-align: center;
    border-radius: 2px;
    padding: 16px;
    position: fixed;
    z-index: 1;
    left: 50%;
    bottom: 30px;
    font-size: 14px;
    transform: translateX(-50%);
  }

  .snackbar.show {
    visibility: visible;
    -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
    animation: fadein 0.5s, fadeout 0.5s 2.5s;
  }

  @-webkit-keyframes fadein {
    from {
      bottom: 0;
      opacity: 0;
    }

    to {
      bottom: 30px;
      opacity: 1;
    }
  }

  @keyframes fadein {
    from {
      bottom: 0;
      opacity: 0;
    }

    to {
      bottom: 30px;
      opacity: 1;
    }
  }

  @-webkit-keyframes fadeout {
    from {
      bottom: 30px;
      opacity: 1;
    }

    to {
      bottom: 0;
      opacity: 0;
    }
  }

  @keyframes fadeout {
    from {
      bottom: 30px;
      opacity: 1;
    }

    to {
      bottom: 0;
      opacity: 0;
    }
  }
  /* Custom hover color for the button */
.btn:hover {
    background-color: #6f42c1; /* Change this to your desired hover color */
    border-color: #6f42c1; /* Also change the border color if needed */
    color: #fff; /* Text color on hover */
}

</style>


<!-- Student Profile -->
<br>
<div class="student-profile py-4" style="padding-left:20%; ; padding-right: 4%;">
  
  <div class="card">
    <div class="card-header">
      <div style="padding:10px 0px; font-weight:600;">
        <span style="color:gray;">Home / </span>
        <a href="<?= base_url($folder_name.'/profile/index') ?>" style="text-decoration:none; color:black;">Profile</a>
      </div>
    </div>
    <div class="card-body">
      <blockquote class="blockquote mb-0">
        <div class="container">
          <div class="row">
            <div class="profile-pic-wrapper">
              <div class="pic-holder">

                <!-- uploaded pic shown here -->
                <img id="profilePic" class="pic" src="<?php echo empty($userdata['image']) ? base_url('assets/img/profil.png') : $userdata['image']; ?>" alt="Profile Image">
                <img src="<?=base_url('assets/img/profiles/'.$userdata['image'])?>" alt="" style="width: 200px; height:200px; border-radius:50%;">

                <Input class="uploadProfileInput" type="file" name="profile_pic" id="newProfilePhoto" accept="image/*" style="opacity: 0;" />
                <label for="newProfilePhoto" class="upload-file-block">
                  <div class="text-center">
                    <div class="mb-2">
                      <i class="fa fa-camera fa-2x"></i>
                    </div>
                  </div>
                </label>
              </div>

              <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter" style="margin-bottom:2%; margin-top:1%;">
                  Change Profile
                </button>

                <!-- Modal -->
                <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Update Profile Image</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                      <form action="<?= base_url('teacher/profile/updateProfileImage') ?>" method="post" enctype="multipart/form-data">
                          <input type="hidden" name="user_id" value="<?= $userdata['id'] ?>">
                          <div class="form-group">
                            <input type="file" name="image" id="image">
                          </div>
                          <br>
                          <button type="submit" class="btn btn-primary" name="update_profile">Save changes</button>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>


            </div>
            <!--------------------------personal info--------------------------------------->
            <div class="card" style="width:70%; margin: 0 auto; ">
              <div class="card-body">
                <a href="<?= base_url('teacher/profile/viewPDF/' . $userdata['id']) ?>" class="btn btn-info rounded-circle" target="_blank" style="width: 60px; height: 60px; display: flex; align-items: center; justify-content: center; margin-left: auto;">
                  <i class="bi bi-filetype-pdf text-white" style="font-size: 24px;"></i>
                </a>
                <form>
                  <div class="form-group row">
                    <label for="name" class="col-sm-2 col-form-label">Name</label>
                    <div class="col-sm-10">
                      <input readonly type="text" id="name" class="form-control" name="name" value="<?= $userdata['name'] ?>">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="serial" class="col-sm-2 col-form-label">Serial</label>
                    <div class="col-sm-10">
                      <input readonly type="text" id="serial" class="form-control" name="serial" value="<?= $userdata['serial'] ?>">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="gender" class="col-sm-2 col-form-label">Gender</label>
                    <div class="col-sm-10">
                      <input readonly type="text" id="gender" class="form-control" name="gender" value="<?= $userdata['gender'] ?>">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="staticEmail" class="col-sm-2 col-form-label">Email</label>
                    <div class="col-sm-10">
                      <input readonly type="text" id="email" class="form-control" name="email" value="<?= $userdata['email'] ?>">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="mobile" class="col-sm-2 col-form-label">Mobile</label>
                    <div class="col-sm-10">
                      <input readonly type="text" id="mobile" class="form-control" name="mobile" value="<?= $userdata['mobile'] ?>">
                    </div>
                  </div>
                  <div class="form-group row">
                    <label for="inputPassword" class="col-sm-2 col-form-label">Password</label>
                    <div class="col-sm-10"> <!-- Adjust the width of the column -->
                      <div class="d-flex justify-content-between">
                        <input readonly type="text" id="password" class="form-control" name="password" value="<?= $userdata['password'] ?>">
                        <button type="button" class="btn btn" data-toggle="modal" data-target="#RestPassword" style="height:35px; margin-top:1%;"><i class="bi bi-pencil"></i></button>
                      </div>
                    </div>
                  </div>
                  <!--------------------------personal info end--------------------------------------->
                  <hr>
                  <!------------------------------lesson info------------------------------->
                    <div class="form-group row">
                      <label for="" class="col-sm-2 col-form-label">Subject</label>
                        <div class="col-sm-10">
                            <?php
                            if (isset($userdata['id'])) {
                                $teacher_id = $userdata['id'];

                                // Fetch the subjects associated with the teacher from the teacher_subject table
                                $this->db->select('subject.title');
                                $this->db->from('teacher_subject'); // Update the table name
                                $this->db->join('subject', 'teacher_subject.subject_id = subject.id');
                                $this->db->where('teacher_subject.teacher_id', $teacher_id); // Update the teacher_id field

                                $subject_query = $this->db->get();
                                $subject_details = $subject_query->result_array();

                                // Display each subject title
                                foreach ($subject_details as $subject) {
                                    if (isset($subject['title'])) {
                                        echo '<input readonly type="text" class="form-control" value="' . $subject['title'] . '">';
                                    } else {
                                        echo '<input readonly type="text" class="form-control" value="Unknown Subject">';
                                    }
                                }
                            }
                            ?>
                        </div>
                    </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </blockquote>
    </div>
    <div class="d-flex justify-content-end">
</div>
  </div>
</div>

<!-- Modal for changing password -->
<!-- <div class="modal fade" id="changePasswordModal" tabindex="-1" role="dialog" aria-labelledby="changePasswordModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <form id="changePasswordForm">
        <div class="modal-header">
          <h5 class="modal-title" id="changePasswordModalLabel">Change Password</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <label for="newPassword">New Password:</label>
          <div class="input-group">
            <input type="password" id="newPassword" name="newPassword" class="form-control" required>
            <div class="input-group-append">
              <div class="input-group-text">
                <i id="showPasswordToggle" class="bi bi-eye-fill" style="cursor: pointer;"></i>
              </div>
            </div>
          </div>
          <div id="passwordError" style="color: red;"></div>

       Password format requirements 
          <div id="passwordRequirements" style="color: #888; font-size: 12px; margin-top: 5px;">
            Password must be at least 8 characters long and include both letters and numbers.
          </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" id="savePasswordBtn">Save Changes</button>
        </div>
      </form>
    </div>
  </div>
</div> -->

<!------------------------------------------------------------------------------------ Rest Password Pop Up Modal ------------------------------------------------------------------------------------>
<?php if ($this->session->flashdata('success_message')): ?>
    <div id="success-alert" class="alert alert-success alert-dismissible fade show position-fixed" style="top: 1%; right: 0;" role="alert">
        <strong>Success!</strong> <?= $this->session->flashdata('success_message') ?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>

    <script>
        $(document).ready(function(){
            // Hide the success message after 1000 milliseconds (1 second)
            setTimeout(function(){
                $("#success-alert").fadeOut("slow");
            }, 1000);
        });
    </script>
<?php endif; ?>



<div class="modal fade" id="RestPassword" tabindex="-1" role="dialog" aria-labelledby="RestPassword" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Rest Password</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <h3>Password Validation</h3>
          <p>Try to submit the form.</p>

          <div class="container">
          <form method="POST" id="edit_form" action="<?= base_url('teacher/profile/update/' . $userdata['id']) ?>">            
          <label for="new_psw">New Password</label>
            <input type="password" id="new_psw" name="new_password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
            
            <input type="submit" value="Submit">
          </form>

          </div>

          <div id="message">
            <h6>Password must contain the following:</h6>
            <p id="letter" class="invalid">A <b>lowercase</b> letter</p>
            <p id="capital" class="invalid">A <b>capital (uppercase)</b> letter</p>
            <p id="number" class="invalid">A <b>number</b></p>
            <p id="length" class="invalid">Minimum <b>8 characters</b></p>
          </div>
      </div>
    </div>
  </div>
</div>



<script>
  function showContent() {
    var select = document.getElementById("contentSelector");
    var selectedOption = select.options[select.selectedIndex].value;
    var contentDivs = document.getElementsByClassName("payment_detail");
    var upload_invoice = document.getElementById("upload_invoice");

    for (var i = 0; i < contentDivs.length; i++) {
      if (contentDivs[i].id === selectedOption) {
        contentDivs[i].style.display = "block";
        upload_invoice.style.display = "block";
      } else {
        contentDivs[i].style.display = "none";
      }
    }
  }

  function validateForm() {
    var fileInput = document.getElementById('fileInput');
    if (fileInput.files.length === 0) {
      alert('Please select a file to upload.');
      return false;
    }
    return true;
  }

  ////reset password 
var myInput = document.getElementById("new_psw");
var letter = document.getElementById("letter");
var capital = document.getElementById("capital");
var number = document.getElementById("number");
var length = document.getElementById("length");

// When the user clicks on the password field, show the message box
myInput.onfocus = function() {
  document.getElementById("message").style.display = "block";
}

// When the user clicks outside of the password field, hide the message box
myInput.onblur = function() {
  document.getElementById("message").style.display = "none";
}

// When the user starts to type something inside the password field
myInput.onkeyup = function() {
  // Validate lowercase letters
  var lowerCaseLetters = /[a-z]/g;
  if(myInput.value.match(lowerCaseLetters)) {  
    letter.classList.remove("invalid");
    letter.classList.add("valid");
  } else {
    letter.classList.remove("valid");
    letter.classList.add("invalid");
  }
  
  // Validate capital letters
  var upperCaseLetters = /[A-Z]/g;
  if(myInput.value.match(upperCaseLetters)) {  
    capital.classList.remove("invalid");
    capital.classList.add("valid");
  } else {
    capital.classList.remove("valid");
    capital.classList.add("invalid");
  }

  // Validate numbers
  var numbers = /[0-9]/g;
  if(myInput.value.match(numbers)) {  
    number.classList.remove("invalid");
    number.classList.add("valid");
  } else {
    number.classList.remove("valid");
    number.classList.add("invalid");
  }
  
  // Validate length
  if(myInput.value.length >= 8) {
    length.classList.remove("invalid");
    length.classList.add("valid");
  } else {
    length.classList.remove("valid");
    length.classList.add("invalid");
  }
};


</script>