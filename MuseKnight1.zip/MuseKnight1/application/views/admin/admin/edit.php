<?php $this->load->view("admin/nav"); ?>
<?php $this->load->view("layouts/header"); ?>


<div class="container-fluid" style="padding-left: 20%; padding-right: 5%; padding-top: 3%;">
    <form method="POST" id="create_form" action="<?=base_url('admin/admin/update/'.$admin['id'])?>">
        <div style="text-align: end; margin-bottom:20px;">
            <a href="<?=base_url('admin/admin/list')?>" class="btn btn-secondary">Back</a>
            <button type="submit" class="btn btn-primary">Save Changes</button>
        </div>
        <div class="card shadow">
            <div style="padding: 30px;">
                <div class="row" style="text-align: start; margin-bottom:10px" >
                    <div class="col-6 form-group mb-2">
                        <label for="serial" style="font-weight: 500;" class="mb-2">Serial ID</label>
                        <input readonly type="text" id="serial" class="form-control bg-light" name="serial" value="<?= $admin['serial'] ?>">
                    </div>
                    <div class="col-6 form-group mb-2">
                        <label for="name" style="font-weight: 500;" class="mb-2">Name</label>
                        <input required type="text" id="name" class="form-control" name="name" value="<?= $admin['name'] ?>">
                    </div>
                    <div class="col-6 form-group mb-2">
                        <label for="email" style="font-weight: 500;" class="mb-2">Email</label>
                        <input required type="text" id="email" class="form-control" name="email" value="<?= $admin['email'] ?>">
                    </div>
                    <div class="col-6 form-group mb-2">
                        <label for="mobile" style="font-weight: 500;" class="mb-2">Mobile</label>
                        <input required type="text" id="mobile" class="form-control" name="mobile" value="<?= $admin['mobile'] ?>">
                    </div>
                    <div class="col-6 form-group mb-2">
                        <label for="password" style="font-weight: 500;" class="mb-2">Password</label>
                        <input required type="password" id="password" class="form-control" name="password" value="<?= $admin['password'] ?>">
                    </div>
                    <div class="col-6 form-group mb-2">
                        <label for="status" style="font-weight: 500;" class="mb-2">Status</label>
                        <select name="status" id="status" class="form form-select">
                            <option value="0">Admin</option>
                            <option value="1">Super Admin</option>
                        </select>
                    </div>
                </div>
                <div style="text-align: end;">
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </form>
</div>