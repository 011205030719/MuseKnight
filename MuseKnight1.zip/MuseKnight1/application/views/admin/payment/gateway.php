<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<?php $this->load->view("layouts/header"); ?>

<style>
    body{
        background: #f5f5f5
    }
    .rounded{
        border-radius: 1rem
    }
    .nav-pills .nav-link{
        color: #555
    }
    .nav-pills .nav-link.active{
        color: white
    }input[type="radio"]{
            margin-right: 5px
        }
    .bold{
        font-weight:bold
        }
</style>

<div class="container py-5">
    <!-- For demo purpose -->
    <div class="row mb-4">
        <div class="col-lg-8 mx-auto text-center">
            <h1 class="display-6">MuseKnight Tuition Payment</h1>
        </div>
    </div> <!-- End -->

    <div class="row">
        <div class="col-lg-6 mx-auto">
            <div class="card ">
                <div class="card-header">
                    <div class="bg-white shadow-sm pt-4 pl-2 pr-2 pb-2">
                        <!-- Credit card form tabs -->
                        <ul role="tablist" class="nav bg-light nav-pills rounded nav-fill mb-3">
                            <li class="nav-item"> <a data-toggle="pill" href="#tng" class="nav-link active "> <i class="bi bi-walle"></i> TNG</a> </li>
                            <li class="nav-item"> <a data-toggle="pill" href="#net-banking" class="nav-link "> <i class="fas fa-mobile-alt mr-2"></i> Net Banking </a> </li>
                        </ul>
                    </div> <!-- End -->

                    <!-- Credit card form content -->
                    <div class="tab-content">
                        <!-- credit card info-->
                        <div id="tng" class="tab-pane fade show active pt-3">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="card" >
                                    <div class="card-header">
                                        Payment Details
                                    </div>
                                    <div class="card-body text-center">
                                        <blockquote class="blockquote mb-0">
                                            <img src="<?= base_url('assets/img/tngQR.webp') ?>" class="img-rounded logo" style="max-width: 100px; max-height: 100px; border: 2px solid #ADD8E6; padding: 5px;">
                                            <br>    
                                            <h4 style="margin-top: 10px;">RM <?php echo number_format(calculateTotalTuition($sales), 2); ?></h4>
                                        </blockquote>
                                    </div>
                                </div>
                            </div>


                            <div class="col-md-8" >
                                <div class="card">
                                    <div class="card-header">
                                        Order Summary
                                    </div>
                                    <div class="card-body">
                                        <blockquote class="blockquote mb-0">
                                            <table>
                                                <tbody>
                                                    <tr>
                                                        <td class="pull-right">Payment To:</td>
                                                        <td><strong>MuseKnight Music Centre</strong></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="pull-right">Transaction No:</td>
                                                        <td><strong><?php echo mt_rand(100000000000, 999999999999); ?></strong></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="pull-right">Payment Details:</td>
                                                        <td>
                                                            <strong>
                                                                <?php if (!empty($sales)) {
                                                                    $unpaidDetails = [];
                                                                    foreach ($sales as $sale) {
                                                                        if ($sale['status'] == 0) {
                                                                            // Get the subject title from the subject_id
                                                                            $subjectTitle = $this->Subject_model->getOne(array('id' => $sale['subject_id'], 'is_deleted' => 0))['title'];
                                                                            $unpaidDetails[] = $subjectTitle . ' - ' . $sale['month'];
                                                                        }
                                                                    }
                                                                    echo "Payment for " . implode(', ', $unpaidDetails);
                                                                } ?>
                                                            </strong>
                                                        </td>
                                                    </tr>




                                                    <br>
                                                    <tr>
                                                        <td colspan="2">
                                                            <hr class="text-muted">
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="pull-right">TOTAL:</td>
                                                        <td><strong>RM <?php echo number_format(calculateTotalTuition($sales), 2); ?></strong></td>
                                                    </tr>
                                            
                                                </tbody>
                                            </table>
                                        </blockquote>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                            <p class="text-muted"> <strong>Pay with your Touch'n Go eWallet!</strong>
                            <br>
                            <ol class="police">
                                <li>Download and regiter for the Touch'n Go eWallet app if you haven't.If you have, lauch you TNG eWallet app </li>
                                <li>Tap on the "Scan" icon</li>
                                <li>Scan the QR code here and complate the payment!</li>    
                            </ol>
                            </p>
                    </div> 
                    <!-- End -->

                    <!-- bank transfer info -->
                    <div id="net-banking" class="tab-pane fade pt-3">
                        <div class="form-group "> 
                            <label for="Select Your Bank">
                                <h6>Select your Bank</h6>
                            </label> 
                            <select class="form-control" id="ccmonth">
                                <option value="" selected disabled>--Please select your Bank--</option>
                                <option>AmBank</option>
                                <option>Public Bank Berhad</option>
                                <option>OCBC Bank Malaysia</option>
                                <option>HSBC Bank Malaysia</option>
                                <option>Hong Leong Bank</option>
                                <option>CIMB</option>
                                <option>UOB Malaysia</option>
                            </select> 
                        </div>
                        <br>
                        <div class="form-group">
                            <p> <button type="button" class="btn btn-primary "><i class="fas fa-mobile-alt mr-2"></i> Proceed Payment</button> </p>
                        </div>
                        <p class="text-muted">Note: After clicking on the button, you will be directed to a secure gateway for payment. After completing the payment process, you will be redirected back to the website to view details of your order. </p>
                    </div> <!-- End -->

                    <!-- End -->
                </div>
            </div>
        </div>
    </div>

    <script>
        $(function() {
  $('[data-toggle="tooltip"]').tooltip()

    // JavaScript to generate a random twelve-digit number
    document.addEventListener("DOMContentLoaded", function () {
        var transactionNumberElement = document.getElementById("transactionNumber");
        var randomTransactionNumber = Math.floor(100000000000 + Math.random() * 900000000000);
        transactionNumberElement.textContent = randomTransactionNumber;
    });
})
        </script>