<?php $this->load->view("admin/nav"); ?>
<?php $this->load->view("layouts/header"); ?>


<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/dt/jq-2.1.4,jszip-2.5.0,pdfmake-0.1.18,dt-1.10.9,af-2.0.0,b-1.0.3,b-colvis-1.0.3,b-html5-1.0.3,b-print-1.0.3,se-1.0.1/datatables.min.css" />
<style>
    .payment-button {
        background-color: #FF5733;
        color: white;
    }


    .receipt-button {
        background-color: mediumspringgreen;
        color: white;
    }

    .custom-module {
        margin-top: -10px;
        margin-bottom: 20px;
        background-color: #703be7;
        height: 40px;
        width: 250px;
        display: flex;
        justify-content: center;
        align-items: center;
        position: relative;
        border-radius: 25px;
        color: #fff;
        text-align: left;
        font-size: 18px;
    }

    .status {
        color: white;
        font-size: 12px;
        font-weight: 600;
        padding-top: 3px;
        padding-bottom: 5px;
        padding-left: 10px;
        padding-right: 10px;
        border-radius: 10px;
    }

    .table-container {
        overflow-x: auto;
    }

    /* Modify the existing table style */
    table {
        background-color: white;
        width: 100%;
        /* Set the width to 100% */
        table-layout: fixed;
        /* Set the table layout to fixed */
        overflow: auto;
        display: block;
    }

    /* Adjust the widths of your table columns as needed */
    table th,
    table td {
        padding: 5px;
        text-align: left;
    }
    .custom-button {
    background-color: #7B68EE; /* Replace with your desired color */
    color: white; /* Text color */
    padding: 5px 15px; 
    }

</style>


<div class="container-fluid" style="padding-left: 20%; padding-right: 5%; padding-top: 1%;">

    <div class="header" style=" width:100%;">
        <div style="position: sticky; top: 0; z-index: 1000; background-color:#E6E6FA; border: 0px solid rgba(100, 100, 100, 1); border-radius: 12px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); padding: 10px; margin: 1%;">
            <span>Home / </span>
            <a href="<?= base_url($folder_name.'/salary/list') ?>" style="text-decoration:none; color:black;">Teacher salary</a>
        </div>
    <div>
    <div class="card shadow">
        <div style="padding: 30px;">
            <div style="overflow-x: auto;" class="table-container">
                <table id="lecturerTable" style="background-color: white; max-height: 400px; overflow-x: auto; display: block;" class="table table-bordered">
                    <thead>

                        <tr style="border-bottom: 2px solid lightgray;">
                            <th style="padding:5px 40px; width: 10%;">#</th>
                            <th style="padding:5px 100px; width: 50%;">Teacher Name</th>
                            <th style="padding:5px 40px; width: 10%;">Subject</th>
                            <th style="padding:5px 40px; width: 10%;">Commission Rate</th>
                            <th style="padding:5px 100px; width: 50%;">Bank</th>
                            <th style="padding:5px 60px; width: 30%;">Account</th>
                            <th style="padding:5px 40px; width: 10%;">Month</th>
                            <th style="padding:5px 40px; width: 10%;">Total Amount</th>
                            <th style="padding:5px 100px; width: 50%;">Receipt</th>
                            <th style="padding:5px 40px; width: 10%;">Receipt_Date</th>
                            <th style="padding:5px 40px; width: 10%;">Status</th>
                            <th style="padding:5px 120px; width: 60%;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($salarys as $key=> $salary) : ?>
                            <?php
                            $user_id = $salary['teacher_id'];
                            ?>

                            <tr class="table_row">
                                <th scope="row"><?= $key + 1 ?></th>
                                <td style="width:20%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                    <?php
                                    // Find the subject_title based on subject_id from the subjects array
                                    $teacher_id = $salary['teacher_id'];
                                    $teacher_name = '';
                                    foreach ($teachers as $teacher) {
                                        if ($teacher['id'] == $teacher_id) {
                                            $teacher_name = $teacher['name'];
                                            break; // Exit the loop once subject_title is found
                                        }
                                    }
                                    echo $teacher_name;
                                    ?>
                                </td>
                                <td style="width:20%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                    <?php
                                    $teacher_id = $salary['teacher_id']; // Assuming $teacher_id holds the teacher's ID
                                    $teacher_subjects_list = array(); // Initialize an array to store subject titles

                                    // Loop through the teacher_subject records to find the subject_ids for the given teacher_id
                                    foreach ($teacher_subjects as $teacher_subject) {
                                        if ($teacher_subject['teacher_id'] == $teacher_id) {
                                            $subject_id = $teacher_subject['subject_id'];

                                            // Loop through the subjects array to find the title of the subject based on subject_id
                                            foreach ($subjects as $subject) {
                                                if ($subject['id'] == $subject_id) {
                                                    $teacher_subjects_list[] = $subject['title'];
                                                }
                                            }
                                        }
                                    }

                                    // Check if there are any subjects associated with the teacher
                                    if (!empty($teacher_subjects_list)) {
                                        echo implode(', ', $teacher_subjects_list); // Display the list of subject titles
                                    }
                                    ?>
                                </td>


                                <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $salary['commission_rate'] ?></td>
                                <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                    <?php
                                    // Find the subject_title based on subject_id from the subjects array
                                    $teacher_id = $salary['teacher_id'];
                                    $teacher_bank = '';
                                    foreach ($teachers as $teacher) {
                                        if ($teacher['id'] == $teacher_id) {
                                            $teacher_bank = $teacher['bank'];
                                            break; // Exit the loop once subject_title is found
                                        }
                                    }
                                    echo $teacher_bank;
                                    ?>
                                </td>
                                <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                    <?php
                                    // Find the subject_title based on subject_id from the subjects array
                                    $teacher_id = $salary['teacher_id'];
                                    $teacher_account = '';
                                    foreach ($teachers as $teacher) {
                                        if ($teacher['id'] == $teacher_id) {
                                            $teacher_account = $teacher['account'];
                                            break; // Exit the loop once subject_title is found
                                        }
                                    }
                                    echo $teacher_account;
                                    ?>
                                </td>
                                <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $salary['month'] ?></td>
                                <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                    <?php 
                                        $total = (float)$salary['total_amount'] * 100;
                                        echo $total;
                                    ?>
                                </td>
                                <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                    <?php
                                    $receipt = $salary['receipt'];
                                    if ($receipt) {
                                        echo $receipt;
                                    } else {
                                        echo 'No Receipt</button>';
                                    }
                                    ?>
                                </td>


                                <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                    <?php
                                    $receipt_date = $salary['receipt_date'];
                                    if ($receipt_date) {
                                        echo $receipt_date;
                                    } else {
                                        echo 'No Receipt Date';
                                    }
                                    ?>
                                </td>
                                <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                    <?php
                                    $status = $salary['status'];

                                    if ($status == 0) {
                                        echo '<span style="color: red;">Unpaid</span>';
                                    } elseif ($status == 1) {
                                        echo '<span style="color: mediumspringgreen;">Paid</span>';
                                    } else {
                                        echo '<span style="color: gray;">Unknown Status</span>';
                                    }
                                    ?>
                                </td>
                                <td style="width:40%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                    <a href="<?= base_url('admin/salary/invoice/' . $salary['id']) ?>" target="_blank" class="btn receipt-button">Invoice</a>
                                    <a href="#" class="btn receipt-button upload-button custom-button" data-salaryid="<?= $salary['id'] ?>" data-teacherid="<?= $salary['teacher_id'] ?>" data-toggle="modal" data-target="#exampleModal">Upload</a>  

                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Upload Receipt</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <!-- File Upload Input with a form -->
                <form action="<?= base_url('admin/salary/SubmitPayment') ?>" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="teacher_id" id="modal-teacher-id" value="" />
                    <input type="hidden" name="salary_id" id="modal-salary-id" value="" />

                    <label class="form-label" for="receipt">Choose a file to upload</label>
                    <input type="file" class="form-control" name="receipt" id="receipt" accept="image/*" required />
                    <br>
                    <button type="submit" class="btn btn-primary">Upload and Save</button>
                </form>
                <!-- End of File Upload Input -->
            </div>
        </div>
    </div>
</div>



<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- DataTables and Bootstrap DataTables -->
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<!-- DataTables library -->
<script type="text/javascript" src="https://cdn.datatables.net/r/dt/jq-2.1.4,jszip-2.5.0,pdfmake-0.1.18,dt-1.10.9,af-2.0.0,b-1.0.3,b-colvis-1.0.3,b-html5-1.0.3,b-print-1.0.3,se-1.0.1/datatables.min.js"></script>

<script>
    $(document).ready(function() {
        $('#lecturerTable').DataTable({
            dom: 'lBfrtip',
            lengthMenu: [10, 25, 50],
            searching: true,
            buttons: [{
                extend: 'excel',
                text: 'Download Data',
                className: 'btn btn-outline-success',
                init: function(api, node, config) {
                    $(node).removeClass('dt-button');
                    $(node).css({
                        'margin-left': '10%',
                        'margin-bottom': '10%',
                        'height': '30px',
                        'width': '150px',
                        'font-size': '17px',
                        'display': 'flex',
                        'align-items': 'center'
                    });
                }
            }]
        });

        // Handle the "Upload" button click and set the teacher_id in the modal
        $('.upload-button').click(function() {
            var teacherId = $(this).data('teacherid');
            $('#modal-teacher-id').val(teacherId);
            
            var salaryId = $(this).data('salaryid');
            $('#modal-salary-id').val(salaryId);
        });
    });

    function showContent() {
        var select = document.getElementById("contentSelector");
        var selectedOption = select.options[select.selectedIndex].value;
        var contentDivs = document.getElementsByClassName("payment_detail");
        var upload_invoice = document.getElementById("upload_invoice");

        for (var i = 0; i < contentDivs.length; i++) {
            if (contentDivs[i].id === selectedOption) {
                contentDivs[i].style.display = "block";
                upload_invoice.style.display = "block";
            } else {
                contentDivs[i].style.display = "none";
            }
        }
    }

    function validateForm() {
        var fileInput = document.getElementById('fileInput');
        if (fileInput.files.length === 0) {
            alert('Please select a file to upload.');
            return false;
        }
        return true;
    }
</script>