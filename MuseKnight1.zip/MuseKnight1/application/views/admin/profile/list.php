<?php $this->load->view("admin/nav"); ?>
<?php $this->load->view("layouts/header"); ?>

<style>
  .toast {
    position: fixed;
    top: 16px;
    right: 16px;
    min-width: 300px;
    padding: 16px;
    background-color: #28a745;
    color: #fff;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    display: none;
    z-index: 1000;
  }
    
.student-profile .card {
  border-radius: 10px;
}

.student-profile .card .card-header .profile_img {
  width: 150px;
  height: 150px;
  object-fit: cover;
  margin: 10px auto;
  border: 10px solid #ccc;
  border-radius: 50%;
}

.student-profile .card h3 {
  font-size: 20px;
  font-weight: 700;
}

.student-profile .card p {
  font-size: 16px;
  color: #000;
}

.student-profile .table th,
.student-profile .table td {
  font-size: 14px;
  padding: 5px 10px;
  color: #000;
}

.edit-password {
  margin-left: 5px; /* Adjust the spacing as needed */
  color: #007bff; /* Change the color to your preferred color */
  text-decoration: none;
}

</style>


<!-- Student Profile -->
   <br>
   <div class="container"style="padding-left:20%; margin-top:1%;">
   <form method="POST" id="create_form" action="<?=base_url('admin/student/update/'.$student['id'])?>">
				<div class="card shadow mb-3">

					<div class="card-header">
						<div class="d-flex justify-content-between align-items-center" style="font-size: 17px;">
							<div>
								<i class="bx bx-edit-alt" style="margin-right: 8px;"></i>
								Edit Student Information
							</div>
						</div>
					</div>
        <div class="student-profile py-4" style="padding-left:5%; margin-top:1%; padding-right:5%;">

          <div class="container">
            <div class="row">
              <div class="col-lg-4">
                <div class="card shadow-sm">
                  <div class="card-header bg-transparent text-center">
                    <img class="profile_img" src="<?=base_url('assets/img/profil1.jpeg')?>"alt="">
                    <h3><?= $student['name'] ?></h3>
                  </div>
                  
                  <div class="card-body">
                    <p class="mb-0"><strong class="pr-1">Serial ID:</strong><?= $student['serial'] ?></p>
                    
                  </div>
                </div>
              </div>
              <div class="col-lg-8">
                <div class="card shadow-sm">
                  <div class="card-header bg-transparent border-0">
                    <h3 class="mb-0"><i class="far fa-clone pr-1"></i>General Information</h3>
                  </div>
                  <div class="card-body pt-0">
                    <table class="table table-bordered">
                      <tr>
                        <th width="30%">Email</th>
                          <td width="2%">:</td>
                          <td><?= $student['email'] ?></td>
                      </tr>
                      <tr>
                        <th width="30%">Phone Number</th>
                          <td width="2%">:</td>
                          <td><?= $student['mobile'] ?></td>
                      </tr>
                      <tr>
                      <th width="30%">Password</th>
                        <td width="2%">:</td>
                        <td>
                          <span id="password"><?= $student['password'] ?></span>
                          <a href="#" class="edit-password" ><i class="bi bi-pencil-square"></i></a>
                        </td>
                      </tr>
                      <tr>
                        <th width="30%">Created Date</th>
                        <td width="2%">:</td>
                        <td><?= date('Y-m-d', strtotime($student['created_date'])) ?></td>
                    </tr>

                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
</div>
</div>

        <!-- Modal for changing password -->
<!-- Modal for changing password -->
<div class="modal fade" id="changePasswordModal" tabindex="-1" role="dialog" aria-labelledby="changePasswordModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="changePasswordModalLabel">Change Password</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <label for="newPassword">New Password:</label>
        <div class="input-group">
          <input type="password" id="newPassword" class="form-control" required>
          <div class="input-group-append">
            <div class="input-group-text">
              <i id="showPasswordToggle" class="bi bi-eye-fill" style="cursor: pointer;"></i>
            </div>
          </div>
        </div>
        <div id="passwordError" style="color: red;"></div>

        <!-- Password format requirements -->
        <div id="passwordRequirements" style="color: #888; font-size: 12px; margin-top: 5px;">
          Password must be at least 8 characters long and include both letters and numbers.
        </div>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="savePasswordBtn">Save Changes</button>
      </div>
    </div>
  </div>
</div>


<script>
    document.addEventListener('DOMContentLoaded', function () {
    var savePasswordBtn = document.getElementById('savePasswordBtn');
    var changePasswordModal = document.getElementById('changePasswordModal');
    var newPasswordInput = document.getElementById('newPassword'); // Declare globally
    var showPasswordToggle = document.getElementById('showPasswordToggle');
    var toastElement = document.createElement('div');
    toastElement.className = 'toast';
    document.body.appendChild(toastElement);

    // Define the event listener for the "Edit Password" icon
    var editPasswordBtn = document.querySelector('.edit-password');
    editPasswordBtn.addEventListener('click', function () {
      $(changePasswordModal).modal('show');
    });

    // Define the event listener for the eye icon to toggle password visibility
    showPasswordToggle.addEventListener('click', function () {
      if (newPasswordInput.type === 'password') {
        newPasswordInput.type = 'text';
        showPasswordToggle.classList.remove('bi-eye-fill');
        showPasswordToggle.classList.add('bi-eye-slash-fill');
      } else {
        newPasswordInput.type = 'password';
        showPasswordToggle.classList.remove('bi-eye-slash-fill');
        showPasswordToggle.classList.add('bi-eye-fill');
      }
    });

    savePasswordBtn.addEventListener('click', function () {
      var new_password = newPasswordInput.value;
      var user_id = <?= $userdata['id'] ?>;
      var current_password = '<?= $userdata['password'] ?>';

      // Check if the new password is the same as the current one
      if (new_password === current_password) {
        passwordError.textContent = 'New password cannot be the same as the current one.';
        return;
      }

      // Check password format
      if (!isValidPasswordFormat(new_password)) {
        passwordError.textContent = 'Incorrect password format.';
        return;
      }

      // Clear previous error messages
      passwordError.textContent = '';

      // Send an AJAX request to update the password
      $.ajax({
        url: '<?= base_url('admin/profile/update_password/') ?>' + user_id,
        type: 'POST',
        data: { new_password: new_password },
        success: function (response) {
          // Handle success, if needed
          console.log(response);

          // Show success toast notification
          showToast('Password updated successfully!');

          // Close the modal
          $(changePasswordModal).modal('hide');

          // Reload the page after 3 seconds (adjust the delay as needed)
          setTimeout(function () {
            window.location.reload();
          }, 3000);
        },
        error: function (error) {
          // Handle error, if needed
          console.error(error);
        }
      });
    });

    // Password format validation function
    function isValidPasswordFormat(password) {
      // Implement your password format validation logic here
      // For example, check length, presence of letters and numbers, etc.
      var isValid = password.length >= 8 && /[a-zA-Z]/.test(password) && /\d/.test(password);

      // Update the UI to show/hide the requirements based on validation
      var requirementsElement = document.getElementById('passwordRequirements');
      requirementsElement.style.display = isValid ? 'none' : 'block';

      return isValid;
    }

    // Function to show a toast notification
    function showToast(message) {
      toastElement.textContent = message;
      toastElement.style.display = 'block';

      // Hide the toast after 3 seconds (adjust the delay as needed)
      setTimeout(function () {
        toastElement.style.display = 'none';
      }, 3000);
    }
  });
</script>