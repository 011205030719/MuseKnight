<?php
//This is the default model that used for every new model
class MY_Model extends CI_Model
{
	protected $table_name = "";
	public $primaryKey = "id";

	public function __construct()
	{
		$this->load->database("default");
	}

    public function set_table($table)
    {
        $this->table_name = $table;
        $this->primaryKey = 'id';
    }
	

	// public function get_all() {
    //     return $this->db->get('subject')->result_array();
    // }

	//for counting total data
	public function record_count($where = array(), $like = array(), $where_in_col = "consignee_id", $where_in = array(), $or_like = array(), $custom = "", $join_table = "", $join_query = "")
	{

		$this->db->select("COUNT(*) AS total");
		$this->db->where($where);

		if (!empty($custom)) {
			$this->db->where($custom);
		}

		if (!empty($where_in)) {
			$this->db->where_in($where_in_col, $where_in);
		}

		if (!empty($like)) {
			foreach ($like as $k => $v) {
				$this->db->like($k, $v);
			}
		}

		if (!empty($or_like)) {
			$i = 1;
			$this->db->group_start();
			foreach ($or_like as $k => $v) {
				if ($i == 1) {
					$this->db->like($k, $v);
				} else {
					$this->db->or_like($k, $v);
				}
				$i++;
			}
			$this->db->group_end();
		}

		if (!empty($join_table) && !empty($join_query)) {
			$this->db->join($join_table, $join_query);
		}

		$query = $this->db->get($this->table_name);
		$row = $query->row_array();
		return $row['total'];
	}

	public function groupby_count($groupby = '', $where = array())
	{
		$this->db->select("COUNT(*) AS total, $groupby");
		if (!empty($groupby)) {
			$this->db->group_by($groupby);
		}

		$this->db->where($where);

		$query = $this->db->get($this->table_name);
		if ($query->num_rows() > 0) {
			return $query->result_array();
		} else {
			return array();
		}
	}

	//for pagination
	public function fetch($limit, $start, $where = array('is_deleted' => 0), $like = array(), $orderBy = array(), $select = "*", $groupBy = "", $where_in = array(), $where_in_col = "", $or_like = array(), $custom = "", $join_table = "", $join_query = "")
	{

		if ($select != "*") {
			$this->db->select($select);
		}
		$this->db->where($where);
		if (!empty($like)) {
			if (is_array($like)) {
				foreach ($like as $k => $v) {
					$this->db->like($k, $v);
				}
			} else {
				$this->db->where($like);
			}
		}

		if (!empty($or_like)) {
			$i = 1;
			$this->db->group_start();
			foreach ($or_like as $k => $v) {
				if ($i == 1) {
					$this->db->like($k, $v);
				} else {
					$this->db->or_like($k, $v);
				}
				$i++;
			}
			$this->db->group_end();
		}

		if (!empty($where_in)) {
			$this->db->where_in($where_in_col, $where_in);
		}

		if (!empty($orderBy)) {
			foreach ($orderBy as $k => $v) {
				$this->db->order_by($k, $v);
			}
		} else {
			$this->db->order_by($this->primaryKey, "DESC");
		}

		if (!empty($groupBy)) {
			$this->db->group_by($groupBy);
		}

		if (!empty($custom)) {
			$this->db->where($custom);
		}

		if (!empty($join_table) && !empty($join_query)) {
			$this->db->join($join_table, $join_query);
		}


		$this->db->limit($limit, $start);
		$query = $this->db->get($this->table_name);

		//echo $this->db->last_query();
		//exit;

		if ($query->num_rows() > 0) {
			return $query->result_array();
		} else {
			return array();
		}
	}

	//insert a new data
	public function insert($data = array())
	{
		$this->db->insert($this->table_name, $data);
		$insert_id = $this->db->insert_id();
		return $insert_id;
	}

	//update a data
	public function update($where = array(), $array = array())
	{
		$this->db->where($where);
		$result = $this->db->update($this->table_name, $array);
		return $result;
	}

	//update a data
	public function update_wherein($where_in = array(), $where_in_col = "", $where = array(), $array = array())
	{

		if (!empty($where)) {
			$this->db->where($where);
		}
		if (!empty($where_in)) {
			$this->db->where_in($where_in_col, $where_in);
		}
		$result = $this->db->update($this->table_name, $array);
		return $result;
	}

	//"Delete" a data
	public function delete($where = array())
	{
		$data = array(
			'is_deleted' => 1,
		);
		$this->db->where($where);
		$this->db->update($this->table_name, $data);
	}

	//"Delete" a data
	public function forceDelete($where = array())
	{
		$this->db->where($where);
		$this->db->delete($this->table_name);
	}

	//get one data
	public function getOne($where, $order_by = "created_date", $ascdec = "DESC", $select = "*")
	{

		if ($select != "*") {
			$this->db->select($select);
		}
		$this->db->order_by($order_by, $ascdec);
		$this->db->limit(1, 0);
		$query = $this->db->get_where($this->table_name, $where);
		return $query->row_array();
	}

	//get more data
	public function get_where($where = array(), $like = array(), $order_by = "created_date", $ascdec = "DESC", $select = "*")
	{

		if ($select != "*") {
			$this->db->select($select);
		}
		$this->db->order_by($order_by, $ascdec);

		if (!empty($like)) {
			$this->db->group_start();
			$i = 0;
			foreach ($like as $k => $v) {
				if ($i == 0) {
					$this->db->like($k, $v);
				} else {
					$this->db->or_like($k, $v);
				}
				$i++;
			}
			$this->db->group_end();
		}
		$this->db->where($where);
		$query = $this->db->get($this->table_name);
		return $query->result_array();
	}



	public function get_where_groupby($where = array(), $order_by = "created_date", $ascdec = "DESC", $group_by = "", $select = "*", $or_where = array())
	{
		if ($select != "*") {
			$this->db->select($select);
		}
		$this->db->order_by($order_by, $ascdec);

		if (!empty($group_by)) {
			$this->db->group_by($group_by);
		}

		if (!empty($where)) {
			foreach ($where as $k => $v) {
				$this->db->where($k, $v);
			}
		}

		if (!empty($or_where)) {
			foreach ($or_where as $k => $v) {
				$this->db->or_where($k, $v);
			}
		}

		$query = $this->db->get($this->table_name);
		return $query->result_array();
	}

	public function get_wherein_groupby($where = array(), $where_in_col = "consignee_id", $where_in = array(), $group_by = "", $select = "*", $order_by = "created_date", $ascdec = "DESC", $or_where = array())
	{
		if ($select != "*") {
			$this->db->select($select);
		}
		$this->db->order_by($order_by, $ascdec);

		if (!empty($where_in)) {
			$this->db->where_in($where_in_col, $where_in);
		}

		if (!empty($group_by)) {
			$this->db->group_by($group_by);
		}

		if (!empty($where)) {
			foreach ($where as $k => $v) {
				$this->db->where($k, $v);
			}
		}

		if (!empty($or_where)) {
			foreach ($or_where as $k => $v) {
				$this->db->or_where($k, $v);
			}
		}

		$query = $this->db->get($this->table_name);
		return $query->result_array();
	}

	//to get a key=>value array
	public function getOptions($where = array(), $key = "id", $value = "title", $order_by = "created_date", $ascdec = "DESC")
	{

		$this->db->order_by($order_by, $ascdec);
		$list = $this->get_where($where);

		$tmp = array();

		if (!empty($list)) {
			foreach ($list as $v) {
				$tmp[$v[$key]] = $v[$value];
			}
		}

		return $tmp;
	}

	public function getSUM($column = "oz", $where = array())
	{

		$this->db->select("SUM(" . $column . ") AS total");
		$query = $this->db->get_where($this->table_name, $where);
		$data = $query->row_array();
		if (!empty($data['total'])) {
			return $data['total'];
		} else {
			return 0;
		}
	}

	public function getSUM_wherein($column = "oz", $where = array(), $where_in_col = "consignee_id", $where_in = array())
	{

		$this->db->select("SUM(" . $column . ") AS total");
		if (!empty($where_in)) {
			$this->db->where_in($where_in_col, $where_in);
		}
		$query = $this->db->get_where($this->table_name, $where);
		$data = $query->row_array();
		if (!empty($data['total'])) {
			return $data['total'];
		} else {
			return 0;
		}
	}

	public function get_wherein($where = array(), $where_in_col = "consignee_id", $where_in = array(), $select = "*", $order_by = "created_date", $ascdec = "DESC")
	{

		$this->db->select($select);

		if (!empty($where_in)) {
			$this->db->where_in($where_in_col, $where_in);
		}

		$this->db->order_by($order_by, $ascdec);

		$query = $this->db->get_where($this->table_name, $where);
		return $query->result_array();
	}

	public function get_wherein_join($where = array(), $where_in_col = "consignee_id", $where_in = array(), $select = "*", $join_table = "", $join_where = "", $order_by = "created_date", $ascdec = "DESC")
	{

		$this->db->select($select);

		if (!empty($where_in)) {
			$this->db->where_in($where_in_col, $where_in);
		}

		if (!empty($join_table) && !empty($join_where)) {
			$this->db->join($join_table, $join_where, 'left');
		}

		$this->db->order_by($order_by, $ascdec);

		$query = $this->db->get_where($this->table_name, $where);
		return $query->result_array();
	}

	public function get_cus($select = "", $where = "", $row = true)
	{
		$this->db->select($select);
		$this->db->where($where, NULL, false);
		$query = $this->db->get($this->table_name);
		if ($query->num_rows() > 0) {

			if ($row) {
				return $query->row_array();
			} else {
				return $query->result_array();
			}
		} else {
			return array();
		}
	}

	public function get_sumwherein($column = "", $where = array(), $where_in = array(), $where_in_id = "")
	{
		$this->db->select("SUM(" . $column . ") AS total");

		$this->db->where($where);

		if (!empty($where_in) && !empty($where_in_id)) {
			$this->db->where_in($where_in_id, $where_in);
		}
		$query = $this->db->get($this->table_name);

		if ($query->num_rows() > 0) {
			$row = $query->row_array();
			return $row['total'];
		} else {
			return 0;
		}
	}

	public function get_where_like($where = array(), $like = array(), $limit = "99999", $select = "*")
	{
		if ($select != "*") {
			$this->db->select($select);
		}
		$this->db->where($where);

		if (!empty($like)) {

			$i = 0;
			$this->db->group_start();
			foreach ($like as $k => $v) {
				if ($i == 0) {
					$this->db->like($k, $v);
				} else {
					$this->db->or_like($k, $v);
				}
				$i++;
			}
			$this->db->group_end();
		}
		$this->db->limit($limit, 0);

		$query = $this->db->get($this->table_name);
		if ($query->num_rows() > 0) {
			return $query->result_array();
		} else {
			return array();
		}
	}

	public function getIDKeyArray($column = "title", $where = array('is_deleted' => 0), $order_by = "", $ascdec = "DESC", $like = array(), $divider = " ")
	{
		$id_list = array();
		$list = $this->get_where($where, $like, $order_by, $ascdec);
		foreach ($list as $k => $v) {
			if (strpos($column, ",") !== FALSE) {
				$title = "";
				$tmp = explode(",", $column);
				$i = 0;
				foreach ($tmp as $v2) {
					if ($i == 0) {
						$title .= $v[$v2];
					} else {
						$title .=  $divider . $v[$v2];
					}

					$i++;
				}
			} else {
				$title = $v[$column];
			}

			$id_list[$v[$this->primaryKey]] = $title;
		}
		return $id_list;
	}

	public function getColKeyArray($column = "title", $where = array('is_deleted' => 0), $order_by = "", $ascdec = "DESC", $like = array())
	{
		$col_list = array();
		$list = $this->get_where($where, $like, $order_by, $ascdec);
		foreach ($list as $k => $v) {
			$title = $v[$column];
			$col_list[$title] = $v[$this->primaryKey];
		}

		return $col_list;
	}



	public function getCusIDKeyArray($key = "id", $column = "title", $where = array('is_deleted' => 0), $order_by = "", $ascdec = "DESC", $like = array(), $divider = " ")
	{
		$id_list = array();
		$list = $this->get_where($where, $like, $order_by, $ascdec);

		foreach ($list as $k => $v) {

			if (strpos($column, ",") !== FALSE) {
				$title = "";
				$tmp = explode(",", $column);
				$i = 0;
				foreach ($tmp as $v2) {
					if ($i == 0) {
						$title .= $v[$v2];
					} else {
						$title .=  $divider . $v[$v2];
					}

					$i++;
				}
			} else {
				$title = $v[$column];
			}

			$id_list[$v[$key]] = $title;
		}

		return $id_list;
	}

	public function objectToArray($id_list)
	{

		$tmp = array();
		if (!empty($id_list)) {
			foreach ($id_list as $k => $v) {
				$tmp[] = array(
					'id' => $k,
					'title' => $v,
				);
			}
		}
		return $tmp;
	}

	public function getRecursivelist($parent_col = "parent_id", $parent_value = "0", $where = array(), $like = array(), $order_by = "created_date", $ascdec = "DESC", $select = "*")
	{
		$where[$parent_col] = $parent_value;
		$list = $this->get_where($where, $like, $order_by, $ascdec, $select);

		if (!empty($list)) {
			foreach ($list as $k => $v) {
				//print_r($v[$parent_col]);
				$list[$k]['child'] = $this->getRecursivelist($parent_col, $v[$this->primaryKey], $where, $like, $order_by, $ascdec, $select);
			}
		}
		return $list;
	}

	public function batch_update($data = array(), $key = false)
	{
		if (!$key) {
			$key = $this->primaryKey;
		}
		if (!empty($data)) {
			$this->db->update_batch($this->table_name, $data, $key);
		}
	}

	public function batch_insert($data = array())
	{

		if (!empty($data)) {
			$this->db->insert_batch($this->table_name, $data);
		}
	}

	public function optimize_table()
	{

		$this->load->dbutil();
		$this->dbutil->optimize_table($this->table_name);
	}

	public function true_actual_delete($where = array())
	{
		$this->db->where($where);
		$this->db->delete($this->table_name);
	}

	public function reorder_auto_increment()
	{
		$fields = $this->db->list_fields($this->table_name);
		$pos = array_search($this->primaryKey, $fields);
		unset($fields[$pos]);
		$all_Data = $this->get_where(array(), array(), $this->primaryKey, "ASC",  implode(",", $fields));
		$data_array = array();
		if (!empty($all_Data)) {
			$this->db->truncate($this->table_name);
			sleep(2);
			//$this->optimize_table();
			$this->batch_insert($all_Data);

			// $this->db->truncate($this->table_name);
			// $this->optimize_table();
			// $i = 0;
			// foreach ($all_Data as $v) {
			//   $i++;
			//   $data_array[] = $v;
			//   if ($i == 5000) {
			//     if (!empty($data_array)) {
			//       $this->batch_insert($data_array);
			//     }

			//     $data_array = array();
			//     $i = 0;
			//   }
			// }
			// if (!empty($data_array)) {
			//   $this->batch_insert($data_array);
			// }
		}
	}

	//get more data
	public function get_custom_query($select = "*", $where = "")
	{
		$this->db->select($select);
		$this->db->where($where);
		$query = $this->db->get($this->table_name);
		return $query->result_array();
	}

	public function full_custom_query($query)
	{
		$query = $this->db->query($query);
		return $query->result_array();
	}


	public function get_random_data($where = "", $limit = 25)
	{
		$this->load->database();

		$this->db->where($where);
		$this->db->order_by('RAND()');
		$this->db->limit($limit);
		$query = $this->db->get($this->table_name);
		$result = $query->result_array();

		return $result;
	}
}
