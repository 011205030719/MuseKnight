<?php $this->load->view("teacher/nav"); ?>
<?php $this->load->view("layouts/header"); ?>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/dt/jq-2.1.4,jszip-2.5.0,pdfmake-0.1.18,dt-1.10.9,af-2.0.0,b-1.0.3,b-colvis-1.0.3,b-html5-1.0.3,b-print-1.0.3,se-1.0.1/datatables.min.css"/>

<style>
    .custom-module{
        margin-top: -10px; 
        margin-bottom: 20px; 
        background-color: #703be7; 
        height: 40px; 
        width: 300px; 
        display: flex; 
        justify-content: center; 
        align-items: center; 
        position: relative; 
        border-radius: 25px; 
        color: #fff; 
        text-align: left;
        font-size: 18px;
    }
    .gender_status{
        color: white;
        font-size:12px;
        font-weight:600;
        padding-top:3px;
        padding-bottom:5px;
        padding-left:10px;
        padding-right:10px;
        border-radius:10px;
    }
    
    /* .custom-module:hover{
        background-color: #422387; 
    } */
</style>

<div class="container-fluid" style="padding-left: 20%; padding-right: 5%; padding-top: 3%;">
    <div style="position: sticky; top: 0; z-index: 1000; background-color:#E6E6FA; border: 0px solid rgba(100, 100, 100, 1); border-radius: 12px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); padding: 10px; margin: 1%;">
        <span style="color:gray;">Home / </span>
        <a href="<?= base_url($folder_name.'/student/list') ?>" style="text-decoration:none; color:black;">Student List</a>
    </div>
        <div class="card shadow">
            <div style="padding: 30px;">
                <div style="overflow-x: auto;" class="table-container">
                    <table id="lecturerTable"style="background-color: white; max-height: 400px; overflow-x: auto; display: block;" class="table table-bordered">
                        <thead>
                            <tr>
                                <th style="padding:5px 40px; width: 5%;">ID</th>
                                <th style="padding:5px 60px; width: 30%;">Student</th>
                                <th style="padding:5px 40px; width: 20%;">Subject</th>
                                <th style="padding:5px 40px; width: 20%;">Class Level</th>
                                <th style="padding:5px 40px; width: 20%;">Subject Fee</th>
                                <th style="padding:5px 60px; width: 30%;">Day</th>
                                <th style="padding:5px 80px; width: 40%;">Time Range</th>
                                <th style="padding:5px 100px; width: 50%;">Created Date</th>
                                <!-- <th style="padding:5px 100px; width: 50%;">Action</th> -->
                            
                            
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($student_subjects as $key=>$student_subject) { ?>
                                <?php if ($student_subject['teacher_id'] == $teacher_id) { ?>
                                    <!-- Add this condition to display records associated with the teacher -->
                                    <tr class="table_row">
                                        <th scope="row"><?= $key + 1 ?></th>
                                        <td style="width:30%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                            <?php
                                            $lesson_student = '';
                                            foreach ($students as $student) {
                                                if ($student['id'] == $student_subject['student_id']) {
                                                    $lesson_student = $student['name'];
                                                }
                                            }
                                            echo $lesson_student;  // Display subject title
                                            ?>
                                        </td>

                                        <td style="width:20%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                            <?php
                                            $subject_name = ''; // Initialize the subject name
                                            foreach ($subjects as $subject) {
                                                if ($subject['id'] == $student_subject['subject_id']) {
                                                    $subject_name = $subject['title'];
                                                    break; // Exit the loop once subject_name is found
                                                }
                                            }
                                            echo $subject_name; // Display subject name
                                            ?>
                                        </td>
                                        <td style="width:20%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                            <?php
                                            $grade_level = '';
                                            foreach ($students as $student) {
                                                if ($student['id'] == $student_subject['student_id']) {
                                                    $grade_level = $student_subject['grade_level'];
                                                }
                                            }
                                            echo $grade_level;  // Display subject title
                                            ?>
                                        </td>
                                        <td style="width:20%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                            <?php
                                            $subject_fees = '';
                                            foreach ($students as $student) {
                                                if ($student['id'] == $student_subject['student_id']) {
                                                    $subject_fees = $student_subject['fee'];
                                                }
                                            }
                                            echo $subject_fees;  // Display subject title
                                            ?>
                                        </td>
                                        <td style="width:30%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $student_subject['day'] ?></td>
                                        <td style="width:30%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $student_subject['time_range'] ?></td>
                                        <td style="width:50%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= date('Y-m-d', strtotime($student_subject['created_date'])) ?></td>
                                    </tr>
                                <?php } ?>
                            <?php } ?>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>
</div>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- DataTables and Bootstrap DataTables -->
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<!-- DataTables library -->
<script type="text/javascript" src="https://cdn.datatables.net/r/dt/jq-2.1.4,jszip-2.5.0,pdfmake-0.1.18,dt-1.10.9,af-2.0.0,b-1.0.3,b-colvis-1.0.3,b-html5-1.0.3,b-print-1.0.3,se-1.0.1/datatables.min.js"></script>

<script>
      
    $(document).ready(function() {

        // Attach click event to delete buttons
        $('.delete-btn').click(function () {
            // Get the teacher ID from the data-id attribute
            var teacherId = $(this).data('id');

            // Set the teacher ID in the modal form action
            $('#deleteForm').attr('action', 'admin/teacher/delete/' + teacherId);

            // Show the confirmation modal
            $('#deleteModal').modal('show');
        });

        $('#lecturerTable').DataTable({
            dom: 'lBfrtip',
            lengthMenu: [10, 25, 50],
            searching: true,
            buttons: [
                {
                    extend: 'excel',
                    text: 'Download Data',
                    className: 'btn btn-outline-success',
                    init: function(api, node, config) {
                        $(node).removeClass('dt-button');
                        $(node).css({
                            'margin-left': '10%',
                            'margin-bottom': '10%',
                            'height': '30px',
                            'width': '150px',
                            'font-size': '17px',
                            'display': 'flex',
                            'align-items': 'center'
                        });
                    }
                }
            ]
        });
    });
    </script>
