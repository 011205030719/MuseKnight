<?php $this->load->view("admin/nav"); ?>
<?php $this->load->view("layouts/header"); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
    google.charts.load('current', {'packages':['corechart']});
    google.charts.setOnLoadCallback(drawChart);

    function drawChart() {
        // Use the PHP array directly without json_encode
        const chart_data  = <?= $subject_fee_data ?>;

        // Log the data to the console for inspection
        console.log(chart_data);

        // Add column headers
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Subject');
        data.addColumn('number', 'Total Fee');

        // Populate the chart data
        chart_data.forEach(function(item) {
            data.addRow([item.subject_title, {v: parseFloat(item.total_fee), f: 'RM ' + parseFloat(item.total_fee).toFixed(2)}]);
        });

        var options = {
    title: 'Subject Sales',
    titleTextStyle: {
        fontSize: 16,  // Set the desired font size
          // Optionally make the title bold
    },
    chartArea: {
        top: '15%',    // Adjust the top margin to position the title at the top-middle
        height: '70%' ,
        width:'50%;' // Adjust the height of the chart area
    }
};
        var chart = new google.visualization.PieChart(document.getElementById('piechart'));
        chart.draw(data, options);

        console.log(typeof chart_data);
        console.log(chart_data);
    }
</script>









<style>
    .custom-module{
        margin-top: -10px; 
        margin-bottom: 20px; 
        background-color: #703be7; 
        height: 40px; 
        width: 350px; 
        display: flex; 
        justify-content: center; 
        align-items: center; 
        position: relative; 
        border-radius: 25px; 
        color: #fff; 
        text-align: left;
        font-size: 18px;
    }

    .custom-module:hover{
        background-color: #422387; 
    }

    .custom-hover:hover{
        background: linear-gradient(135deg, rgb(206, 159, 252) 10%, rgb(115, 103, 240) 100%);
        color: #fff;
        transform: translateY(-15px); /* Move the column up by 5 pixels on hover */
      transition: transform 0.3s ease;
    }
    .element {
    border: 0px solid rgba(100, 100, 100, 1);
    border-radius: 12px;
    color: rgba(255, 255, 255, 0.5);
  }
    .status {
        color: white;
        font-size: 12px;
        font-weight: 600;
        padding-top: 3px;
        padding-bottom: 5px;
        padding-left: 10px;
        padding-right: 10px;
        border-radius: 10px;
    }

</style>

<div class="dashboard" style="padding-left:20%;">
    <div class="container-fluid">
        <div class="card-header" style="position: sticky; top: 0; z-index: 1000; background-color:#E6E6FA; border: 0px solid rgba(100, 100, 100, 1); border-radius: 12px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); padding: 10px; margin: 1%;">
            <div style="font-weight:600;">
                <span style="color:gray;">Home / </span>
                <a href="<?= base_url($folder_name.'/dashboard') ?>" style="text-decoration:none; color:black;">Dashboard</a>
            </div>
        </div>



            <div class="card">
                <div class="card-body element" style="background-color: rgba(6, 47, 209, 0.05);">
                    <div class="row">
                        <div class="col-md-8">
                            <h1 style="color: black; font-family:Lucida Handwriting, cursive; margin-top:6%; ">Hi  <?= $userdata['name'] ?></h1>
                            <h1 style="color: black; font-family:URW Chancery L, cursive; margin-top:3%; ">Welcome Our MuseKnight </h1>
                            <p style="color: black; font-size:medium; font-style:italic; margin-top: 5%;" >Welcome to our web-based hub designed to enhance your learning experience. Tailored for both new and returning students, this system streamlines academic tasks, making your journey smoother.</p>
                        </div>
                        <div class="col-md-4">
                            <img src="<?= base_url('assets/img/first.png') ?>" class="img-fluid" alt="Image">
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-4" style="padding: 20px;">
                        <div class="card shadow custom-hover" style="padding: 20px;">
                            <div class="card-item d-flex justify-content-between">
                                <div>
                                    <div><?php echo $total_active_students; ?></div>
                                    <div>Total Active Students</div>
                                </div>
                                <div><i class="bi bi-person-badge-fill" style="font-size: 50px;"></i></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-4" style="padding: 20px;">
                        <div class="card shadow custom-hover" style="padding: 20px;">
                            <div class="card-item d-flex justify-content-between">
                                <div>
                                    <div><?php echo $total_active_teachers; ?></div>
                                    <div>Total Teacher</div>
                                </div>
                                <div><i class="bi bi-person" style="font-size: 50px;"></i></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-4" style="padding: 20px;">
                        <div class="card shadow custom-hover" style="padding: 20px;">
                            <div class="card-item d-flex justify-content-between">
                                <div>
                                    <div>RM <?php echo number_format($total_active_sales_amount, 2); ?></div>
                                    <div>Sales</div>
                                </div>
                                <div><i class="bi bi-cash-coin" style="font-size: 50px;"></i></div>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="col-3" style="padding: 20px;">
                        <div class="card shadow custom-hover" style="padding: 20px;">
                            <div class="card-item d-flex justify-content-between">
                                <div>
                                    <div>RM <?php echo number_format($total_active_teacher_salary_amount, 2); ?></div>
                                    <div>Expense</div>
                                </div>
                                <div><i class="bi bi-currency-dollar" style="font-size: 30px;"></i></div>
                            </div>
                        </div>
                    </div> -->
                </div>
            </div>

            <!-------------------- Chart --------------------------------> 
            <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
            <div class="row">
                <div class="col-sm-6">
                    <div class="card shadow">
                    <div class="card-body">
                        <div id="myPlot" style="width:100%;max-width:700px"></div>
                    </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="card">
                    <div class="card-body">
                    <div id="piechart" style="width: 500px; height: 400px;"></div>
                    
                    </div>
                    </div>
                </div>
            </div>
            <!----------------------- Information List -----------------------> 
            <div class="row">
                <div class="col-7" style="padding: 10px;">
                    <div class="card shadow" style="padding: 20px;">
                        <div class="card-header">
                            <div class="d-flex justify-content-between">
                                <div style="font-weight: 700; font-size: 20px">Student Payment</div>
                                <a href="<?= base_url('admin/payment/list')?>" class="btn btn-primary text-light btn-sm">More Details</a>
                            </div>
                        </div>
                        <div class="selected_table">
                            <table style="background-color: white; width:100%;">
                                <thead>
                                    <tr style="border-bottom: 2px solid lightgray;">
                                        <th style="padding:5px 10px; width: 5%;">Serial</th>
                                        <th style="padding:5px 10px; width: 5%;">Student Name</th>
                                        <th style="padding:5px 10px; width: 5%;">Month</th>
                                        <th style="padding:5px 10px; width: 5%;">Total Amount</th>
                                        <th style="padding:5px 10px; width: 5%;">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $count = 0; ?>
                                    <?php foreach ($sales as $sale): ?>
                                        <?php
                                        $user_id = $sale['student_id'];
                                        $payment_serial = $sale['serial'];
                                        $payment_serial = $payment_serial !== '' ? $payment_serial : 'No Payment Available';
                                        ?>

                                        <?php if ($sale['status'] != 1&& $count < 5): ?>
                                            <?php $count++; ?>
                                            <tr class="table_row">
                                                <td style="width:5%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $sale['serial'] ?></td>
                                                <td style="width:5%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                                    <?php
                                                        $student_id = $sale['student_id'];
                                                        $student_name = '';
                                                        foreach ($students as $student) {
                                                            if ($student['id'] == $student_id) {
                                                                $student_name = $student['name'];
                                                                break;
                                                            }
                                                        }
                                                        echo $student_name;
                                                    ?>
                                                </td>
                                                <td style="width:5%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $sale['month'] ?></td>
                                                <td style="width:5%; padding-left:10px; padding-top:8px; padding-bottom:8px;">RM <?= $sale['total_amount'] ?></td>
                                                <td style="width:5%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                                    <?php
                                                    $status = $sale['status'];

                                                    if ($status == 0) {
                                                        echo '<span style="color: red;">Not Paid</span>';
                                                    } elseif ($status == 2) {
                                                        echo '<span style="color: orange;">Pending</span>';
                                                    } else {
                                                        echo '<span style="color: gray;">Unknown Status</span>';
                                                    }
                                                    ?>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-----------------------Teacher List --------------------------------------->
                <div class="col-5" style="padding: 10px;">
                    <div class="card shadow">
                        <div class="card-list" style="padding: 20px;">
                            <div class="card-header">
                                <div class="d-flex justify-content-between">
                                    <div style="font-weight: 700; font-size: 20px">Teacher</div>
                                    <a href="<?= base_url('admin/teacher/list')?>" class="btn btn-primary text-light btn-sm">More Details</a>
                                </div>
                            </div>
                            <div class="selected_table">
                                <table style="background-color: white; width:100%;">
                                    <tbody>
                                        <?php foreach($teachers as $teacher): ?>
                                            <tr class="table_row">
                                                <td>
                                                    <?php if ($teacher['image']): ?>
                                                        <?php
                                                        $imagePath = base_url("assets/img/profiles/{$teacher['image']}");
                                                        ?>
                                                        <img style="width:40px; height:40px; border-radius:50%;" src="<?= $imagePath ?>" alt="Teacher Image">
                                                    <?php else: ?>
                                                        <!-- Add a default image or placeholder if no image is available -->
                                                        <img style="width:40px; height:40px;" src="<?= base_url('assets/profile/default.jpg') ?>" alt="Default Image">
                                                    <?php endif; ?>
                                                </td>


                                                <td><?= $teacher['name'] ?></td>
                                                <td>
                                                    <?php
                                                        // Create an associative array to store subject titles for each teacher
                                                        $teacherSubjectTitles = [];

                                                        // Find the subject titles for the current teacher
                                                        foreach ($this->data['teacher_subjects'] as $teacherSubject) {
                                                            if ($teacherSubject['teacher_id'] == $teacher['id']) {
                                                                $subjectId = $teacherSubject['subject_id'];
                                                                
                                                                // Find the subject title based on subject_id
                                                                foreach ($this->data['subjects'] as $subject) {
                                                                    if ($subject['id'] == $subjectId) {
                                                                        // Add the subject title to the current teacher's array
                                                                        $teacherSubjectTitles[] = $subject['title'];
                                                                        break;
                                                                    }
                                                                }
                                                            }
                                                        }

                                                        // Display the subject titles for the current teacher
                                                        echo implode(', ', $teacherSubjectTitles);
                                                        ?>
                                                </td>

                                                <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                                    <?php if($teacher['status'] == 0){?>
                                                        <span class="status" style="background-color:limegreen;">Active</span>
                                                    <?php }else{ ?>
                                                        <span class="status" style="background-color:orange;">Inactive</span>
                                                    <?php } ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!----------------------------------------------------------posted announcement---------------------------------------------------------->
            <div class="col" style="padding: 10px;">
                <div class="card shadow">
                    <div class="card-list" style="padding: 20px;">
                        <div class="card-header">
                            <div class="d-flex justify-content-between">
                                <div style="font-weight: 700; font-size: 20px">Announcement</div>
                                <a href="<?= base_url('admin/annoucement/subjectList')?>" class="btn btn-primary text-light btn-sm">More Details</a>
                            </div>
                        </div>
                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade show active" id="annoucment" role="tabpanel" aria-labelledby="annoucment-tab">
                                <?php if($annoucements) {
                                    foreach ($annoucements as $announcement) { ?>
                                        <div class="card announcement-card" style="border-radius: 5px; position: relative; margin-top:1%;">
                                            <div class="card-body">
                                                <div style="display:flex; justify-content:start; align-items:center;">
                                                    <div style="width: 50px; height: 50px; border-radius: 50%; background-color: #3498db; text-align: center; line-height: 50px; color: #fff; font-size:10px;"><?= $announcement['sender_type'] ?></div>
                                                    <div style="margin-left:10px;">
                                                        <div style="font-size:15px; font-weight:600;"><?= $announcement['senderName'] ?></div>
                                                        <div style="font-size:12px;"><?= date('M d, Y (h:i a)', strtotime($announcement['created_date'])) ?></div>
                                                    </div>
                                                </div>
                                                <br>
                                                <h5 class="card-title"><?= $announcement['title'] ?></h5>
                                                <p class="card-text"><?= $announcement['description'] ?></p>

                                                <!-- Display Subject Title in the upper right -->
                                                <div style="position: absolute; top: 0; right: 0; padding: 20px;">
                                                    <span style="background-color: #7B68EE; color: #fff; font-weight:bold ; padding: 3px 5px; border-radius: 10px; font-size:12px;">
                                                        <?= $announcement['subject_title'] ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    <?php }
                                } else { ?>
                                    <div style="width:100%; text-align:center; padding:20px;">There is no announcement posted on this subject.</div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script>
    const subjectData = <?= $subject_student_counts ?>; // Assuming $subject_student_counts is a JSON-encoded string

    const xArray = subjectData.labels;
    const yArray = subjectData.values;

    const layout = {
        title: "Student",
        height: 400, // Specify the height of the chart
        width: 500,  // Specify the width of the chart
    };

    const data = [{labels: xArray, values: yArray, type: "pie"}];

    Plotly.newPlot("myPlot", data, layout);
</script>

<!-- <script>
    // Ensure the colors variable is defined
    var colors = ['#4CAF50', '#FFC107', '#2196F3', '#FF5722', '#E91E63', '#9C27B0', '#795548', '#607D8B'];

    var options = {
        series: [{
            data: [21, 22, 10, 28,10]
        }],
        chart: {
            height: 350,
            type: 'bar',
            events: {
                click: function (chart, w, e) {
                    // console.log(chart, w, e)
                }
            }
        },
        colors: colors,
        plotOptions: {
            bar: {
                columnWidth: '45%',
                distributed: true,
            }
        },
        dataLabels: {
            enabled: false
        },
        legend: {
            show: false
        },
        xaxis: {
            categories: [
                ['Piano'],
                ['Violin'],
                ['Cello'],
                ['Guitar'],
                ['Ukulele']
            ],
            labels: {
                style: {
                    colors: colors,
                    fontSize: '12px'
                }
            }
        }
    };

    var chart = new ApexCharts(document.querySelector("#chart"), options);

    // Render the chart after the document is fully loaded
    document.addEventListener('DOMContentLoaded', function () {
        chart.render();
    });
</script> -->
