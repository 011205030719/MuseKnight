<!DOCTYPE html>
<html>
<head>
</head>
<body>

<div>
    <span>Checking for database: </span>
    <span><?= $user['name'] ?></span>
</div>
</body>
</html>