<?php $this->load->view("student/nav"); ?>
<?php $this->load->view("layouts/header"); ?>

<div class="border" style="padding:5% 2% 5% 20%;">
    <?php if($Incompleted_sale){ ?>
    <div style="border-radius: 10px; border:1.5px solid lightgray; padding: 20px; width: 100%;">
        <div style="border-radius: 10px; border:1.5px solid lightgray; padding: 20px; width: 100%; display:flex; align-items:center;">
            <div style="color: black; font-size:30px; margin-right:15px;"><i class="bi bi-exclamation-circle"></i></div>
            <div>
                <div style="font-weight:700;">Incomplete payment <?= date("F Y") ?></div>
                <div>Please submit payment before the end of this month.</div>
            </div>
        </div>
        <div style="display: flex; padding:0 5%;">
            <div style="width:50%; padding-top:15px;">
                <div style="font-weight: 700; padding-bottom:10px; border-bottom:1.5px solid lightgray; margin-top:25px;">Summary Payment</div>
                <?php foreach($Incompleted_sale_detail as $key => $subject){ ?>
                <div style="padding: 5px 5%; display:flex; justify-content:space-between;">
                    <div>Subject <?= $key + 1 ?> - <span style="font-weight: 700;"><?= $subjects[$subject['subject_id']] ?></span></div>
                    <div>RM <?= $subject['fee'] ?></div>
                </div>
                <?php } ?>
                <div style="padding-top:10px; border-top:1.5px solid lightgray;">Total Amount: RM <?= $Incompleted_sale['total_amount'] ?></div>
                <div></div>
            </div>
            <div style="width:50%; padding:20px;">
                <div style="border:1.5px solid lightgray; border-radius:5px; padding:20px;">
                    <form method="POST" action="<?=base_url('student/payment/submit_payment')?>" enctype="multipart/form-data" onsubmit="return validateForm();">
                        <div style="padding-bottom: 10px; border-bottom:1.5px solid lightgray; font-weight:700; margin-bottom:10px;">Make a Payment</div>
                        <div style="display: flex; justify-content:space-between; align-items:center;">
                            <div>Payment Method</div>
                            <div style="width: 40%;">
                                <select name="payment_method" id="contentSelector" onchange="showContent()" class="form form-select">
                                    <option value="" disabled selected>Select Method</option>
                                    <option value="tng">Touch&Go(TNG)</option>
                                    <option value="fpx">Online Bank Transfer(FPX)</option>
                                </select>
                            </div>
                        </div>
                        <div style="display: flex; justify-content:space-between; align-items:center; padding-top:10px;">
                            <div>Payment Date</div>
                            <div><?= date("d F, Y") ?></div>
                        </div>
                        <div id="tng" class="payment_detail" style="display:none; padding:15px 0; margin-top:10px; border-top:1.5px solid lightgray; border-bottom:1.5px solid lightgray;">
                            <div style="display: flex; align-items:center;">
                                <img style="width: 15%;" src="<?=base_url('assets/img/tng.png')?>" alt="">
                                <div style="padding-left: 10px;">
                                    <div style="font-weight: 700; font-size:20px;">TouchNGo Ewallet</div>
                                    <div style="font-size: 13px;">Please Scan this QR code to make a transfer.</div>
                                </div>
                            </div>
                            <div style="width: 50%; margin-left:auto; margin-right:auto; padding: 15px; border:1.5px solid lightgray; border-radius:10px;">
                                <img style="width: 100%;" src="<?=base_url('assets/img/QRcode.png')?>" alt="">
                            </div>
                        </div>
                        <div id="fpx" class="payment_detail" style="display:none; padding:15px 0; margin-top:10px; border-top:1.5px solid lightgray; border-bottom:1.5px solid lightgray;">
                            <div style="display: flex; align-items:center;">
                                <img style="width: 15%;" class="shadow" src="<?=base_url('assets/img/fpx.jpg')?>" alt="">
                                <div style="padding-left: 10px;">
                                    <div style="font-weight: 700; font-size:20px;">FPX Online Banking</div>
                                    <div style="font-size: 13px;">Copy this code to your preferred bank for the transaction.</div>
                                </div>
                            </div>
                            <div style="width: 60%; margin:10px auto 0 auto; padding: 15px; border:1.5px solid lightgray; border-radius:10px;">
                                Transaction Code : <span style="font-weight: 700;">0123456789</span>
                            </div>
                        </div>
                        <div id="upload_invoice" style="padding-top:10px; display:none;">
                            <div style="font-weight: 600;">Payment Invoice (PNG/JPEG)</div>
                            <div style="font-size: 12px; margin-bottom:10px;">Upload your payment receipt to prove the transaction.</div>
                            <div>
                                <input type="file" name="image" id="fileInput">
                            </div>
                        </div>
                        <div style="text-align: end; margin-top:20px; padding-top:10px; border-top:1.5px solid lightgray;">
                            <button class="btn btn-primary">Pay Now</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php } ?>
    <div>
        <div style="font-weight:700; font-size:25px; margin-top:20px; padding-bottom:10px; border-bottom:2px solid lightgray;">Payment History</div>
        <?php if($sales){ ?>
            <?php foreach($sales as $sale){ ?>
            <div style="margin-top:15px; border-radius: 10px; border:1.5px solid lightgray; padding:20px;">
                <div style="display: flex; align-items:center; width:100%;">
                    <div style="width: 10%; border-radius: 5px; margin-right:10px; justify-content:center; font-weight:700; color:white; display:flex; align-items:center; background-color:orange; width:50px; height:50px; text-transform: uppercase;"><?= $sale['payment_method'] ?></div>
                    <div style="width: 55%;">
                        <div style="font-weight: 800;"><?= $sale['month'] ?> 2023</div>
                        <div style="font-size: 14px;">Payment Date: <?= $sale['payment_date'] ?></div>
                    </div>
                    <div style="width:15%;">
                        <button class="btn btn-primary" data-toggle="modal" data-target="#ViewPaymentSlip">Payment Slip</button>
                        <!-- Modal -->
                        <div class="modal fade" id="ViewPaymentSlip" tabindex="-1" role="dialog" aria-labelledby="ViewPaymentSlipTitle" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered" style="max-width: 60%;" role="document">
                                <div class="modal-content">
                                    <img src="<?=base_url('assets/img/payment_invoice/'.$sale['image'])?>" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="width: 10%; text-align:center; border-radius:5px; padding:5px 10px; background-color: <?= $sale['status'] === '1' ? 'green' : 'yellow' ?>; font-weight:600; color:<?= $sale['status'] === '1' ? 'white' : 'black' ?>;"><?= $sale['status'] === '1' ? 'Completed' : 'Pending' ?></div>
                    <div style="width: 10%; text-align:center;">RM 999.00</div>
                </div>
            </div>
            <?php } ?>
        <?php }else{ ?>
            <div style="text-align: center; padding:20px;">There is no payment record currently.</div>
        <?php } ?>
    </div>

</div>
<script>
    function showContent() {
        var select = document.getElementById("contentSelector");
        var selectedOption = select.options[select.selectedIndex].value;
        var contentDivs = document.getElementsByClassName("payment_detail");
        var upload_invoice = document.getElementById("upload_invoice");

        for (var i = 0; i < contentDivs.length; i++) {
            if (contentDivs[i].id === selectedOption) {
                contentDivs[i].style.display = "block";
                upload_invoice.style.display = "block";
            } else {
                contentDivs[i].style.display = "none";
            }
        }
    }
    function validateForm() {
        var fileInput = document.getElementById('fileInput');
        if (fileInput.files.length === 0) {
            alert('Please select a file to upload.');
            return false;
        }
        return true;
    }
</script>