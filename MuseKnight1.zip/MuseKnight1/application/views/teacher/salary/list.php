<?php $this->load->view("teacher/nav"); ?>
<?php $this->load->view("layouts/header"); ?>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>


<style>
    .invoice-button {
    background-color: #00FA9A;
    color: #fff;
    /* Add any additional styling as needed */
}

</style>

<div class="border" style="padding:5% 2% 5% 20%;">
    <div>
        <div style="font-weight:700; font-size:25px; margin-top:20px; padding-bottom:10px; border-bottom:2px solid lightgray;">Salary History</div>
        <?php if($salarys && count($salarys) > 0){ ?>
            <?php $teacherHasSalary = false; ?>
            <?php foreach($salarys as $key => $salary){ ?>
                <?php if($salary['teacher_id'] == $teacher_id){ ?>
                    <?php $teacherHasSalary = true; ?>
                    <div style="margin-top:15px; border-radius: 10px; border:1.5px solid lightgray; padding:20px;">
                        <div style="display: flex; align-items:center; width:100%;">
                            <div style="width: 10%; border-radius: 5px; margin-right:10px; justify-content:center; font-weight:700; color:white; display:flex; align-items:center; background-color:orange; width:50px; height:50px; text-transform: uppercase;"></div>
                            <div style="width: 55%;">
                                <div style="font-weight: 800;"><?= $salary['month'] ?> 2023</div>
                                <div style="font-size: 14px;">Payment Date: <?= $salary['receipt_date'] ?></div>
                            </div>
                            <div style="width:20%; display: flex; justify-content: space-between;">
                                <button class="btn btn-primary" data-toggle="modal" data-target="#ViewPaymentSlip<?= $key ?>">Salary Slip</button>
                                <a href="<?= base_url('teacher/salary/invoice/' . $salary['id']) ?>" target="_blank" class="btn receipt-button invoice-button">Invoice</a>
                                <br>
                                <!-- Modal -->
                                <div class="modal fade" id="ViewPaymentSlip<?= $key ?>" tabindex="-1" role="dialog" aria-labelledby="ViewPaymentSlipTitle" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered" style="max-width: 60%;" role="document">
                                        <div class="modal-content">
                                            <img src="<?=base_url('assets/img/payment_invoice/'.$salary['receipt'])?>" alt="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div style="width: 10%; text-align:center; border-radius:5px; padding:5px 10px; background-color: <?= $salary['status'] === '1' ? 'green' : 'red' ?>; font-weight:600; color:<?= $salary['status'] === '1' ? 'white' : 'white' ?>;"><?= $salary['status'] === '1' ? 'Completed' : 'Unpaid' ?></div>
                        </div>
                    </div>
                <?php } ?>
            <?php } ?>
            <?php if (!$teacherHasSalary) { ?>
                <div style="text-align: center; padding:20px;">There is no salary record currently.</div>
            <?php } ?>
        <?php } else { ?>
            <div style="text-align: center; padding:20px;">There is no salary record currently.</div>
        <?php } ?>
    </div>
</div>


<script>
    function showContent() {
        var select = document.getElementById("contentSelector");
        var selectedOption = select.options[select.selectedIndex].value;
        var contentDivs = document.getElementsByClassName("payment_detail");
        var upload_invoice = document.getElementById("upload_invoice");

        for (var i = 0; i < contentDivs.length; i++) {
            if (contentDivs[i].id === selectedOption) {
                contentDivs[i].style.display = "block";
                upload_invoice.style.display = "block";
            } else {
                contentDivs[i].style.display = "none";
            }
        }
    }
    function validateForm() {
        var fileInput = document.getElementById('fileInput');
        if (fileInput.files.length === 0) {
            alert('Please select a file to upload.');
            return false;
        }
        return true;
    }
</script>