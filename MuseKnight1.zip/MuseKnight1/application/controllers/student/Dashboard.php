<?php

class Dashboard extends MY_Controller {

    // Predefine function in controller

	public function __construct()
{
    parent::__construct();
    $this->data['folder_name'] = 'student';
    $this->load->model("Admin_model");
    $this->load->model("StudentSubject_model");
    $this->load->model("Student_model");
    $this->load->model("Sales_model");
    $this->load->model("Salary_model");
    $this->load->model("Annoucement_model"); 
    $this->load->model("TeacherSubject_model"); 
    $this->load->model("Teacher_model");
    $this->auth_validate();
}


public function index() {
    $studentId = $this->session->userdata('user_id');
    $this->data['students'] = $this->Student_model->get_where(array('is_deleted' => 0));
    $this->data['subjects'] = $this->Subject_model->get_where(array('is_deleted' => 0));
    $this->data['student_subjects'] = $this->StudentSubject_model->get_where(array('student_id' => $studentId, 'is_deleted' => 0));

    // Get the current day
    $currentDay = date('l');

    // Filter student_subjects based on the current day
    $filteredStudentSubjects = array_filter($this->data['student_subjects'], function ($subject) use ($currentDay) {
        return strtolower($subject['day']) == strtolower($currentDay);
    });

    // Pass the filtered student_subjects to the view
    $this->data['filtered_student_subjects'] = $filteredStudentSubjects;

    // Pass the student_id to the view
    $this->data['student_id'] = $studentId;

   // Fetch sales data for the logged-in student with status "0" or "2"
    $sales = $this->Sales_model->get_sales_with_status($studentId);

    // Calculate total sales and check status
    $totalSales = 0;
    $status = 'Pending'; // Set a default status

    foreach ($sales as $sale) {
        $totalSales += $sale['total_amount'];
        // Update status based on the status of the first sale (assuming status is the same for all sales)
        $status = $sale['status'] == 1 ? 'Paid' : 'Pending';
    }

    // Set the data to be passed to the view
    $this->data['totalSales'] = 'RM ' . number_format($totalSales, 2);
    $this->data['status'] = $status;
    $this->data['sales'] = $sales; // Pass the sales data to the view


    // Get the subjects related to the student
    $studentSubjects = $this->StudentSubject_model->get_where(array('student_id' => $studentId, 'is_deleted' => 0));
    $subjectIds = array_column($studentSubjects, 'subject_id');

    // Initialize an array to store the latest three announcements for each subject
    $latestAnnouncementsBySubject = [];

    // Loop through each subject and get the latest three announcements
    foreach ($subjectIds as $subjectId) {
        $latestAnnouncements = $this->Annoucement_model->get_latest_announcements_for_subject($subjectId, 3);

        foreach ($latestAnnouncements as $announcementKey => $announcement) {
            $sender_id = $announcement['sender_id'];
            $sender_type = $announcement['sender_type'];

            if ($sender_type == 'admin') {
                $latestAnnouncements[$announcementKey]['senderName'] = 'Admin';
            } elseif ($sender_type == 'teacher') {
                $sender_info = $this->Teacher_model->getOne(array('id' => $sender_id, 'is_deleted' => 0));
                if ($sender_info) {
                    $latestAnnouncements[$announcementKey]['senderName'] = $sender_info['name'];
                } else {
                    $latestAnnouncements[$announcementKey]['senderName'] = 'Unknown name';
                }
            } else {
                // Handle additional sender types if needed
                // $sender_info = $this->AdditionalSenderModel->getOne(array('id' => $sender_id, 'is_deleted' => 0));
                // $latestAnnouncements[$announcementKey]['senderName'] = $sender_info ? $sender_info['name'] : 'Unknown name';
            }

            // Fetch subject title from the 'subject' table
            $subject_info = $this->Subject_model->getOne(array('id' => $subjectId, 'is_deleted' => 0));
            $latestAnnouncements[$announcementKey]['subject_title'] = $subject_info ? $subject_info['title'] : '';
        }

        $latestAnnouncementsBySubject[$subjectId] = $latestAnnouncements;
    }

    $this->data['latest_announcements'] = $latestAnnouncementsBySubject;

    // Load your view with the modified data
    $this->load->view("student/dashboard", $this->data);
}



}
