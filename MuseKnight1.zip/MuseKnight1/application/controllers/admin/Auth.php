<?php
class Auth extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->model('Admin_model'); // Load the model.
    }
    
    public function login() {
        $this->load->view('login'); // Load the login view.
    }

    public function processLogin() {
        // Get the email and password from the form using CodeIgniter's input class.
        $email = $this->input->post('email');
        $password = $this->input->post('password');
        
        $admin = $this->Admin_model->getOne(array('email' => $email,));

        // if ($admin && password_verify($password, $admin['password'])) {
        if ($admin && $password == $admin['password']) {
            $this->session->set_userdata('user_role', 'admin'); // Set user_role as 'admin'
            $this->session->set_userdata('user_id', $admin['id']);
            redirect(base_url('admin/home'));// Redirect to the teacher homepage.
        } else {
            // Login failed, show an error message and stay on the login page.
            $error_message = 'Invalid email or password.';
            echo "<script>alert('$error_message'); window.location = '" . base_url() . "';</script>";
        }
    }
}
