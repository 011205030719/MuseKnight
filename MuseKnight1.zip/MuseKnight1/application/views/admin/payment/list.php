<?php $this->load->view("admin/nav"); ?>
<?php $this->load->view("layouts/header"); ?>


<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/dt/jq-2.1.4,jszip-2.5.0,pdfmake-0.1.18,dt-1.10.9,af-2.0.0,b-1.0.3,b-colvis-1.0.3,b-html5-1.0.3,b-print-1.0.3,se-1.0.1/datatables.min.css"/>
<style>
        .payment-button {
        background-color: #FF5733; 
        color: white; 
    }


    .receipt-button {
        background-color: mediumspringgreen;
        color: white;
    }
     .custom-module {
        margin-top: -10px;
        margin-bottom: 20px;
        background-color: #703be7;
        height: 40px;
        width: 250px;
        display: flex;
        justify-content: center;
        align-items: center;
        position: relative;
        border-radius: 25px;
        color: #fff;
        text-align: left;
        font-size: 18px;
    }

    .status {
        color: white;
        font-size: 12px;
        font-weight: 600;
        padding-top: 3px;
        padding-bottom: 5px;
        padding-left: 10px;
        padding-right: 10px;
        border-radius: 10px;
    }

    .table-container {
        overflow-x: auto;
    }

    /* Modify the existing table style */
    table {
        background-color: white;
        width: 100%; /* Set the width to 100% */
        table-layout: fixed; /* Set the table layout to fixed */
        overflow: auto;
        display: block;
    }

    /* Adjust the widths of your table columns as needed */
    table th,
    table td {
        padding: 5px;
        text-align: left;
    }
</style>


<div class="container-fluid" style="padding-left: 20%; padding-right: 5%; padding-top: 1%;">
    <div class="header" style=" width:100%;">
        <div style="position: sticky; top: 0; z-index: 1000; background-color:#E6E6FA; border: 0px solid rgba(100, 100, 100, 1); border-radius: 12px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); padding: 10px; margin: 1%;">
            <span>Home / </span>
            <a href="<?= base_url($folder_name.'/payment/list') ?>" style="text-decoration:none; color:black;">Student Fee</a>
        </div>
    <div>
    
    <div class="card shadow">
        <div style="padding: 30px;">
            <div style="overflow-x: auto;" class="table-container">
                <table id="lecturerTable"style="background-color: white; max-height: 400px; overflow-x: auto; display: block;" class="table table-bordered">
                    <thead>
                        
                        <tr style="border-bottom: 2px solid lightgray;">
                            <th style="padding:5px 40px; width: 10%;">#</th>
                            <th style="padding:5px 40px; width: 10%;">Serial</th>
                            <th style="padding:5px 40px; width: 10%;">Payment ID</th>
                            <th style="padding:5px 40px; width: 10%;">Student Name</th>
                            <th style="padding:5px 40px; width: 10%;">Month</th>
                            <th style="padding:5px 40px; width: 10%;">Total Amount</th>
                            <th style="padding:5px 40px; width: 10%;">Payment Date</th>
                            <th style="padding:5px 40px; width: 10%;">Status</th>
                            <th style="padding:5px 40px; width: 40%;">Action</th>
                        </tr>
                    </thead>
                        <tbody>
                            <?php foreach ($sales as $key=>  $sale): ?>
                                <?php
                                $user_id = $sale['student_id'];
                                $payment_serial = $sale['serial'];
                                $payment_serial = $payment_serial !== '' ? $payment_serial : 'No Payment Available';
                                ?>

                                <tr class="table_row">
                                    <th scope="row"><?= $key + 1 ?></th>
                                    <td style="width:20%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                        <?php
                                            // Find the subject_title based on subject_id from the subjects array
                                            $student_id = $sale['student_id'];
                                            $student_serial = '';
                                            foreach ($students as $student) {
                                                if ($student['id'] == $student_id) {
                                                    $student_serial = $student['serial'];
                                                    break; // Exit the loop once subject_title is found
                                                }
                                            }
                                            echo $student_serial;
                                        ?>
                                    </td>
                                    <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $sale['serial'] ?></td>
                                    <td style="width:20%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                        <?php
                                            // Find the subject_title based on subject_id from the subjects array
                                            $student_id = $sale['student_id'];
                                            $student_name = '';
                                            foreach ($students as $student) {
                                                if ($student['id'] == $student_id) {
                                                    $student_name = $student['name'];
                                                    break; // Exit the loop once subject_title is found
                                                }
                                            }
                                            echo $student_name;
                                        ?>
                                    </td>
                                    <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $sale['month'] ?></td>
                                    <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $sale['total_amount'] ?></td>
                                    <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                        <?php
                                        $payment_date = $sale['payment_date'];
                                        if ($payment_date) {
                                            echo $payment_date;
                                        } else {
                                            echo 'No Payment Date';
                                        }
                                        ?>
                                    </td>
                                    <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                        <?php
                                        $status = $sale['status'];

                                        if ($status == 0) {
                                            echo '<span style="color: red;">Not Paid</span>';
                                        } elseif ($status == 1) {
                                            echo '<span style="color: mediumspringgreen;">Paid</span>';
                                        } elseif ($status == 2) {
                                            echo '<span style="color: orange;">Pending</span>';
                                        } else {
                                            echo '<span style="color: gray;">Unknown Status</span>';
                                        }
                                        ?>
                                    </td>
                                    <td style="width:40%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                        <a href="<?= base_url('admin/payment/invoice/' . $sale['id']) ?>" target="_blank" class="btn receipt-button">Invoice</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


    <!-- ----------------------------------------pop up model message------------------------------------------
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <form method="POST" id="create_form" action="<?=base_url('admin/payment/store')?>">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Tuition Invoice</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                    </div>

                    <div class="modal-body">
                        <div class="container">
                            <div class="row">
                                <div class="span4">
                                    <img src="<?= base_url('assets/img/MuseKnightLogo.png') ?>" class="img-rounded logo" style="max-width: 100px; max-height: 100px;">
                                        <address>
                                            <strong>MuseKnight</strong><br>
                                                35, Lajpat Nagar<br>
                                                Gurugram, Haryana-122001 
                                        </address>
                                </div>

                                <div class="span4 card" style="background-color: #f0f0f0; padding: 10px; width: 40%; position: absolute; top: 0; right: 3%;">
                                    <table class="invoice-head">
                                        <tbody>
                                            <tr>
                                                <td class="pull-right"><strong>Invoice #</strong></td>
                                                <td><?= $sale['serial'] ?> </td>
                                            </tr>
                                            <tr>
                                                <td class="pull-right"><strong>Serial</strong></td>
                                                <td >
                                                    <?php
                                                    // Find the subject_title based on subject_id from the subjects array
                                                    $student_id = $sale['student_id'];
                                                    $student_serial = '';
                                                    foreach ($students as $student) {
                                                        if ($student['id'] == $student_id) {
                                                            $student_serial = $student['serial'];
                                                            break; // Exit the loop once subject_title is found
                                                        }
                                                    }
                                                    echo $student_serial;
                                                    ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="pull-right"><strong>Student Name</strong></td>
                                                <td><?= $userdata['name'] ?></td>
                                            </tr>
                                            <tr>
                                                <td class="pull-right"><strong>Date</strong></td>
                                                <td><?= date('d/m/Y') ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                            </div>

                            <div class="row">
                                <div class="span8">
                                    <h2>Invoice</h2>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 span8 well invoice-body">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th class="text-center" style="width: 10%; padding: 5px 30px;">No</th>
                                                <th class="text-center" style="width: 30%; padding: 5px 60px;">Subject</th>
                                                <th class="text-center" style="width: 30%; padding: 5px 60px;">Grade</th>
                                                <th class="text-center" style="width: 30%; padding: 5px 70px;">Amount</th>
                                            </tr>
                                        </thead>
                                        <tbody >
                                        <?php foreach($sales as $sale) { ?>
                                            <tr class="table_row">
                                                <td style="width:5%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $sale['id'] ?></td>

                                                <td style="width:20%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                                    <?php
                                                    // Find the subject_title based on subject_id from the subjects array
                                                    $subject_id = $sale['subject_id'];
                                                    $subject_title = '';
                                                    foreach ($subjects as $subject) {
                                                        if ($subject['id'] == $subject_id) {
                                                            $subject_title = $subject['title'];
                                                            break; // Exit the loop once subject_title is found
                                                        }
                                                    }
                                                    echo $subject_title;
                                                    ?>
                                                </td>

                                                <td style="width:20%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                                    <?php
                                                    // Find the grade_level based on subject_id from the subjects array
                                                    $subject_id = $sale['subject_id'];
                                                    $grade_level = '';
                                                    foreach ($student_subjects as $student_subject) {
                                                        if ($student_subject['subject_id'] == $subject_id) {
                                                            $grade_level = $student_subject['grade_level'];
                                                            break; // Exit the loop once grade_level is found
                                                        }
                                                    }
                                                    echo $grade_level;
                                                    ?>
                                                </td>

                                                <td style="width:20%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $sale['subject_fee'] ?></td>
                                            </tr>
                                        <?php } ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary">Print</button>
                    </div>
            </div>
        </div>
    </div> -->

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- DataTables and Bootstrap DataTables -->
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<!-- DataTables library -->
<script type="text/javascript" src="https://cdn.datatables.net/r/dt/jq-2.1.4,jszip-2.5.0,pdfmake-0.1.18,dt-1.10.9,af-2.0.0,b-1.0.3,b-colvis-1.0.3,b-html5-1.0.3,b-print-1.0.3,se-1.0.1/datatables.min.js"></script>

<script>
    $(document).ready(function() {
        $('#lecturerTable').DataTable({
            dom: 'lBfrtip',
            lengthMenu: [10, 25, 50],
            searching: true,
            buttons: [
                {
                    extend: 'excel',
                    text: 'Download Data',
                    className: 'btn btn-outline-success',
                    init: function(api, node, config) {
                        $(node).removeClass('dt-button');
                        $(node).css({
                            'margin-left': '10%',
                            'margin-bottom': '10%',
                            'height': '30px',
                            'width': '150px',
                            'font-size': '17px',
                            'display': 'flex',
                            'align-items': 'center'
                        });
                    }
                }
            ]
        });
    });

   

    </script>