<?php

class Student extends MY_Controller {

    // Predefine function in controller
	public function __construct()
	{
        parent::__construct();
        // $this->data['invalid'] = 0;
        $this->data['folder_name'] = 'teacher';
        $this->load->model("Student_model");
        $this->load->model("Subject_model"); 
        $this->load->model("StudentSubject_model"); 
        $this->auth_validate();
	}

    public function index() {
        // Get the logged-in teacher's ID or however you manage teacher authentication
        $teacher_id = $this->session->userdata('user_id'); // Replace this with your actual authentication logic
        
        $this->data['students'] = $this->Student_model->get_where(array('is_deleted' => 0));
        $this->data['subjects'] = $this->Subject_model->get_where(array('is_deleted' => 0));
        $this->data['student_subjects'] = $this->StudentSubject_model->get_where(array('teacher_id' => $teacher_id, 'is_deleted' => 0));
        
        // Pass the teacher_id to the view
        $this->data['teacher_id'] = $teacher_id;
        
        $this->load->view("teacher/student/list", $this->data);
    }
    
    
    
    public function store()
{
    if ($this->input->post()) {
        // add student serial id
        $serials = $this->Student_model->getIDKeyArray('serial');
        if ($serials) {
            $largestNumber = 0;
            foreach ($serials as $str) {
                $matches = [];
                if (preg_match('/(\d+)/', $str, $matches)) {
                    $number = intval($matches[0]);
                    if ($number > $largestNumber) {
                        $largestNumber = $number;
                    }
                }
            }
            $serial = 'ST' . str_pad(($largestNumber + 1), 5, '0', STR_PAD_LEFT);
        }

        // Get the subject ID from the form data
        $subject_id = $this->input->post('subject_id');

        // store data
        $sql = array(
            'serial' => $serial,
            'subject_id' => $subject_id, // Fix: Use the correct column name
            'name' => $this->input->post('name'),
            'password' => $this->input->post('password'),
            'email' => $this->input->post('email'),
            'mobile' => $this->input->post('mobile'),
            'gender' => $this->input->post('gender'),
            'status' => $this->input->post('status'),
        );

        $this->Student_model->insert($sql);
        redirect(base_url('teacher/student/list')); // calling route
    }
}


    public function edit($id){
        $this->data['student'] = $this->Student_model->getOne(array('id'=>$id,'is_deleted'=>0));
        $this->data['subject'] = $this->Subject_model->getOne(array('id'=>$id,'is_deleted'=>0));
        $this->load->view("teacher/student/edit",$this->data);
    }
    public function update($id){
        if ($this->input->post()) {
            $sql = array(
                'name' => $this->input->post('name'),
                'password' => $this->input->post('password'),
                'email' => $this->input->post('email'),
                'mobile' => $this->input->post('mobile'),
                'gender' => $this->input->post('gender'),
                'status' => $this->input->post('status'),
                'modified_date' => date('Y-m-d H:i:s'),
            );

            $this->Student_model->update(array('id'=>$id), $sql);

            redirect(base_url('teacher/student/list')); // calling route
            
        }
    }
    
    
    public function delete($id){
        // $this->User_model->delete(array('id'=>$id)); //delete database data
        $this->Student_model->update(array('id'=>$id), array('is_deleted'=>1));
        redirect(base_url('teacher/student/list')); // calling route
    }
}
