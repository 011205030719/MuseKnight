<?php $this->load->view("student/nav"); ?>
<?php $this->load->view("layouts/header"); ?>


<style>
    .announcement-card {
        margin: 10px;
    }

    .announcement-sender-badge {
        background-color: #007bff;
        color: white;
        padding: 4px 8px;
        border-radius: 5px;
        font-size: 12px;
    }
</style>

<div class="border" style="padding-left:20%;padding-right:2%;">
    <div class="header" style=" width:100%;">
        <div  style="position: sticky; top: 0; z-index: 1000; background-color:#E6E6FA; border: 0px solid rgba(100, 100, 100, 1); border-radius: 12px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); padding: 10px; margin: 1%;">
            <span>Home / </span>
            <a href="<?= base_url($folder_name.'/announcement/subjectList') ?>" style="text-decoration:none; color:black;">Subject List</a>
            <span>/ <?= $subject['title'] ?></span>
        </div>
        <div>
            <div style="background-image: url('<?= base_url('assets/img/bck.jpg') ?>'); background-size: cover; background-repeat: no-repeat; background-position: center; border-radius: 10px; padding: 20px; width: 100%; height: 300px; position: relative;">
                <div style="position: absolute; bottom: 20px; left: 20px; color:white; font-size:30px; font-weight:600;"><?= $subject['title'] ?></div>
            </div>
        </div>

        <ul class="nav nav-tabs mb-3" id="pills-tab" role="tablist" style="margin-top:1%;">
            <li class="nav-item">
                <a class="nav-link active" id="annoucment-tab" data-toggle="pill" href="#annoucment" role="tab" aria-controls="annoucment" aria-selected="true">Annoucement</a>
            </li>
            <!-- <li class="nav-item">
                <a class="nav-link" id="user-tab" data-toggle="pill" href="#user" role="tab" aria-controls="user" aria-selected="false">User</a>
            </li> -->
        </ul>
        <!----------------------------------------------------------posted announcement---------------------------------------------------------->
        <div class="tab-content" id="pills-tabContent">
            <div class="tab-pane fade show active" id="annoucment" role="tabpanel" aria-labelledby="annoucment-tab">
                <?php if($announcements){
                        foreach ($announcements as $announcement){ ?>
                        <div class="card announcement-card" style="border-radius:5px;">
                            <div class="card-body">
                                <div style="display:flex; justify-content:start; align-items:center;">
                                    <div style="width: 50px; height: 50px; border-radius: 50%; background-color: #3498db; text-align: center; line-height: 50px; color: #fff; font-size:10px;"><?= $announcement['sender_type'] ?></div>
                                    <div style="margin-left:10px;">
                                        <div style="font-size:15px; font-weight:600;"><?= $announcement['senderName'] ?></div>
                                        <div style="font-size:12px;"><?= date('M d, Y (h:i a)', strtotime($announcement['created_date'])) ?></div>
                                    </div>
                                </div>
                                <br>
                                <h5 class="card-title"><?= $announcement['title'] ?></h5>
                                <p class="card-text"><?= $announcement['description'] ?></p>
                            </div>
                        </div>
                <?php   }
                      }else{ ?>
                      <div style="width:100%; text-align:center; padding:20px;">There is no annoucment posted on this subject.</div>
                <?php } ?>
            </div>


            <!----------------------------------------------------------user list---------------------------------------------------------->
            <div class="tab-pane fade" id="user" role="tabpanel" aria-labelledby="user-tab">
                <table class="table">
                    <h3 class="table_list" style="font-family: 'Tangerine', serif;">Teacher List</h3>
                    <hr>
                    <thead>
                        <tr>
                            <th scope="col" style="width:10%; background-color:whitesmoke;">#</th>
                            <th scope="col" style="background-color:whitesmoke;">Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($teachers as $teacherKey => $teacher) { ?>
                            <tr class="table_row">
                                <td style="background-color:whitesmoke;"><?= $teacherKey+1 ?></td>
                                <td style="width:20%; padding-left:10px; padding-top:8px; padding-bottom:8px;background-color:whitesmoke;"><?= $teachers_Name[$teacher['teacher_id']] ?></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
                <br>
                <table class="table">
                    <h3 class="table_list" style="font-family: 'Tangerine', serif;background-color:whitesmoke;">Student List</h3>
                    <hr>
                    <thead>
                        <tr>
                            <th scope="col" style="width:10%;background-color:whitesmoke;">#</th>
                            <th scope="col"style="background-color:whitesmoke;">Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $studentKey => $student) { ?>
                            <tr class="table_row">
                                <td style="background-color:whitesmoke;"><?= $studentKey +1 ?></td>
                                <td style="width:20%; padding-left:10px; padding-top:8px; padding-bottom:8px;background-color:whitesmoke;"><?= $student['name'] ?></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>