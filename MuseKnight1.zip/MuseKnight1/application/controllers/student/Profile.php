<?php

class Profile extends MY_Controller
{

    // Predefine function in controller
    public function __construct()
    {
        parent::__construct();
        // $this->data['invalid'] = 0;
        $this->data['folder_name'] = 'student';
        $this->load->model("Student_model");
        $this->load->model("Subject_model");
        $this->load->model("StudentSubject_model");
        $this->auth_validate();
    }

    public function index()
    {
        $user_id = $this->session->userdata('user_id'); // Adjust this to get the user's ID
        $user_data = $this->Student_model->getOne(array('id' => $user_id));

        // Check if the 'image' key is set in the retrieved data
        if (!isset($user_data['image']) || empty($user_data['image'])) {
            $user_data['image'] = 'profil1.jpeg';
        }

        $this->data['userdata'] = $user_data;

        // The rest of your code remains the same
        $this->data['students'] = $this->Student_model->get_where(array('is_deleted' => 0));
        $this->data['subjects'] = $this->Subject_model->get_where(array('is_deleted' => 0));
        $this->data['student_subjects'] = $this->StudentSubject_model->get_where(array('is_deleted' => 0));
        $this->load->view("student/profile/list", $this->data);
    }   

    public function store()
    {
        if ($this->input->post()) {
            // Add student serial id and save uploaded profile image
            $serials = $this->Student_model->getIDKeyArray('serial');
            if ($serials) {
                $largestNumber = 0;
                foreach ($serials as $str) {
                    $matches = [];
                    if (preg_match('/(\d+)/', $str, $matches)) {
                        $number = intval($matches[0]);
                        if ($number > $largestNumber) {
                            $largestNumber = $number;
                        }
                    }
                }
                $serial = 'ST' . str_pad(($largestNumber + 1), 5, '0', STR_PAD_LEFT);
            }

            // Get the subject ID from the form data
            $subject_id = $this->input->post('subject_id');

            // Handle image upload
            if (!empty($_FILES['profile_pic']['name'])) {
                // Configure image upload settings
                $config['upload_path'] = 'uploads/profiles/';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['max_size'] = 2048; // 2MB max size, adjust as needed

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('profile_pic')) {
                    $data = $this->upload->data();
                    $image_name = $data['file_name'];
                } else {
                    $error = $this->upload->display_errors();
                    // Handle the upload error as needed
                }
            } else {
                $image_name = ''; // No image uploaded, set it to an empty string
            }

            // Store data including the profile image name
            $sql = array(
                'serial' => $serial,
                'subject_id' => $subject_id,
                'name' => $this->input->post('name'),
                'password' => $this->input->post('password'),
                'email' => $this->input->post('email'),
                'mobile' => $this->input->post('mobile'),
                'status' => $this->input->post('status'),
                'image' => $image_name, // Save the image name
            );

            $this->Student_model->insert($sql);
            redirect(base_url('student/profile/list'));
        }
    }

    // public function updateProfileImage()
    // {
    //     // Check if the form was submitted
    //     if ($this->input->post('update_profile')) {
    //         // Get the user ID from the session
    //         $user_id = $this->session->userdata('user_id');

    //         // Handle image upload
    //         if (!empty($_FILES['image']['name'])) {
    //             // Configure image upload settings
    //             $config['upload_path'] = 'uploads/profiles/';
    //             $config['allowed_types'] = 'jpg|jpeg|png';
    //             $config['max_size'] = 2048; // 2MB max size, adjust as needed

    //             $this->load->library('upload', $config);

    //             if ($this->upload->do_upload('image')) {
    //                 $data = $this->upload->data();
    //                 $image_name = $data['file_name'];

    //                 // Update the user's profile image in the database
    //                 $this->Student_model->update(array('id' => $user_id), array('image' => $image_name));

    //                 // Redirect to the profile page or any other page as needed
    //                 redirect(base_url('student/profile/index'));
    //             } else {
    //                 $error = $this->upload->display_errors();
    //                 // Handle the upload error as needed
    //             }
    //         }
    //     }

    //     redirect(base_url('student/profile/list'));
    // }

    public function updateProfileImage()
    {
        $image = $this->input->post('image');
        $user_id = $this->session->userdata('user_id');
    
        // Upload Image
        $config['upload_path'] = FCPATH . 'assets/img/profiles/';
        $config['allowed_types'] = 'jpg|jpeg|png';
        $config['max_size'] = 2048;
        $this->load->library('upload', $config);
    
        if ($this->upload->do_upload('image')) {
            $data = $this->upload->data();
            $image_name = $data['file_name'];
    
            $sql = array(
                'image' => $image_name,
            );
    
            $this->Student_model->update(array('id' => $user_id, 'is_deleted' => 0), $sql);
    
            // Redirect to the 'student/profile/list' page
            redirect(base_url('student/profile/index'));
        } else {
            $error = array('error' => $this->upload->display_errors());
            var_dump($error);
            throw new Exception("Error!");
        }
    }
    


    public function edit($id)
    {
        $this->data['student'] = $this->Student_model->getOne(array('id' => $id, 'is_deleted' => 0));

        // Set the student_id variable to the ID of the student you want to display
        $student_id = $id;

        // Fetch the subject information for the student from the student_subject table
        $this->load->model("StudentSubject_model"); // Assuming you have a model for student_subject
        $this->data['student_subjects'] = $this->StudentSubject_model->get_where(array('student_id' => $student_id, 'is_deleted' => 0));

        $this->load->view("student/profile/edit", $this->data);
    }


    // public function update_password($id)
    // {
    //     if ($this->input->is_ajax_request()) {
    //         $new_password = $this->input->post('new_password');

    //         // Check password format
    //         if (!$this->isValidPasswordFormat($new_password)) {
    //             // Password format is incorrect, send an error response
    //             echo json_encode(array('status' => 'error', 'message' => 'Incorrect password format.'));
    //             return;
    //         }

    //         // Update the password in the database
    //         $sql = array(
    //             'password' => $new_password,
    //             'modified_date' => date('Y-m-d H:i:s'),
    //         );

    //         $this->Student_model->update(array('id' => $id), $sql);

    //         // Send a success response
    //         echo json_encode(array('status' => 'success', 'message' => 'Password updated successfully.'));
    //     } else {
    //         // Non-AJAX request, handle accordingly
    //         show_404(); // or redirect, or display an error page
    //     }
    // }

    // private function isValidPasswordFormat($password)
    // {
    //     // Implement your password format validation logic here
    //     // For example, check length, presence of letters and numbers, etc.
    //     return strlen($password) >= 8 && preg_match('/[a-zA-Z]/', $password) && preg_match('/\d/', $password);
    // }

    public function update($id) {
        if ($this->input->post()) {
            $sql = array(
                'password' => $this->input->post('new_password'),
                'modified_date' => date('Y-m-d H:i:s'),
            );
            // Update the teacher's data
            $this->Student_model->update(array('id' => $id), $sql);
    
            // Set a success message
            $this->session->set_flashdata('success_message', 'Password updated successfully.');
    
            redirect(base_url('student/profile/index')); // calling route
        }
    }

    public function delete($id)
    {
        // $this->User_model->delete(array('id'=>$id)); //delete database data
        $this->Student_model->update(array('id' => $id), array('is_deleted' => 1));
        redirect(base_url('student/profile/list')); // calling route
    }
}
