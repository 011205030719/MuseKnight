<?php $this->load->view("teacher/nav"); ?>
<?php $this->load->view("layouts/header"); ?>
<style>
    .subject-background{
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center;
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
        padding: 20px;
        width: 100%;
        height: 150px;
        position: relative;   
    }
    .subject-content{
        position: absolute; 
        left: 20px;
        color:white;
        font-weight:600;
    }
    .overlay{
        position: absolute;
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
    }
</style>
<div class="border" style="padding-left:20%;padding-right:2%;">
    <div class="header" style=" width:100%;">
        <div style="position: sticky; top: 0; z-index: 1000; background-color:#E6E6FA; border: 0px solid rgba(100, 100, 100, 1); border-radius: 12px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); padding: 10px; margin: 1%;">
            <span>Home / </span>
            <a href="<?= base_url($folder_name.'/annoucement/subjectList') ?>" style="text-decoration:none; color:black;">Subject List</a>
        </div>
    <div>
    <div class="row" style="margin-top:2%">
        <?php foreach($subjects as $subject){ ?>
        <div class="col-4">
            <a href="<?= base_url($folder_name.'/annoucement/list/'.$subject['subject_id']) ?>" style="text-decoration:none;">
                <div class="shadow" style="border-radius:10px;">
                    <div class="subject-background" style="background-image: url('<?= base_url('assets/img/bck.jpg') ?>');">
                        <div class="overlay">
                            <div class="subject-content" style="top: 20px; font-size:20px;"><?= $subject['title'] ?></div>
                            <!-- <div class="subject-content" style="bottom: 20px; font-size:15px;"><?= $subject['teacherName'] ?></div>     -->
                        </div>
                        <div style="position: absolute; bottom: -20px; right: 20px; z-index: 1;">
                            <div style="border-radius: 50%; width: 70px; height: 70px;">
                                <img src="<?= base_url('assets/img/bck.jpg') ?>" style="width: 100%; height: 100%; border-radius: 50%;" alt="">
                            </div>
                        </div>
                    </div>
                     <div style="padding:10px; font-size:12px; color:black;">
                        <div>Teacher Name : <?= $userdata['name'] ?></div>
                        <!-- <div>Student : </div> -->
                    </div>
                </div>
            </a>
        </div>
        <?php } ?>
    </div>
</div>