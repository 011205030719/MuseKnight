<style>
  body {
    background: #eee;
    overflow-y: scroll;
    margin: 0;
  }

  #side_nav {
    background: #0e1a35;
    min-width: 250px;
    max-width: 250px;
    transition: all 0.3s;
    height: 100%;
    min-height: 675px;
    position: fixed;
  }

  .content {
    min-height: 100vh;
    width: 100%;
  }

  hr.h-color {
    background: #eee;
  }
  .header-box {
    text-align: center;
    margin-bottom: 20px;
  }

  .header-box img {
    max-width: 100%; /* Make sure the image does not exceed its container */
    width: 70%;
    margin-left: 15%;
  }

  .header-box h1 {
    margin: 0;
    color: #fff;
  }

  .sidebar li.active {
    background: #eee;
    border-radius: 8px;
  }

  .sidebar li.active a,
  .sidebar li.active a:hover {
    color: #000;
  }
  .sidebar li:hover{
    background-color: rgba(255, 255, 255, 0.2);
}

  .sidebar li a {
    color: #fff;
    margin-bottom: 5%;
  }

  .sidebar-bottom {
    position: absolute;
    bottom: 0;
    width: 100%;
  }

  .sidebar-bottom li {
    margin-bottom: 10%;
  }

  @media (max-width: 767px) {
    #side_nav {
      margin-left: -250px;
      position: absolute;
      min-height: 100vh;
      z-index: 1;
    }

    #side_nav.active {
      margin-left: 0;
    }
  }

  .sales_nav {
    padding-left: 15%;
    background-color: rgb(0, 0, 0, 0.15);
    padding-top: 10px;
    padding-bottom: 10px;
  }

  .sales_nav:hover {
    background-color: rgb(255, 255, 255, 0.2);
  }

  .profile-image {
    width: 30px; /* Adjust the width as needed */
    height: 30px; /* Adjust the height as needed */
    border-radius: 50%; /* Optional: make the image circular */
    margin-right: 10px; /* Optional: add some spacing between the image and the text */
}

</style>

<body>
  <div class="main-container d-flex">
    <div class="sidebar" id="side_nav">
      <div class="header-box px-2 pt-3 pb-4 d-flex">
      <img src="<?=base_url('assets/img/MuseKnightLogo.png')?>">
        <button class="btn d-md-none d-block close-btn px-1 py-0 text-white"><i class="fal fa-stream"></i></button>
      </div>

      <ul class="list-unstyled px-2">
        <li class="active">
          <a href="<?= base_url($folder_name.'/dashboard') ?>" class="text-decoration-none px-3 py-2 d-block">
            <i class="bi bi-speedometer2"></i> Dashboard
          </a>
        </li>

        <li class="">
          <a href="<?= base_url($folder_name.'/announcement/subjectList') ?>" class="text-decoration-none px-3 py-2 d-block">
            <i class="bi bi-megaphone"></i> Announcement
          </a>
        </li>

        <!-- <li class="">
          <a href="<?= base_url($folder_name.'/student/list') ?>" class="text-decoration-none px-3 py-2 d-block d-flex justify-content-between">
            <span><i class="fal fa-comment"></i> Calendar</span>
          </a>
        </li> -->

        <li class="">
          <a href="<?= base_url($folder_name.'/payment/list') ?>" class="text-decoration-none px-3 py-2 d-block">
            <i class="bi bi-wallet"></i> Payment
          </a>
        </li>
      </ul>
      <br>
      <hr class="h-color mx-2 "style="color:white;">
      <ul class="list-unstyled px-2 sidebar-bottom">
      <li class="">
        <a href="<?= base_url($folder_name.'/profile/list/'. $userdata['id']) ?>" class="text-decoration-none px-3 py-2 d-block">
            <img src="<?=base_url('assets/img/profiles/'.$userdata['image'])?>" alt="Profile Image" class="profile-image"> <!-- Add this line for the profile image -->
            <i class="fal fa-bars"></i> Profile
        </a>
      </li>
        <li class=""><a href="<?= base_url('auth/logout') ?>" class="text-decoration-none px-3 py-2 d-block"><i class="bi bi-box-arrow-left"></i> Log out</a></li>
      </ul>
    </div>
  </div>
</body>

<script>

    // Set the last clicked item to local storage on click
    $(document).ready(function () {
        $(".sidebar ul li a").click(function () {
            var href = $(this).attr('href');
            localStorage.setItem('lastClicked', href);
        });

        // Call the setActiveLink function when the page loads
        setActiveLink();
    });
</script>
