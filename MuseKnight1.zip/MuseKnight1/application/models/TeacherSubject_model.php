<?php
class TeacherSubject_model extends MY_Model {
    public function __construct(){
        $this->set_table('teacher_subject');
    }
    public function getWhere($conditions) {
        $this->db->where($conditions);
        $query = $this->db->get('teacher_subject'); // Replace 'teacher_subject' with your table name
    
        return $query->result();
    }
    // Count the number of active teachers for a given subject
    public function countWhere($where)
    {
        $this->db->where($where);
        $this->db->from('teacher_subject');
        return $this->db->count_all_results();
    }
    public function getTeacherBySubject($subject_id) {
        // Define the database query to retrieve student_subject data by subject and teacher
        $query = $this->db->get_where('student_subject', array('subject_id' => $subject_id, 'is_deleted' => 0));
    
        $teacher_ids = array();
        foreach ($query->result_array() as $row) {
            $teacher_ids[] = $row['teacher_id'];
        }
    
        return $teacher_ids;
    }

}
?>