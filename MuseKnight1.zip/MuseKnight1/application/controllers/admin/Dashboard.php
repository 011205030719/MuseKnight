<?php

class Dashboard extends MY_Controller {

    // Predefine function in controller
	public function __construct()
{
    parent::__construct();
    $this->data['folder_name'] = 'admin';
    $this->load->model("Admin_model");
    $this->load->model("StudentSubject_model");
    $this->load->model("Student_model");
    $this->load->model("Sales_model");
    $this->load->model("Salary_model");
    $this->load->model("Annoucement_model"); 
    $this->load->model("TeacherSubject_model"); 
    $this->load->model("Teacher_model");
    $this->auth_validate();
}


    public function index(){
        /////////////////// Get all students with status = 0 (active)\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
        $active_students = $this->Student_model->get_where(array('status' => 0, 'is_deleted' => 0));

        // Count the number of active students
        $total_active_students = count($active_students);

        // Pass the total to the view
        $this->data['total_active_students'] = $total_active_students;

        /////////////////// Get all Teachers with status = 0 (active)\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
         $active_teachers = $this->Teacher_model->get_where(array('status' => 0, 'is_deleted' => 0));

         // Count the number of active students
         $total_active_teachers = count($active_teachers);
 
         // Pass the total to the view
         $this->data['total_active_teachers'] = $total_active_teachers;
        
        /////////////////// Get all Sales with status = 1 (paid)\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
        $active_sales = $this->Sales_model->get_where(array('status' => 1, 'is_deleted' => 0));

        // Calculate the total amount for active sales
        $total_active_sales_amount = 0;
        foreach ($active_sales as $sale) {
            $total_active_sales_amount += $sale['total_amount'];
        }

        // Pass the total to the view
        $this->data['total_active_sales_amount'] = $total_active_sales_amount;

        ///////////////////// Get all teacher salaries with status = 1\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
        $active_teacher_salaries = $this->Salary_model->get_where(array('status' => 1, 'is_deleted' => 0));

        // Calculate the total amount for active teacher salaries
        $total_active_teacher_salary_amount = 0;
        foreach ($active_teacher_salaries as $salary) {
            $total_active_teacher_salary_amount += $salary['total_amount'];
        }

        // Pass the total to the view
        $this->data['total_active_teacher_salary_amount'] = $total_active_teacher_salary_amount;

        /////////////////// Get the total number of students for each subject\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
        $subject_student_counts = $this->StudentSubject_model->get_subject_student_counts();

        // Prepare data for the pie chart
        $xArray = [];
        $yArray = [];

        foreach ($subject_student_counts as $subject_count) {
            $xArray[] = $subject_count['subject_title'];
            $yArray[] = $subject_count['total_students'];
        }

        // Pass the data to the view
        $this->data['subject_student_counts'] = json_encode(['labels' => $xArray, 'values' => $yArray]);


        $this->data['students'] = $this->Student_model->get_where(array('is_deleted' => 0));
        $this->data['subjects'] = $this->Subject_model->get_where(array('is_deleted' => 0));
        $this->data['student_subjects'] = $this->StudentSubject_model->get_where(array('is_deleted' => 0));
        $this->data['sales'] = $this->Sales_model->get_where(array('is_deleted' => 0));
        $this->data['annoucements'] = $this->Annoucement_model->get_where(array('is_deleted' => 0));
        $this->data['teachers'] = $this->Teacher_model->get_where(array('is_deleted' => 0));
        $this->data['teacher_subjects'] = $this->TeacherSubject_model->get_where(array('is_deleted' => 0));

       // Annoucment
       $last_three_announcements = $this->Annoucement_model->get_latest_announcements_for_admin(3);


    foreach ($last_three_announcements as $announcementKey => $announcement) {
        $sender_id = $announcement['sender_id'];
        $sender_type = $announcement['sender_type'];

        // Fetch the name based on sender_type and sender_id
        if ($sender_type == 'admin') {
            // For admin sender, you can directly use 'Admin' as the sender name
            $last_three_announcements[$announcementKey]['senderName'] = 'Admin';
        } elseif ($sender_type == 'teacher') {
            $sender_info = $this->Teacher_model->getOne(array('id' => $sender_id, 'is_deleted' => 0));
            if ($sender_info) {
                // Assign the sender's name to the announcement
                $last_three_announcements[$announcementKey]['senderName'] = $sender_info['name'];
            } else {
                // Handle the case when the sender's info is not found
                $last_three_announcements[$announcementKey]['senderName'] = 'Unknown name';
            }
        } else {
            // Handle additional sender types if needed
            // $sender_info = $this->AdditionalSenderModel->getOne(array('id' => $sender_id, 'is_deleted' => 0));
            // $last_three_announcements[$announcementKey]['senderName'] = $sender_info ? $sender_info['name'] : 'Unknown name';
        }
         $last_three_announcements[$announcementKey]['subject_title'] = $announcement['subject_title'];
    }

    $this->data['annoucements'] = $last_three_announcements; // Assign the modified array back

     // Get the total fees for each subject
     $subject_fee_data = (array) $this->StudentSubject_model->get_subject_fees_counts();



 
     // Pass the data to the view
     $this->data['subject_fee_data'] = json_encode($subject_fee_data);
     
    $this->load->view("admin/dashboard", $this->data);
}

}
