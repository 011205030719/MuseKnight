<?php

function calculateTotalTuition($sales) {
    $totalTuition = 0;

    foreach ($sales as $sale) {
        if ($sale['status'] == 0) {
            $totalTuition += $sale['subject_fee'];
        }
    }

    return $totalTuition;
}
