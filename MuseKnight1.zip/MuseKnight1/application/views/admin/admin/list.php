
<?php $this->load->view("admin/nav"); ?>
<?php $this->load->view("layouts/header"); ?>

<style>
    .custom-module{
        margin-top: -10px; 
        margin-bottom: 20px; 
        background-color: #703be7; 
        height: 40px; 
        width: 250px; 
        display: flex; 
        justify-content: center; 
        align-items: center; 
        position: relative; 
        border-radius: 25px; 
        color: #fff; 
        text-align: left;
        font-size: 18px;
    }

    .status{
        color: white;
        font-size:12px;
        font-weight:600;
        padding-top:3px;
        padding-bottom:5px;
        padding-left:10px;
        padding-right:10px;
        border-radius:10px;
    }

    /* .custom-module:hover{
        background-color: #422387; 
    } */
</style>

<div class="container-fluid" style="padding-left: 20%; padding-right: 5%; padding-top: 3%;">

    <div style="text-align: end; margin-bottom:20px;">
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#createModal">Add New Admin</button>
        <!-- Modal -->
        <div class="modal fade" id="createModal" tabindex="-1" role="dialog" aria-labelledby="createModalTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" style="max-width: 60%;" role="document">
                <div class="modal-content">
                    <form method="POST" id="create_form" action="<?=base_url('admin/admin/store')?>">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle">Create New Admin</h5>
                            <a style="padding-left: 15px; padding-right: 15px;" type="button" data-dismiss="modal" aria-label="Close">x</a>
                        </div>
                        <div class="modal-body">
                                <div class="row" style="text-align: start;" >
                                    <div class="col-6 form-group mb-2">
                                        <label for="name" style="font-weight: 500;" class="mb-2">Name</label>
                                        <input required type="text" id="name" class="form-control" name="name" placeholder="Enter User name">
                                    </div>
                                    <div class="col-6 form-group mb-2">
                                        <label for="email" style="font-weight: 500;" class="mb-2">Email</label>
                                        <input required type="text" id="email" class="form-control" name="email" placeholder="Enter email address">
                                    </div>
                                    <div class="col-6 form-group mb-2">
                                        <label for="mobile" style="font-weight: 500;" class="mb-2">Mobile</label>
                                        <input required type="text" id="mobile" class="form-control" name="mobile" placeholder="Enter mobile number">
                                    </div>
                                    <div class="col-6 form-group mb-2">
                                        <label for="password" style="font-weight: 500;" class="mb-2">Password</label>
                                        <input required type="password" id="password" class="form-control" name="password" placeholder="Enter your password">
                                    </div>
                                    <div class="col-6 form-group mb-2">
                                        <label for="status" style="font-weight: 500;" class="mb-2">Status</label>
                                        <select name="status" id="status" class="form form-select">
                                            <option value="0">Admin</option>
                                            <option value="1">Super Admin</option>
                                        </select>
                                    </div>
                                </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="card shadow">
        <div style="padding: 30px;">
            <table style="background-color: white; width:100%; height: 400px; overflow: auto; display: block;">
                <thead>
                    <tr style="border-bottom: 2px solid lightgray;">
                        <th style="padding:5px; width: 3%;">#</th>
                        <th style="padding:5px; width: 10%;">Serial</th>
                        <th style="padding:5px; width: 15%;">Name</th>
                        <th style="padding:5px; width: 20%;">Email</th>
                        <th style="padding:5px; width: 15%;">Mobile</th>
                        <th style="padding:5px; width: 15%;">Status</th>
                        <th style="padding:5px; width: 15%;">Created Date</th>
                        <th style="padding:5px; width: 15%;">Action</th>
                    </tr>
                </thead>
                <tbody >
                <?php foreach($admins as $admin){?>
                    <tr class="table_row">
                        <td style="width:3%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $admin['id'] ?></td>
                        <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $admin['serial'] ?></td>
                        <td style="width:15%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $admin['name'] ?></td>
                        <td style="width:20%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $admin['email'] ?></td>
                        <td style="width:15%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $admin['mobile'] ?></td>
                        <td style="width:15%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                            <?php if($admin['status'] == 0){?>
                                <span class="status-primary">Admin</span>
                            <?php }else{ ?>
                                <span class="status-warning">Super Admin</span>
                            <?php } ?>
                        </td>
                        <td style="width:15%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $admin['created_date'] ?></td>
                        <td style="width:15%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                            <a href="<?=base_url('admin/admin/edit/'. $admin['id'])?>" class="btn btn-success"><i class="bi bi-pencil-square"></i></a>
                            <a href="<?=base_url('admin/admin/delete/'. $admin['id'])?>" onclick="return confirmSubmit();" class="btn btn-danger"><i class="bi bi-trash3"></i></a>
                        </td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
function confirmSubmit() {
    // Display a confirmation dialog
    if (window.confirm("Are you sure you want to delete this admin?")) {
        document.getElementById("myForm").submit();
        return true;
    } else {
        return false;
    }
}
</script>
