<?php $this->load->view("admin/nav"); ?>
<?php $this->load->view("layouts/header"); ?>

<div class="container-fluid" style="padding-left: 20%; padding-right: 5%; padding-top: 1%;">
    <div class="header" style=" width:100%;">
        <div style="position: sticky; top: 0; z-index: 1000; background-color:#E6E6FA; border: 0px solid rgba(100, 100, 100, 1); border-radius: 12px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); padding: 10px; margin: 1%;">
            <span>Home / </span>
            <a href="<?= base_url($folder_name.'/teacher/list') ?>" style="text-decoration:none; color:black;">Teacher List</a>
            <span>/</span>
            <a href="<?= base_url($folder_name.'/teacher/edit') ?>" style="text-decoration:none; color:black;">Teacher Edit</a>
        </div>
    <div>
    <?php if ($teacher): ?>
        <form method="POST" id="edit_form" action="<?= base_url('admin/teacher/update/' . $teacher['id']) ?>">
            <!-- <div style="text-align: end; margin-bottom:20px;">
                <a href="<?= base_url('admin/teacher/list') ?>" class="btn btn-secondary">Back</a>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div> -->
            <div class="card shadow">
                <div style="padding: 30px;">
                    <div class="row" style="text-align: start; margin-bottom:10px">
                        <div class="col-6 form-group mb-2">
                            <label for="serial" style="font-weight: 500;" class="mb-2">Serial ID</label>
                            <input readonly type="text" id="serial" class="form-control bg-light" name="serial" value="<?= $teacher['serial'] ?>">
                        </div>
                        <div class="col-6 form-group mb-2">
                            <label for="gender" style="font-weight: 500;" class="mb-2">Gender</label>
                                <select name="gender" id="gender" class="form form-select">
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>

                        </div>
                        <div class="col-6 form-group mb-2">
                            <label for="subject_id">Subject</label>
                            <?php foreach ($subjects as $subject) {
                                $is_checked = 0;
                                    foreach ($teacher_subjects as $teacher_subject) {
                                        if($teacher_subject['subject_id'] == $subject['id']){
                                            $is_checked = 1;
                                        }
                                    } ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="subject_id[]" value="<?= $subject['id'] ?>" <?= $is_checked==1 ? 'checked' : '' ?>>
                                    <label class="form-check-label"><?= $subject['title'] ?></label>
                                </div>
                            <?php } ?>
                        </div>
                        <div class="col-6 form-group mb-2">
                            <label for="name" style="font-weight: 500;" class="mb-2">Teacher Name</label>
                            <input required type="text" id="name" class="form-control" name="name" value="<?= $teacher['name'] ?>">
                        </div>
                        <div class="col-6 form-group mb-2">
                            <label for="email" style="font-weight: 500;" class="mb-2">Email</label>
                            <input required type="email" id="email" class="form-control" name="email" value="<?= $teacher['email'] ?>">
                        </div>
                        
                        <div class="col-6 form-group mb-2">
                            <label for="commission_rate" style="font-weight: 500;" class="mb-2">Commission Rate</label>
                            <input required type="commission_rate" id="commission_rate" class="form-control" name="commission_rate" value="<?= $teacher['commission_rate'] ?>">
                        </div>
                        <div class="col-6 form-group mb-2">
                            <label for="bank" style="font-weight: 500;" class="mb-2">Bank</label>
                            <select id="bank" class="form form-select" name="bank">
                                <option value="bank" disabled>Select a bank</option>
                                <option value="Public Bank Berhad" <?php if ($teacher['bank'] === "Public Bank Berhad") echo 'selected'; ?>>Public Bank Berhad</option>
                                <option value="Hong Leong Bank Berhad" <?php if ($teacher['bank'] === "Hong Leong Bank Berhad") echo 'selected'; ?>>Hong Leong Bank Berhad</option>
                                <option value="RHB Bank Berhad" <?php if ($teacher['bank'] === "RHB Bank Berhad") echo 'selected'; ?>>RHB Bank Berhad</option>
                                <option value="CIMB Bank Berhad" <?php if ($teacher['bank'] === "CIMB Bank Berhad") echo 'selected'; ?>>CIMB Bank Berhad</option>
                                <option value="AmBank" <?php if ($teacher['bank'] === "AmBank") echo 'selected'; ?>>AmBank</option>
                                <option value="UOB Malaysia" <?php if ($teacher['bank'] === "UOB Malaysia") echo 'selected'; ?>>UOB Malaysia</option>
                                <option value="HSBC Bank Malaysia" <?php if ($teacher['bank'] === "HSBC Bank Malaysia") echo 'selected'; ?>>HSBC Bank Malaysia</option>
                                <option value="Affin Bank" <?php if ($teacher['bank'] === "Affin Bank") echo 'selected'; ?>>Affin Bank</option>
                                <option value="OCBC Bank Malaysia" <?php if ($teacher['bank'] === "OCBC Bank Malaysia") echo 'selected'; ?>>OCBC Bank Malaysia</option>
                            </select>
                        </div>

                        <div class="col-6 form-group mb-2">
                            <label for="account" style="font-weight: 500;" class="mb-2">Account</label>
                            <input required type="text" id="account" class="form-control" name="account" value="<?= $teacher['account'] ?>">
                        </div>
                        <div class="col-6 form-group mb-2">
                            <label for="mobile" style="font-weight: 500;" class="mb-2">Mobile</label>
                            <input required type="text" id="mobile" class="form-control" name="mobile" value="<?= $teacher['mobile'] ?>">
                        </div>
                        <div class="col-6 form-group mb-2">
                            <label for="password" style="font-weight: 500;" class="mb-2">Password</label>
                            <input required type="password" id="password" class="form-control" name="password" value="<?= $teacher['password'] ?>">
                        </div>
                        <div class="col-6 form-group mb-2">
                            <label for="status" style="font-weight: 500;" class="mb-2">Status</label>
                                <select name="status" id="status" class="form form-select">
                                    <option value="0">Active</option>
                                    <option value="1">Inactive</option>
                                </select>
                        </div>
                        
                    </div>
                    <div style="text-align: end;">
                        <a href="<?= base_url('admin/teacher/list') ?>" class="btn btn-secondary">Back</a>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
            </div>
        </form>
    <?php else: ?>
        <p>Error: Teacher not found.</p>
    <?php endif; ?>
</div>
