<?php

class Auth extends CI_Controller {

    // Predefine function in controller
	public function __construct()
	{
        parent::__construct();
        $this->data['invalid'] = 0;
        $this->load->model("Admin_model");
        $this->load->model("Teacher_model");
        $this->load->model("Student_model");
	}
    public function login(){
        $this->load->view("login",$this->data);
    }
    public function login_validate() {
        $serial = $this->input->post('serial');
        $password = $this->input->post('password');

        if ($serial && $password)
        {
            if (strpos($serial, "AD") === 0)
            {
                $this->data['folder_name'] = 'admin';
                $this->data['login_model'] = 'Admin_model';
    
            }else if (strpos($serial, "ST") === 0)
            {
                $this->data['folder_name'] = 'student';
                $this->data['login_model'] = 'Student_model';
            }else if (strpos($serial, "TC") === 0)
            {
                $this->data['folder_name'] = 'teacher';
                $this->data['login_model'] = 'Teacher_model';
            }

            $user = $this->{$this->data['login_model']}->getOne(array('serial' => $serial,'is_deleted' => 0));
            
            // if ($user && password_verify($password, $user['password'])) {
            if ($user && $password === $user['password']) {
                $module = ucfirst($this->data['folder_name']);
                $this->session->set_userdata('module', $module);
                $this->session->set_userdata('is_login', true);
                $this->session->set_userdata('user_id', $user['id']);
                redirect(base_url($this->data['folder_name'].'/dashboard'));
            } else {
                $this->data['invalid'] = 1;
                $this->data['error_message'] = "Invalid serial number or password. Try again!";
                $this->load->view("login",$this->data);
            }
        } else {
            $this->data['invalid'] = 1;
            $this->data['error_message'] = "Please insert your serial number and password!";
            $this->load->view("login",$this->data);
        }
    }
    public function logout() {
        $this->session->unset_userdata('module');
        $this->session->unset_userdata('is_login');
        $this->session->unset_userdata('user_id');
        redirect(base_url('login'));
    }
}
