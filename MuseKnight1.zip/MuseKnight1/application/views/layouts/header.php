
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

 <style>
    body{
        background-color:GhostWhite ;
    }
    /* .header {
        top: 0;
        height: 80px;
        background: white;
        color: white;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0 15px;
    }

    .logo {
        padding: 15px;
        font-weight: 800;
        font-size: 45px;
    }

    .title {
        font-size: 20px;
        margin-left: 15px;
        color: #000;
    }
    .card-item{
        display:flex;
        align-items: center;
        padding: 20px;
        font-weight:600;
        justify-content: space-between;
    }
    .card-header{
        background-color: transparent;
        padding: 5px; 
        display:flex; 
        justify-content:space-between; 
        align-items:center; 
        padding-bottom:20px; 
        margin-bottom:20px; 
        border-bottom: 1.5px solid lightgray;
    }
	.selected_table{
		border: 1.5px solid lightgray;
		border-radius: 5px;
		padding: 10px;
		height: 260px;
		overflow: hidden;
	}
	thead, tbody tr{
		display: table;
    	table-layout: fixed;
    	width: 100%;
	}
    .table_row:hover {
        background-color: #f5f5f5;
    }
    .status-primary{
        padding-right:15px;
        padding-left:15px;
        padding-top:5px;
        padding-bottom:5px;
        background-color:#007bff;
        color:black;
        font-weight:700;
        border-radius:10px;
        text-align:center;
    }
    .status-warning{
        padding-right:15px;
        padding-left:15px;
        padding-top:5px;
        padding-bottom:5px;
        background-color:#ffc107;
        color:white;
        font-weight:700;
        border-radius:10px;
        text-align:center;
    } */

</style>
<!--
<div>
    <div class="header shadow" style="padding-left:20%; color: white;">
        <div style="display: flex; align-items: center;">
            <div class="logo">
                <a type="button">
                    <i class="bi bi-list"></i>
                </a>
            </div>
            <div class="title">MuseKnight - <?= $module ?> Panel</div>
        </div>
        <div style="display:flex; align-items:center">
            <img style="width: 40px; height: 40px; margin-right:10px; border-radius:25px; background-color:white;" src="https://icon-library.com/images/head-admin-icon-ts3/head-admin-icon-ts3-8.jpg" alt="">
            <div style="text-align:start; padding-right:5px;">
                <div style="font-weight: bold;"><?= $userdata['name'] ?></div>
                <div style="font-size: 14px;"><?= $userdata['serial'] ?></div>
            </div>
            <div class="dropdown">
                <button class="btn" style="color: white;" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="bi bi-caret-down-fill"></i>
                </button>
                <div class="dropdown-menu  dropdown-menu-right" aria-labelledby="dropdownMenuButton">
                    <div>
                        <a class="dropdown-item" href="#">
                            <i class="bi bi-person-fill"></i> Profile
                        </a>
                    </div>
                    <div>
                        <a class="dropdown-item" href="<?=base_url('logout')?>">
                            <i class="bi bi-box-arrow-in-right"></i> Sign Out
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <script>
        // Function to set the active link based on the current URL
        function setActiveLink() {
            var currentUrl = window.location.href;
            $(".sidebar ul li.active").removeClass('active');
            if (currentUrl.indexOf("dashboard") !== -1) {
                $("a[href*='dashboard']").closest('li').addClass('active');
            } 
            else if (currentUrl.indexOf("admin/list") !== -1 || currentUrl.indexOf("admin/edit") !== -1) {
                $("a[href*='admin/list']").closest('li').addClass('active');
            } 
            else if (currentUrl.indexOf("student/list") !== -1 || currentUrl.indexOf("student/edit") !== -1) {
                $("a[href*='student/list']").closest('li').addClass('active');
            } 
            else if (currentUrl.indexOf("teacher/list") !== -1 || currentUrl.indexOf("teacher/edit") !== -1) {
                $("a[href*='teacher/list']").closest('li').addClass('active');
            } 
            else if (currentUrl.indexOf("subject/list") !== -1 || currentUrl.indexOf("subject/edit") !== -1) {
                $("a[href*='subject/list']").closest('li').addClass('active');
            }
            else if (currentUrl.indexOf("lesson/list") !== -1 || currentUrl.indexOf("lesson/edit") !== -1) {
                $("a[href*='lesson/list']").closest('li').addClass('active');
            } 
            else if (currentUrl.indexOf("sales/salary") !== -1 || currentUrl.indexOf("sales/edit") !== -1) {
                $("a[href*='sales/salary']").closest('li').addClass('active');
            }
            else if (currentUrl.indexOf("profile/list") !== -1) {
                $("a[href*='profile/list']").closest('li').addClass('active');
            }
            else if (currentUrl.indexOf("logout/list") !== -1) {
                    $("a[href*='profile/list']").closest('li').addClass('active');
            }
            else if (currentUrl.indexOf("annoucement/subjectList") !== -1 || currentUrl.indexOf("annoucement/list") !== -1 || currentUrl.indexOf("annoucement/add_annoucement_view") !== -1) {
                    $("a[href*='annoucement/subjectList']").closest('li').addClass('active');
            }
            else if (currentUrl.indexOf("announcement/subjectList") !== -1 || currentUrl.indexOf("announcement/list") !== -1) {
                            $("a[href*='announcement/subjectList']").closest('li').addClass('active');
            }
            else if (currentUrl.indexOf("payment/list") !== -1) {
                            $("a[href*='payment/list']").closest('li').addClass('active');
            }
            else if (currentUrl.indexOf("salary/list") !== -1 || currentUrl.indexOf("salary/invoice") !== -1) {
                            $("a[href*='salary/list']").closest('li').addClass('active');
            }
        }

        // Call the setActiveLink function when the page loads
        $(document).ready(function () {
            setActiveLink();
        });

        // Your other JavaScript code...
    </script>