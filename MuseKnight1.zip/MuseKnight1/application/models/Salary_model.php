<?php
class Salary_model extends MY_Model
{
    public function __construct()
    {
        $this->set_table('teacher_salary'); // Set the correct table name
    }

    public function updateStatus($salary_id, $status)
    {
        $this->db->where('id', $salary_id);
        $this->db->update('teacher_salary', array('status' => $status));
    }

    public function getSalaryByTeacherId($teacher_id)
    {
        // Query the database to get a salary record by teacher_id
        $query = $this->db->get_where('teacher_salary', array('teacher_id' => $teacher_id));
        return $query->row_array(); // Return the result as an array
    }

    public function updateSalary($id, $data)
    {
        // Update the 'salary' record with the provided ID using the given data
        $this->db->where('id', $id);
        $this->db->update('teacher_salary', $data);
    }

    public function insertSalary($data)
    {
        // Insert a new 'salary' record with the provided data
        $this->db->insert('teacher_salary', $data);
    }
}
