<?php

class Dashboard extends MY_Controller {

    // Predefine function in controller

	public function __construct()
{
    parent::__construct();
    $this->data['folder_name'] = 'teacher';
    $this->load->model("Admin_model");
    $this->load->model("StudentSubject_model");
    $this->load->model("Student_model");
    $this->load->model("Sales_model");
    $this->load->model("Salary_model");
    $this->load->model("Annoucement_model"); 
    $this->load->model("TeacherSubject_model"); 
    $this->load->model("Teacher_model");
    $this->auth_validate();
}


public function index() {
    $teacherId = $this->session->userdata('user_id');
    $this->data['students'] = $this->Student_model->get_where(array('is_deleted' => 0));
    $this->data['subjects'] = $this->Subject_model->get_where(array('is_deleted' => 0));
    $this->data['student_subjects'] = $this->StudentSubject_model->get_where(array('teacher_id' => $teacherId, 'is_deleted' => 0));
    
    // Get the current day
    $currentDay = date('l');

    // Filter student_subjects based on the current day
    $filteredStudentSubjects = array_filter($this->data['student_subjects'], function ($subject) use ($currentDay) {
        return strtolower($subject['day']) == strtolower($currentDay);
    });

    // Extract student IDs from filtered subjects
    $studentIds = array_column($filteredStudentSubjects, 'student_id');

    // Filter students based on the extracted student IDs
    $filteredStudents = array_filter($this->data['students'], function ($student) use ($studentIds) {
        return in_array($student['id'], $studentIds);
    });

    // Pass the filtered students to the view
    $this->data['filtered_students'] = $filteredStudents;

  // Pass the teacher_id to the view
  $this->data['teacher_id'] = $teacherId;

    // Get the current month
    $currentMonth = date('F');
    
    // Get the teacher subjects related to the teacher
    $teacherSubjects = $this->TeacherSubject_model->get_where(array('teacher_id' => $teacherId, 'is_deleted' => 0));
    $subjectIds = array_column($teacherSubjects, 'subject_id');

    // Get the teacher's salary for the current month with status equal to "0"
    $currentMonthSalary = $this->Salary_model->get_where(array('teacher_id' => $teacherId, 'month' => $currentMonth,  'is_deleted' => 0));
    

    // Initialize an array to store the latest two announcements for each teacher subject
    $latestAnnouncementsBySubject = [];

    // Loop through each teacher subject and get the latest two announcements
    foreach ($subjectIds as $subjectId) {
        $latestAnnouncements = $this->Annoucement_model->get_latest_announcements_for_subject($subjectId, 2);

        foreach ($latestAnnouncements as $announcementKey => $announcement) {
            $sender_id = $announcement['sender_id'];
            $sender_type = $announcement['sender_type'];

            if ($sender_type == 'admin') {
                $latestAnnouncements[$announcementKey]['senderName'] = 'Admin';
            } elseif ($sender_type == 'teacher') {
                $sender_info = $this->Teacher_model->getOne(array('id' => $sender_id, 'is_deleted' => 0));
                if ($sender_info) {
                    $latestAnnouncements[$announcementKey]['senderName'] = $sender_info['name'];
                } else {
                    $latestAnnouncements[$announcementKey]['senderName'] = 'Unknown name';
                }
            } else {
                // Handle additional sender types if needed
                // $sender_info = $this->AdditionalSenderModel->getOne(array('id' => $sender_id, 'is_deleted' => 0));
                // $latestAnnouncements[$announcementKey]['senderName'] = $sender_info ? $sender_info['name'] : 'Unknown name';
            }

            // Fetch subject title from the 'subject' table
            $subject_info = $this->Subject_model->getOne(array('id' => $subjectId, 'is_deleted' => 0));
            $latestAnnouncements[$announcementKey]['subject_title'] = $subject_info ? $subject_info['title'] : '';
        }

        $latestAnnouncementsBySubject[$subjectId] = $latestAnnouncements;
    }

    // Pass data to the view
    $this->data['latest_announcements'] = $latestAnnouncementsBySubject;
    $this->data['current_month_salary'] = $currentMonthSalary;

    // Load your view with the modified data
    $this->load->view("teacher/dashboard", $this->data);
}

}
