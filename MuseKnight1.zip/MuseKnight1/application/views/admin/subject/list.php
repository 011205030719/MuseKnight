<?php $this->load->view("admin/nav"); ?>
<?php $this->load->view("layouts/header"); ?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/dt/jq-2.1.4,jszip-2.5.0,pdfmake-0.1.18,dt-1.10.9,af-2.0.0,b-1.0.3,b-colvis-1.0.3,b-html5-1.0.3,b-print-1.0.3,se-1.0.1/datatables.min.css"/>

<style>
    .custom-module{
        margin-top: -10px; 
        margin-bottom: 20px; 
        background-color: #703be7; 
        height: 40px; 
        width: 350px; 
        display: flex; 
        justify-content: center; 
        align-items: center; 
        position: relative; 
        border-radius: 25px; 
        color: #fff; 
        text-align: left;
        font-size: 18px;
    }

    .status{
        color: white;
        font-size:12px;
        font-weight:600;
        padding-top:3px;
        padding-bottom:5px;
        padding-left:10px;
        padding-right:10px;
        border-radius:10px;
    }

    /* .custom-module:hover{
        background-color: #422387; 
    } */
</style>

<div class="container-fluid" style="padding-left: 20%; padding-right: 5%; padding-top: 3%;">
    <div class="header" style=" width:100%;">
        <div style="position: sticky; top: 0; z-index: 1000; background-color:#E6E6FA; border: 0px solid rgba(100, 100, 100, 1); border-radius: 12px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); padding: 10px; margin: 1%;">
            <span>Home / </span>
            <a href="<?= base_url($folder_name.'/subject/list') ?>" style="text-decoration:none; color:black;">Subject List</a>
        </div>
    <div>
    <div style="text-align: end; margin-bottom:20px;">
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#createModal">Add New Subject</button>
        <!-- Modal -->
        <div class="modal fade" id="createModal" tabindex="-1" role="dialog" aria-labelledby="createModalTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" style="max-width: 60%;" role="document">
                <div class="modal-content">
                    <form method="POST" id="create_form" action="<?=base_url('admin/subject/store')?>">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle">Create New Subject</h5>
                            <a style="padding-left: 15px; padding-right: 15px;" type="button" data-dismiss="modal" aria-label="Close">x</a>
                        </div>
                        <div class="modal-body">
                                <div class="row" style="text-align: start;" >
                                    
                                    <div class="col-6 form-group mb-2">
                                        <label for="email" style="font-weight: 500;" class="mb-2">Title</label>
                                        <input required type="text" id="title" class="form-control" name="title" placeholder="Enter Subject Title">
                                    </div>
                                    <div class="col-6 form-group mb-2">
                                        <label for="description" style="font-weight: 500;" class="mb-2">Description</label>
                                        <input required type="text" id="description" class="form-control" name="description" placeholder="Enter description">
                                    </div>
                                    <!-- <div class="col-6 form-group mb-2">
                                        <label for="teacher_id" style="font-weight: 500;" class="mb-2">Teacher Name</label>
                                        <select name="teacher_id" id="teacher_id" class="form form-select">
                                            <option value="">Select Teacher Name</option>
                                            <?php foreach ($teachers as $teacher) { ?>
                                                <option value="<?= $teacher['id'] ?>"><?= $teacher['name'] ?></option>
                                            <?php } ?>
                                        </select>
                                    </div> -->
                                    <div class="col-6 form-group mb-2">
                                        <label for="fee" style="font-weight: 500;" class="mb-2">Tuition Fees</label>
                                        <input required type="text" id="fee" class="form-control" name="fee" placeholder="Enter subject Fees">
                                    </div>
                                    
                                </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="card shadow">
        <div style="padding: 30px;">
            <table id="lecturerTable" style="background-color: white; width:100%; max-height: 400px; overflow: auto; display: block;" class="table table-bordered">
                <thead>
                    <tr style="border-bottom: 2px solid lightgray;">
                        <th style="padding:5px; width: 3%;">#</th>
                        <th style="padding:5px; width: 10%;">Code</th>
                        <th style="padding:5px; width: 10%;">Title</th>
                        <th style="padding:5px; width: 10%;">Description</th>
                        <th style="padding:5px; width: 15%;">Fees</th>
                        <th style="padding:5px; width: 10%;">Created Date</th>
                        <th style="padding:5px; width: 15%;">Action</th>
                    </tr>
                </thead>
                <tbody >
                <?php foreach($subjects as $key=> $subject){?>
                    <tr class="table_row">
                        <th scope="row"><?= $key + 1 ?></th>
                        <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $subject['code'] ?></td>
                        <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $subject['title'] ?></td>
                        <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $subject['description'] ?></td>
                        <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $subject['fee'] ?></td>
                        <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= date('Y-m-d', strtotime($subject['created_date'])) ?></td>
                        <td style="width:15%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                            <a href="<?=base_url('admin/subject/edit/'. $subject['id'])?>" class="btn btn-success"><i class="bi bi-pencil-square"></i></a>
                            <a href="<?=base_url('admin/subject/delete/'. $subject['id'])?>" onclick="return confirmSubmit();" class="btn btn-danger"><i class="bi bi-trash3"></i></a>
                        </td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- DataTables and Bootstrap DataTables -->
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<!-- DataTables library -->
<script type="text/javascript" src="https://cdn.datatables.net/r/dt/jq-2.1.4,jszip-2.5.0,pdfmake-0.1.18,dt-1.10.9,af-2.0.0,b-1.0.3,b-colvis-1.0.3,b-html5-1.0.3,b-print-1.0.3,se-1.0.1/datatables.min.js"></script>


<script>
function confirmSubmit() {
    // Display a confirmation dialog
    if (window.confirm("Are you sure you want to delete this subject?")) {
        document.getElementById("myForm").submit();
        return true;
    } else {
        return false;
    }
}

$(document).ready(function() {
        $('#lecturerTable').DataTable({
            dom: 'lBfrtip',
            lengthMenu: [10, 25, 50],
            searching: true,
            buttons: [
                {
                    extend: 'excel',
                    text: 'Download Data',
                    className: 'btn btn-outline-success',
                    init: function(api, node, config) {
                        $(node).removeClass('dt-button');
                        $(node).css({
                            'margin-left': '10%',
                            'margin-bottom': '10%',
                            'height': '30px',
                            'width': '150px',
                            'font-size': '17px',
                            'display': 'flex',
                            'align-items': 'center'
                        });
                    }
                }
            ]
        });
    });
</script>
