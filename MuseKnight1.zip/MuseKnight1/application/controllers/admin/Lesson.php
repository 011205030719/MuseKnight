<?php

class Lesson extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->data['folder_name'] = 'admin';
        $this->load->model("StudentSubject_model");
        $this->load->model("Student_model"); 
        $this->load->model("Teacher_model"); 
        $this->load->model("Subject_model");
        $this->load->model("TeacherSubject_model");
        $this->load->model("Sales_model"); // Load the Sales_model
        $this->auth_validate();
    }

    public function index() {
        $this->data['subjects'] = $this->Subject_model->get_where(array('is_deleted' => 0));
        $this->data['teacher_subjects'] = $this->TeacherSubject_model->get_where(array('is_deleted' => 0));
        $this->data['student_subjects'] = $this->StudentSubject_model->get_where(array('is_deleted'=>0));
        $this->data['teachers'] = $this->Teacher_model->get_where(array('is_deleted' => 0));
        $this->data['students'] = $this->Student_model->get_where(array('is_deleted'=>0));
        $this->load->view("admin/lesson/list", $this->data);
    }

    public function store() {
        if ($this->input->post()) {
            $teacher_id = $this->input->post('teacher_id');
            $student_id = $this->input->post('student_id');
            $subject_id = $this->input->post('subject_id');
    
            if (empty($teacher_id) || empty($student_id) || empty($subject_id)) {
                redirect(base_url('admin/lesson/list?error=foreign_key_empty'));
                return;
            }
    
            $grade_level = $this->input->post('grade_level');
            $fee = $this->input->post('fee');
    
            // Store data in the 'student_subject' table
            $student_subject_data = array(
                'student_id' => $student_id,
                'subject_id' => $subject_id,
                'grade_level' => $grade_level,
                'fee' => $fee,
                // You can include other columns as needed.
            );
    
            $student_subject_id = $this->StudentSubject_model->insert($student_subject_data);
    
            // Store data in the 'teacher_subject' table
            $teacher_subject_data = array(
                'teacher_id' => $teacher_id, // Ensure that teacher_id is set
                'subject_id' => $subject_id,
                'student_id' => $student_id,
                'lesson_id' => $student_subject_id,
            );
    
            $this->TeacherSubject_model->insert($teacher_subject_data);
    
            // Redirect to the lesson list page
            redirect(base_url('admin/lesson/list'));
        }
    }
    
    
    
    
    
    private function generate_serial_number($student_id) {
        $serials = $this->Sales_model->getSerialNumbersForStudent($student_id);
        $largestNumber = 0;
        
        foreach ($serials as $str) {
            $matches = [];
            if (preg_match('/(\d+)/', $str, $matches)) {
                $number = intval($matches[0]);
                if ($number > $largestNumber) {
                    $largestNumber = $number;
                }
            }
        }
    
        return 'S' . str_pad(($largestNumber + 1), 5, '0', STR_PAD_LEFT);
    }
    

    public function edit($id) {
        $this->data['student_subject'] = $this->StudentSubject_model->getOne(array('id' => $id, 'is_deleted' => 0));
        
        // Check if teacher_subject data exists before accessing its elements
        $teacher_id = $this->data['student_subject']['teacher_id'];
        if (!empty($teacher_id)) {
            $this->data['teacher_subject'] = $this->TeacherSubject_model->getOne(array('id' => $teacher_id, 'is_deleted' => 0));
        } else {
            // Handle the case where teacher_subject data is not available
            // You can set $this->data['teacher_subject'] to an empty array or handle it as needed.
            $this->data['teacher_subject'] = [];
        }
        
        $this->data['subjects'] = $this->Subject_model->get_where(array('is_deleted' => 0));
        $this->data['teacher_subjects'] = $this->TeacherSubject_model->get_where(array('is_deleted' => 0));
        $this->data['student_subjects'] = $this->StudentSubject_model->get_where(array('is_deleted' => 0));
        $this->data['teachers'] = $this->Teacher_model->get_where(array('is_deleted' => 0));
        $this->data['students'] = $this->Student_model->get_where(array('is_deleted' => 0));
        
        // Add debugging information to check the results
        if (empty($this->data['teacher_subject'])) {
            // Log or print debug information to check the issue.
            log_message('error', 'Teacher subject data is null for teacher_id: ' . $teacher_id);
        }
        
        $this->load->view("admin/lesson/edit", $this->data);
    }
    
    
    

    public function update($id) {
        if ($this->input->post()) {
            $sql = array(
                'grade_level' => $this->input->post('grade_level'),
                'day' => $this->input->post('day'),
                'fee' => $this->input->post('fee'),
                'start_time' => $this->input->post('start_time'),
                'end_time' => $this->input->post('end_time'),
                'modified_date' => date('Y-m-d H:i:s'),
            );

            $this->StudentSubject_model->update(array('id' => $id), $sql);

            redirect(base_url('admin/lesson/list'));
        }
    }

    public function delete($id) {
        $this->StudentSubject_model->update(array('id' => $id), array('is_deleted' => 1));
        redirect(base_url('admin/lesson/list'));
    }
}
