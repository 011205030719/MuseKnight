<?php $this->load->view("admin/nav"); ?>
<?php $this->load->view("layouts/header"); ?>


<div class="container-fluid" style="padding-left: 20%; padding-right: 5%; padding-top: 3%;">
    <div class="header" style=" width:100%;">
        <div style="position: sticky; top: 0; z-index: 1000; background-color:#E6E6FA; border: 0px solid rgba(100, 100, 100, 1); border-radius: 12px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); padding: 10px; margin: 1%;">
            <span>Home / </span>
            <a href="<?= base_url($folder_name.'/student/list') ?>" style="text-decoration:none; color:black;">Student List</a>
            <span>/</span>
            <a href="<?= base_url($folder_name.'/student/edit') ?>" style="text-decoration:none; color:black;">Student Edit</a>
        </div>
    <div>
    <form method="POST" id="create_form" action="<?=base_url('admin/student/update/'.$student['id'])?>">
        <div style="text-align: end; margin-bottom:20px;">
            <a href="<?=base_url('admin/student/list')?>" class="btn btn-secondary">Back</a>
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bd-example-modal-lg">Add New Lessons</button>
        </div>
        <div class="card shadow">
            <div style="padding: 30px;">
                <h2>Student Information</h2>
                    <div class="row" style="text-align: start; margin-bottom:10px" >
                        <div class="col-6 form-group mb-2">
                            <label for="serial" style="font-weight: 500;" class="mb-2">Serial ID</label>
                            <input readonly type="text" id="serial" class="form-control bg-light" name="serial" value="<?= $student['serial'] ?>">
                        </div>
                        <div class="col-6 form-group mb-2">
                            <label for="name" style="font-weight: 500;" class="mb-2">Name</label>
                            <input required type="text" id="name" class="form-control" name="name" value="<?= $student['name'] ?>">
                        </div>
                        <div class="col-6 form-group mb-3">
                            <label for="gender" style="font-weight: 500;" class="mb-2">Gender</label>
                                <select name="gender" id="gender" class="form form-select">
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>

                        </div>
                        <div class="col-6 form-group mb-2">
                            <label for="email" style="font-weight: 500;" class="mb-2">Email</label>
                            <input required type="email" id="email" class="form-control" name="email" value="<?= $student['email'] ?>">
                        </div>
                        <div class="col-6 form-group mb-2">
                            <label for="mobile" style="font-weight: 500;" class="mb-2">Mobile</label>
                            <input required type="text" id="mobile" class="form-control" name="mobile" value="<?= $student['mobile'] ?>">
                        </div>
                        <div class="col-6 form-group mb-3">
                            <label for="password" style="font-weight: 500;" class="mb-2">Password</label>
                            <input required type="password" id="password" class="form-control" name="password" value="<?= $student['password'] ?>">
                        </div>
                        <div class="col-6 form-group mb-3">
                            <label for="status" style="font-weight: 500;" class="mb-2">Status</label>
                                <select name="status" id="status" class="form form-select">
                                    <option value="0">Active</option>
                                    <option value="1">Inactive</option>
                                </select>
                        </div>
                    </div>
                                            <!-------------------------------------student subject information-------------------------------------------------------------->
                                            <!-- <div class="tab-pane fade show active" id="subject" role="tabpanel" aria-labelledby="subject-tab">
                            <ul class="nav nav-tabs mb-3" id="pills-tab" role="tablist" style="margin-top:1%;">
                                <?php foreach ($student_subjects as $student_subject): ?>
                                    <?php if ($student_subject['status'] == 0): ?>
                                    <li class="nav-item">
                                        <a class="nav-link <?= ($student_subject['id'] == $default_subject_id) ? 'active' : '' ?>"
                                        id="subject-<?= $student_subject['subject_id'] ?>"
                                        data-toggle="pill"
                                        href="#subject<?= $student_subject['subject_id'] ?>"
                                        role="tab"
                                        aria-controls="subject<?= $student_subject['subject_id'] ?>"
                                        aria-selected="<?= ($student_subject['id'] == $default_subject_id) ? 'true' : 'false' ?>">
                                            <?= $subjectTitles[$student_subject['subject_id']] ?>
                                        </a>
                                    </li>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </ul>
                            <div class="row" style="text-align: start; margin-bottom:10px" >
                                <div class="tab-content" id="pills-tabContent">
                                    <?php foreach ($student_subjects as $student_subject): ?>
                                    <div class="tab-pane fade <?= ($student_subject['id'] == $default_subject_id) ? 'show active' : '' ?>"
                                        id="subject<?= $student_subject['subject_id'] ?>"
                                        role="tabpanel"
                                        aria-labelledby="subject-<?= $student_subject['subject_id'] ?>">
                                        <div class="col-6 form-group mb-2">
                                            <label for="grade_level" style="font-weight: 500;" class="mb-2">Grade</label>
                                            <span id="grade_level" class="form-control">
                                                <?= $student_subject['grade_level'] ?>
                                            </span>
                                        </div>

                                        <div class="col-6 form-group mb-2">
                                            <label for="teacher_id" style="font-weight: 500;" class="mb-2">Teacher</label>
                                            <?php
                                            // Find the selected teacher
                                            $selected_teacher = null;
                                            foreach ($teachers as $teacher) {
                                                if ($teacher['id'] == $student_subject['teacher_id']) {
                                                    $selected_teacher = $teacher;
                                                    break;
                                                }
                                            }
                                            ?>
                                            <div id="teacher_name" class="form-control">
                                                <?= ($selected_teacher) ? $selected_teacher['name'] : 'Select Teacher' ?>
                                            </div>
                                        </div>




                                           <div class="col-6 form-group mb-2">
                                                <label for="fee">Tuition Price (RM)</label>
                                                <input type="text" id="fee" class="form-control bg-light" name="fee" value="<?= isset($student_subject['fee']) ? $student_subject['fee'] : '' ?>" readonly>
                                            </div> 

                                            <div class="col-6 form-group mb-2">
                                                <label for="day" style="font-weight: 500;" class="mb-2">Day</label>
                                                <span id="grade_level" class="form-control">
                                                    <?= htmlspecialchars($student_subject['day']) ?>
                                                </span>
                                            </div>

                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                 -->
                <div style="text-align: end; ">
                    <button type="submit" class="btn btn-primary">Save Changed</button>
                </div>
        
            </div>
        </div>
    </form>
    <div style="text-align: end; margin-top:1%;">
                
                
                <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg" styel="width: 200px;">
                        <form method="POST" id="create_form" action="<?=base_url('admin/student/addLesson')?>">
                            <div class="modal-content">
                                <div class="subject detail" style="padding-left:3%; padding-right:3%; margin-top:1%;margin-bottom:1%;">
                                    <h4 style="text-align: start;font-family:'AmstelvarAlpha';">Add Subject</h4>
                                    <hr>
                                    <div class="row" style="text-align: start; margin-bottom:10px">
                                        
                                        <input readonly type="text" id="student_id" class="form-control bg-light d-none" name="student_id" value="<?= $student['id'] ?>">

                                            <div class="col-6 form-group mb-2">
                                                <label for="subject_id">Subject</label>
                                                    <select name="subject_id" id="subject_id" class="form-select">
                                                        <option value="" disabled selected>Select Subject</option>
                                                            <?php foreach ($subjects as $subject) { ?>
                                                                <option value="<?= $subject['id'] ?>"><?= $subject['title'] ?></option>
                                                            <?php } ?>
                                                    </select>
                                            </div>

                                            <div class="col-6 form-group mb-2">
                                                <label for="teacher_id" style="font-weight: 500;" class="mb-2">Teacher</label>
                                                    <select name="teacher_id" id="teacher_id" class="form form-select">
                                                        <option value="" disabled selected>Select Teacher</option>
                                                            <?php foreach ($teachers as $teacher) { ?>
                                                                <option value="<?= $teacher['id'] ?>"><?= $teacher['name'] ?></option>
                                                            <?php } ?>
                                                    </select>
                                            </div>
                                            <div class="col-6 form-group mb-2">
                                                <label for="grade_level" style="font-weight: 500;" class="mb-2">Grade</label>
                                                <select id="grade_level" class="form form-select" name="grade_level">
                                                    <option value="Beginner">Beginner</option>
                                                    <option value="Grade 1">Grade 1</option>
                                                    <option value="Grade 2">Grade 2</option>
                                                    <option value="Grade 3">Grade 3</option>
                                                    <option value="Grade 4">Grade 4</option>
                                                    <option value="Grade 5">Grade 5</option>
                                                    <option value="Grade 6">Grade 6</option>
                                                    <option value="Grade 7">Grade 7</option>
                                                    <option value="Grade 8">Grade 8</option>
                                                </select>
                                            </div>

                                            <div class="col-6 form-group mb-2">
                                                <label for="tuition">Tuition Price (RM)</label>
                                                <input type="text" id="tuition" class="form-control" name="fee" readonly>
                                            </div>


                                            <div class="col-6 form-group mb-2">
                                                <label for="day">Day</label>
                                                    <select class="form-select" id="day" name="day">
                                                        <option value="" disabled selected>Select Day</option>
                                                        <option value="Monday">Monday</option>
                                                        <option value="Tuesday">Tuesday</option>
                                                        <option value="Wednesday">Wednesday</option>
                                                        <option value="Thursday">Thursday</option>
                                                        <option value="Friday">Friday</option>
                                                        <option value="Saturday">Saturday</option>
                                                        <option value="Sunday">Sunday</option>
                                                    </select>
                                            </div>

                                            <div class="col-6 form-group mb-2">
                                                <label for="time_range">Time Range</label>
                                                <select class="form-select" id="time_range" name="time_range">
                                                    <option value="time_range" disabled selected>Select Time Range</option>
                                                </select>
                                            </div>
                                            <div style="text-align: end; ">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary">Add Lesson</button>
                                            </div>
                                    </div>
                                </div>

                            </div>
                        </form>
                    </div>
                </div>
    </div>
</div>

<script>
   // Function to calculate and display the tuition fee
function calculateTuitionFee() {
    // Get the selected grade from the dropdown
    const selectedGrade = document.getElementById('grade_level').value;

    // Set the initial tuition fee to RM120 for beginners
    let tuitionFee = 120;

    // Check if the selected grade is not "Beginner" and calculate the tuition fee accordingly
    if (selectedGrade !== "Beginner") {
        const gradeLevel = parseInt(selectedGrade.replace("Grade ", ""));
        // Calculate the tuition fee (RM30 per grade level after Beginner)
        tuitionFee += (gradeLevel - 0) * 30;
    }

    // Update the "Tuition Price (RM)" input field with the calculated fee
    document.getElementById('tuition').value = tuitionFee.toFixed(2);
}

// Event listener to call the calculateTuitionFee function when the grade selection changes
document.getElementById('grade_level').addEventListener('change', calculateTuitionFee);

// Initial calculation when the page loads
calculateTuitionFee();


</script>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<script>
    $(document).ready(function () {
        $('#subject_id').on('change', function () {
            var subjectId = $(this).val();
            if (subjectId) {
                $.ajax({
                    type: 'POST',
                    url: '<?= base_url("admin/student/get_teachers_by_subject") ?>', // Update the URL to your controller method
                    data: {subject_id: subjectId},
                    dataType: 'json',
                    success: function (data) {
                        var options = '<option value="" disabled selected>Select Teacher</option>';
                        for (var i = 0; i < data.length; i++) {
                            options += '<option value="' + data[i].id + '">' + data[i].name + '</option>';
                        }
                        $('#teacher_id').html(options);
                    }
                });
            } else {
                // Reset teacher dropdown if no subject is selected
                $('#teacher_id').html('<option value="" disabled selected>Select Teacher</option>');
            }
        });
    });
</script>

<script>
$(document).ready(function () {
    $('#subject_id, #teacher_id, #day').on('change', function () {
        var subjectId = $('#subject_id').val();
        var teacherID = $('#teacher_id').val();
        var Day = $('#day').val();
        
        // Add this line to get student ID
        var studentId = $('#student_id').val(); // Adjust the selector based on your HTML structure

        if (subjectId && teacherID && Day && studentId) {
            $.ajax({
                type: 'POST',
                url: '<?= base_url("admin/student/getFreeTimeSlots") ?>',
                data: { subject_id: subjectId, teacher_id: teacherID, day: Day, student_id: studentId },
                dataType: 'json',
                success: function (data) {
                    // Ensure the response is an array
                    if (Array.isArray(data)) {
                        var options = '<option value="" disabled selected>Select Time Range</option>';
                        for (var i = 0; i < data.length; i++) {
                            options += '<option value="' + data[i] + '">' + data[i] + '</option>';
                        }
                        $('#time_range').html(options);
                    } else {
                        console.error('Invalid response from server:', data);
                    }
                },

                error: function (xhr, status, error) {
                    console.error('Error:', error);
                    console.log('Server Response:', xhr.responseText); // Log the server response
                }
            });
        } else {
            // Reset time range dropdown if any of the values is not selected
            $('#time_range').html('<option value="" disabled selected>Select Time Range</option>');
        }
    });
});

</script>