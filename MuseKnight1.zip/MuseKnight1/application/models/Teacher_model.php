<?php
class Teacher_model extends MY_Model {
    public function __construct(){
        $this->set_table('teacher');
    }
    public function get_all() {
        return $this->db->get('teacher')->result_array();
    }

    public function getTeacherName($teacher_id) {
        $this->db->select('name');
        $this->db->where('id', $teacher_id);
        $query = $this->db->get('teacher');
    
        if ($query->num_rows() > 0) {
            $row = $query->row();
            return $row->name; 
        } else {
            return 'Unknown';
        }
    }

    public function getTeacherSubjects($teacherId) {
        $this->db->select('subject.title');
        $this->db->from('teacher_subject');
        $this->db->join('subject', 'teacher_subject.subject_id = subject.id');
        $this->db->where('teacher_subject.teacher_id', $teacherId);
        $query = $this->db->get();
    
        return $query->result_array();
    }
    
    public function get_teachers_by_subject($subjectId)
{
    $this->db->select('t.id, t.name');
    $this->db->from('teacher t');
    $this->db->join('teacher_subject ts', 't.id = ts.teacher_id');
    $this->db->where('ts.subject_id', $subjectId);
    $this->db->where('t.is_deleted', 0);
    $this->db->where('ts.is_deleted', 0);
    $query = $this->db->get();
    return $query->result_array();
}
public function getTeacherEmailById($teacher_id) {
    $this->db->select('email');
    $this->db->where('id', $teacher_id);
    $query = $this->db->get('teacher');

    if ($query->num_rows() > 0) {
        $row = $query->row();
        return $row->email;
    } else {
        return null; // Student not found
    }
}
// Teacher_model.php model
public function getTeacherById($teacherId) {
    $this->db->select('*');
    $this->db->from('teacher');
    $this->db->where('id', $teacherId);
    $query = $this->db->get();

    return $query->row_array();
}


}
