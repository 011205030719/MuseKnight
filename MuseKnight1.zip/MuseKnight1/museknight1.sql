-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 13, 2024 at 10:55 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `museknight1`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `serial` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `serial`, `name`, `email`, `password`, `mobile`, `status`, `is_deleted`, `created_date`, `modified_date`) VALUES
(1, 'AD00001', 'Admin', 'miao_admin@gmail.com', 'Admin', '0123456789', 0, 0, '2023-10-08 21:12:08', NULL),
(2, 'SP00001', 'Super Admin', 'muijing0112@gmail.com', 'superadmin', '0183712388', 0, 0, '2023-11-24 22:22:22', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `annoucement`
--

CREATE TABLE `annoucement` (
  `id` int(8) NOT NULL,
  `subject_id` int(1) NOT NULL,
  `sender_id` int(1) NOT NULL,
  `sender_type` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `is_deleted` int(1) NOT NULL DEFAULT 0,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `annoucement`
--

INSERT INTO `annoucement` (`id`, `subject_id`, `sender_id`, `sender_type`, `title`, `description`, `receiver_id`, `is_deleted`, `created_date`, `modified_date`) VALUES
(111, 15, 1, 'admin', 'First Post Announcement', 'Testing Post of Violin ', 0, 0, '2023-12-01 09:32:53', NULL),
(112, 16, 1, 'admin', 'First Post Announcement', 'Testing Post Piano ', 0, 0, '2023-12-01 09:34:06', NULL),
(113, 17, 1, 'admin', 'First post announcement', 'Testing Post Guitar Announcement', 0, 0, '2023-12-01 09:34:42', NULL),
(114, 18, 1, 'admin', 'testing ', 'post announcement', 0, 0, '2023-12-01 14:20:04', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `serial` varchar(50) NOT NULL,
  `student_id` int(11) NOT NULL,
  `subject_detail` text DEFAULT NULL,
  `total_amount` float(10,2) DEFAULT 0.00,
  `month` varchar(50) NOT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT 0,
  `is_deleted` int(1) NOT NULL DEFAULT 0,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `serial`, `student_id`, `subject_detail`, `total_amount`, `month`, `payment_method`, `payment_date`, `image`, `status`, `is_deleted`, `created_date`, `modified_date`) VALUES
(208, 'PM00001', 177, '[{\"subject_id\":\"16\",\"grade_level\":\"Grade 2\",\"fee\":\"180.00\"}]', 180.00, 'December', 'tng', '2023-12-01', 'cimb131.png', 2, 0, '2023-12-01 10:06:32', '2023-12-01 03:08:40'),
(209, 'PM00002', 178, '[{\"subject_id\":\"17\",\"grade_level\":\"Grade 5\",\"fee\":\"270.00\"}]', 270.00, 'December', 'fpx', '2023-12-01', 'cimb7.png', 1, 0, '2023-12-01 10:06:59', '2023-12-01 07:25:10'),
(210, 'PM00003', 179, '[{\"subject_id\":\"15\",\"grade_level\":\"Grade 8\",\"fee\":\"360.00\"}]', 360.00, 'December', NULL, NULL, NULL, 0, 0, '2023-12-01 10:07:42', NULL),
(211, 'PM00004', 180, '[{\"subject_id\":\"18\",\"grade_level\":\"Grade 4\",\"fee\":\"240.00\"}]', 240.00, 'December', NULL, NULL, NULL, 0, 0, '2023-12-01 14:12:47', NULL),
(212, 'PM00005', 181, '[{\"subject_id\":\"18\",\"grade_level\":\"Grade 8\",\"fee\":\"360.00\"}]', 360.00, 'December', NULL, NULL, NULL, 0, 0, '2023-12-01 14:17:53', NULL),
(213, 'PM00006', 178, '[{\"subject_id\":\"17\",\"grade_level\":\"Grade 5\",\"fee\":\"270.00\"}]', 270.00, 'January', NULL, NULL, NULL, 0, 0, '2023-12-01 14:26:09', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `serial` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `modified_date` datetime DEFAULT NULL,
  `gender` varchar(10) NOT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `serial`, `name`, `email`, `password`, `mobile`, `status`, `is_deleted`, `created_date`, `modified_date`, `gender`, `image`) VALUES
(177, 'ST00001', 'Oliver', 'Oliver@gmail.com', '111', '0122365495', 0, 0, '2023-12-01 10:06:32', NULL, 'Female', '11_(2)122.jpg'),
(178, 'ST00002', 'Alex', 'Alex@gmail.com', 'Miao_01111', '0122365495', 0, 0, '2023-12-01 10:06:59', '2023-12-01 07:27:20', 'Male', 'images_(1)81.jpeg'),
(179, 'ST00003', 'Kimberly', 'Kimberly@gmail.com', 'Miao_0112', '0123456789', 0, 0, '2023-12-01 10:07:42', '2023-12-01 07:29:41', 'Female', NULL),
(180, 'ST00004', 'Lim Chee Ying', 'zzzsoonping@gmail.com', '111', '0122365495', 0, 0, '2023-12-01 14:12:47', NULL, 'Female', NULL),
(181, 'ST00005', 'Karen', 'Karen@gmail.com', '111', '0122365495', 0, 0, '2023-12-01 14:17:53', NULL, 'Female', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `student_subject`
--

CREATE TABLE `student_subject` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `subject_id` int(11) NOT NULL,
  `grade_level` varchar(255) NOT NULL,
  `fee` float(10,2) NOT NULL,
  `day` varchar(50) NOT NULL,
  `time_range` varchar(20) NOT NULL,
  `status` int(1) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_subject`
--

INSERT INTO `student_subject` (`id`, `student_id`, `teacher_id`, `subject_id`, `grade_level`, `fee`, `day`, `time_range`, `status`, `is_deleted`, `created_date`, `modified_date`) VALUES
(367, 177, 57, 16, 'Grade 2', 180.00, 'Wednesday', '09:00 - 10:00', 0, 0, '2023-12-01 10:06:43', NULL),
(368, 178, 59, 17, 'Grade 5', 270.00, 'Saturday', '10:00 - 11:00', 0, 0, '2023-12-01 10:07:12', NULL),
(369, 179, 55, 15, 'Grade 8', 360.00, 'Sunday', '09:00 - 10:00', 0, 0, '2023-12-01 10:07:54', NULL),
(370, 180, 64, 18, 'Grade 4', 240.00, 'Tuesday', '09:00 - 10:00', 0, 0, '2023-12-01 14:14:47', NULL),
(371, 181, 64, 18, 'Grade 8', 360.00, 'Tuesday', '10:00 - 11:00', 0, 0, '2023-12-01 14:18:19', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `id` int(11) NOT NULL,
  `code` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `fee` decimal(10,2) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`id`, `code`, `title`, `description`, `fee`, `status`, `is_deleted`, `created_date`, `modified_date`) VALUES
(15, 'SJ00001', 'Violin', 'Empty', '120.00', 0, 0, '2023-11-27 22:38:55', '2023-11-27 15:42:18'),
(16, 'SJ00002', 'Piano', 'Empty', '120.00', 0, 0, '2023-11-27 22:39:18', NULL),
(17, 'SJ00003', 'Guitar', 'Empty', '120.00', 0, 0, '2023-11-28 22:40:42', NULL),
(18, 'SJ00004', 'Ukulele', 'Empty', '120.00', 0, 0, '2023-12-01 14:10:08', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `id` int(11) NOT NULL,
  `serial` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `commission_rate` float(10,2) NOT NULL,
  `bank` varchar(255) NOT NULL,
  `account` varchar(255) NOT NULL,
  `cert` varchar(255) DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `modified_date` datetime DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`id`, `serial`, `name`, `email`, `gender`, `password`, `mobile`, `commission_rate`, `bank`, `account`, `cert`, `is_deleted`, `status`, `created_date`, `modified_date`, `image`) VALUES
(55, 'TC00001', 'TC-Amelia', 'Amelia@gmail.com', 'Female', '111', '0122365495', 0.75, 'CIMB Bank Berhad', '550211436652', 'Violin_cert3.pdf', 0, 0, '2023-11-30 15:23:01', NULL, 'images_(4)12.jpeg'),
(56, 'TC00002', 'TC-James', 'James@gmail.com', 'Male', '111', '0122365495', 0.50, 'CIMB Bank Berhad', '550211436652', 'Guitar_Certificates1.pdf', 0, 0, '2023-11-30 15:23:44', NULL, 'qq_(1)2.jpg'),
(57, 'TC00003', 'TC-Jennifer', 'Jennifer@gmail.com', 'Female', '111', '0122365495', 0.75, 'OCBC Bank Malaysia', '550211436652', 'Piano_Cert4.pdf', 0, 0, '2023-11-30 15:24:21', NULL, 'WhatsApp-Image-2023-11-11-at-20_13_08_042a7b69_(5)_(1)22.jpeg'),
(58, 'TC00004', 'TC-Thomas', 'Thomas@gmail.com', 'Male', '111', '0122365495', 0.50, 'RHB Bank Berhad', '550211436652', 'PianoViolin_Certificates.pdf', 0, 0, '2023-11-30 15:27:23', NULL, 'images3.jpg'),
(59, 'TC00005', 'TC-Michelle', 'Michelle@gmail.com', 'Female', '111', '0122649888', 0.75, 'Public Bank Berhad', '550211436652', 'Guitar-TC-Michelle.pdf', 0, 0, '2023-11-30 15:29:01', NULL, '11_(2)41.jpg'),
(63, 'TC00006', 'jyukyu', '123456', 'Male', '111', '0123456789', 0.50, 'Public Bank Berhad', '550211436652', 'tc-emma-Violin1.pdf', 1, 0, '2023-11-30 23:24:04', NULL, NULL),
(64, 'TC00006', 'TC-Emma', 'muijing0112@gmail.com', 'Male', 'Miao_0112', '0123456789', 0.75, 'CIMB Bank Berhad', '550211436652', 'tc-emma-Violin2.pdf', 0, 0, '2023-12-01 14:12:09', '2023-12-01 07:23:39', '11_(2)6.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_salary`
--

CREATE TABLE `teacher_salary` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `commission_rate` float(10,2) NOT NULL,
  `total_amount` float(10,2) NOT NULL,
  `subject_student` text NOT NULL,
  `month` varchar(50) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 0,
  `receipt` varchar(255) DEFAULT NULL,
  `receipt_date` datetime DEFAULT NULL,
  `is_deleted` int(1) NOT NULL DEFAULT 0,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher_salary`
--

INSERT INTO `teacher_salary` (`id`, `teacher_id`, `commission_rate`, `total_amount`, `subject_student`, `month`, `status`, `receipt`, `receipt_date`, `is_deleted`, `created_date`, `modified_date`) VALUES
(143, 57, 0.75, 1.35, '[{\"subject_id\":\"16\",\"grade_level\":\"Grade 2\",\"student_id\":\"177\",\"fee\":\"180.00\"}]', 'December', 1, 'bankTF23.jpg', '2023-12-01 03:08:16', 0, '2023-12-01 10:06:47', '2023-12-01 03:08:16'),
(144, 59, 0.75, 2.02, '[{\"subject_id\":\"17\",\"grade_level\":\"Grade 5\",\"student_id\":\"178\",\"fee\":\"270.00\"}]', 'December', 0, NULL, NULL, 0, '2023-12-01 10:07:16', NULL),
(145, 55, 0.75, 2.70, '[{\"subject_id\":\"15\",\"grade_level\":\"Grade 8\",\"student_id\":\"179\",\"fee\":\"360.00\"}]', 'December', 0, NULL, NULL, 0, '2023-12-01 10:07:58', NULL),
(146, 57, 0.75, 1.35, '[{\"subject_id\":\"16\",\"grade_level\":\"Grade 2\",\"student_id\":\"177\",\"fee\":\"180.00\"}]', 'January', 0, NULL, NULL, 0, '2023-12-01 10:08:16', NULL),
(147, 64, 0.75, 1.80, '[{\"subject_id\":\"18\",\"grade_level\":\"Grade 4\",\"student_id\":\"180\",\"fee\":\"240.00\"}]', 'December', 1, 'bankTF212.jpg', '2023-12-01 07:17:02', 0, '2023-12-01 14:14:52', '2023-12-01 07:17:02'),
(148, 64, 0.75, 4.50, '[{\"subject_id\":\"18\",\"grade_level\":\"Grade 4\",\"student_id\":\"180\",\"fee\":\"240.00\"},{\"subject_id\":\"18\",\"grade_level\":\"Grade 8\",\"student_id\":\"181\",\"fee\":\"360.00\"}]', 'January', 0, NULL, NULL, 0, '2023-12-01 14:17:02', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `teacher_subject`
--

CREATE TABLE `teacher_subject` (
  `id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `teacher_id` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `is_deleted` int(1) NOT NULL DEFAULT 0,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher_subject`
--

INSERT INTO `teacher_subject` (`id`, `subject_id`, `teacher_id`, `status`, `is_deleted`, `created_date`, `modified_date`) VALUES
(116, 15, 55, 0, 0, '2023-11-30 15:23:01', NULL),
(117, 17, 56, 0, 0, '2023-11-30 15:23:44', NULL),
(118, 16, 57, 0, 0, '2023-11-30 15:24:21', NULL),
(119, 16, 58, 0, 0, '2023-11-30 15:27:23', NULL),
(120, 15, 58, 0, 0, '2023-11-30 15:27:23', NULL),
(121, 17, 59, 0, 0, '2023-11-30 15:29:01', NULL),
(123, 15, 61, 0, 0, '2023-11-30 15:36:38', NULL),
(125, 17, 63, 0, 0, '2023-11-30 23:24:04', NULL),
(126, 18, 64, 0, 0, '2023-12-01 14:12:09', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `annoucement`
--
ALTER TABLE `annoucement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_subject`
--
ALTER TABLE `student_subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teacher_salary`
--
ALTER TABLE `teacher_salary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teacher_subject`
--
ALTER TABLE `teacher_subject`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `annoucement`
--
ALTER TABLE `annoucement`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=214;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=182;

--
-- AUTO_INCREMENT for table `student_subject`
--
ALTER TABLE `student_subject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=372;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `teacher_salary`
--
ALTER TABLE `teacher_salary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=149;

--
-- AUTO_INCREMENT for table `teacher_subject`
--
ALTER TABLE `teacher_subject`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
