
<?php

class Subject extends MY_Controller {

    // Predefine function in controller
	public function __construct()
	{
        parent::__construct();
        // $this->data['invalid'] = 0;
        $this->data['folder_name'] = 'teacher';
        $this->load->model("Subject_model");
        // $this->load->model("Teacher_model"); // Load Subject_model
        $this->auth_validate();
	}

    public function index(){
        $this->data['subjects'] = $this->Subject_model->get_where(array('is_deleted'=>0));
        // $this->data['teachers'] = $this->Teacher_model->get_where(array('is_deleted'=>0));
        $this->load->view("teacher/subject/list",$this->data);
    }

    public function store(){
        if ($this->input->post()) {
            
            // add student serial id
            $code = $this->Subject_model->getIDKeyArray('code');
            if($code){
                $largestNumber = 0;
                foreach ($code as $cd) {
                    $matches = [];
                    if (preg_match('/(\d+)/', $cd, $matches)) {
                        $number = intval($matches[0]);
                        if ($number > $largestNumber) {
                            $largestNumber = $number;
                        }
                    }
                }
                $code = 'SJ' . str_pad(($largestNumber + 1), 5, '0', STR_PAD_LEFT);
            }

        //      // Get the selected subject_id from the form data
        // $teacher_id = $this->input->post('teacher_id');
            // store data
            $sql = array(
                'code' => $code,
                // 'teacher_id' => $teacher_id,
                'title' => $this->input->post('title'),
                'tuition_fees' => $this->input->post('tuition_fees'),
                'class_level' => $this->input->post('class_level'),
                'duration_time' => $this->input->post('duration_time'),
            );

            $this->Subject_model->insert($sql);
            redirect(base_url('teacher/subject/list')); // calling route
        }
    }
    public function edit($id){
        $this->load->model("Teacher_model");
        $this->data['subject'] = $this->Subject_model->getOne(array('id'=>$id,'is_deleted'=>0));
        // $this->data['teacher'] = $this->Teacher_model->getOne(array('id'=>$id,'is_deleted'=>0));
        $this->load->view("teacher/subject/edit",$this->data);
    }
    public function update($id){
        if ($this->input->post()) {
            $sql = array(
                'title' => $this->input->post('title'),
                'tuition_fees' => $this->input->post('tuition_fees'),
                'class_level' => $this->input->post('class_level'),
                'duration_time' => $this->input->post('duration_time'),
                'modified_date' => date('Y-m-d H:i:s'),
            );

            $this->Subject_model->update(array('id'=>$id), $sql);

            redirect(base_url('teacher/subject/list')); // calling route
            
        }
    }
    public function delete($id){
        // $this->User_model->delete(array('id'=>$id)); //delete database data
        $this->Subject_model->update(array('id'=>$id), array('is_deleted'=>1));
        redirect(base_url('teacher/subject/list')); // calling route
    }
}
