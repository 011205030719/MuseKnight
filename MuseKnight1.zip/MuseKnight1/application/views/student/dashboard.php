<?php $this->load->view("student/nav"); ?>
<?php $this->load->view("layouts/header"); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
      .custom-module{
        margin-top: -10px; 
        margin-bottom: 20px; 
        background-color: #703be7; 
        height: 40px; 
        width: 350px; 
        display: flex; 
        justify-content: center; 
        align-items: center; 
        position: relative; 
        border-radius: 25px; 
        color: #fff; 
        text-align: left;
        font-size: 18px;
    }

    .custom-module:hover{
        background-color: #422387; 
    }

    .custom-hover:hover{
        background: linear-gradient(135deg, rgb(206, 159, 252) 10%, rgb(115, 103, 240) 100%);
        color: #fff;
        transform: translateY(-15px); /* Move the column up by 5 pixels on hover */
      transition: transform 0.3s ease;
    }
    .element {
    border: 0px solid rgba(100, 100, 100, 1);
    border-radius: 12px;
    color: rgba(255, 255, 255, 0.5);
  }
    .status {
        color: white;
        font-size: 12px;
        font-weight: 600;
        padding-top: 3px;
        padding-bottom: 5px;
        padding-left: 10px;
        padding-right: 10px;
        border-radius: 10px;
    }
    
</style>

          <div class="dashboard" style="padding-left:20%;">
            <div class="container-fluid">
              <div class="card-header">
                <div  style="position: sticky; top: 0; z-index: 1000; background-color:#E6E6FA; border: 0px solid rgba(100, 100, 100, 1); border-radius: 12px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); padding: 10px; margin: 1%;">
                  <span style="color:gray;">Home / </span>
                  <a href="<?= base_url($folder_name.'/annoucement') ?>" style="text-decoration:none; color:black;">Dashboard</a>
                </div>
                <div class="card">
                  <div class="card-body element" style="background-color: rgba(6, 47, 209, 0.05);">
                    <div class="row">
                      <div class="col-md-8">
                        <h1 style="color: black; font-family:Lucida Handwriting, cursive; margin-top:6%; ">Hi  <?= $userdata['name'] ?></h1>
                        <h1 style="color: black; font-family:URW Chancery L, cursive; margin-top:3%; ">Welcome Our MuseKnight </h1>
                        <p style="color: black; font-size:medium; font-style:italic; margin-top: 5%;" >Welcome to our web-based hub designed to enhance your learning experience. Tailored for both new and returning students, this system streamlines academic tasks, making your journey smoother.</p>
                      </div>
                      <div class="col-md-4">
                        <img src="<?= base_url('assets/img/first.png') ?>" class="img-fluid" alt="Image">
                      </div>
                    </div>
                  </div>
                </div>

                <!-- <div class="row">
                  <div class="col-4" style="padding: 20px; margin:auto;">
                    <div class="card shadow custom-hover" style="padding: 20px;">
                      <div class="card-item">
                        <div>
                          <div>0</div>
                          <div>Expenses</div>
                        </div>
                        <div><i class="bi bi-person-badge-fill" style="font-size: 30px;"></i></div>
                      </div>
                    </div>
                  </div>
                  <div class="col-4" style="padding: 20px;margin:auto;">
                    <div class="card shadow custom-hover" style="padding: 20px;">
                      <div class="card-item">
                        <div>
                          <div>0</div>
                          <div>Total Teacher</div>
                        </div>
                        <div><i class="bi bi-person" style="font-size: 30px;"></i></div>
                      </div>
                    </div>
                  </div>
                  <div class="col-4" style="padding: 20px;margin:auto;">
                    <div class="card shadow custom-hover" style="padding: 20px;">
                      <div class="card-item">
                        <div>
                          <div>0</div>
                          <div>Sales</div>
                        </div>
                        <div><i class="bi bi-cash-coin" style="font-size: 30px;"></i></div>
                      </div>
                    </div>
                  </div>
                </div> -->

                <!-- <div class="container">
                  <div style="width: 80%; margin: auto;">
                    <canvas id="myBarChart"></canvas>
                  </div>
                </div> -->
                  <!----------------------------------------------------------posted announcement---------------------------------------------------------->
                  <div class="row">
                    <div class="col-8" style="padding: 10px;">
                      <div class="card shadow">
                        <div class="card-list" style="padding: 20px;">
                          <div class="card-header">
                            <div class="d-flex justify-content-between">
                              <div style="font-weight: 700; font-size: 20px">Announcement</div>
                                <a href="<?= base_url('student/announcement/subjectList')?>" class="btn btn-primary text-light btn-sm">More Details</a>
                            </div>
                          </div>
                          <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade show active" id="annoucment" role="tabpanel" aria-labelledby="annoucment-tab">
                              <?php if($latest_announcements) {
                                foreach ($latest_announcements as $subjectId => $announcements) {
                                  foreach ($announcements as $announcement) { ?>
                                    <div class="card announcement-card" style="border-radius: 5px; position: relative; margin-top:1%;">
                                      <div class="card-body">
                                        <div style="display:flex; justify-content:start; align-items:center;">
                                          <div style="width: 50px; height: 50px; border-radius: 50%; background-color: #3498db; text-align: center; line-height: 50px; color: #fff; font-size:10px;"><?= $announcement['sender_type'] ?></div>
                                          <div style="margin-left:10px;">
                                            <div style="font-size:15px; font-weight:600;"><?= $announcement['senderName'] ?></div>
                                            <div style="font-size:12px;"><?= date('M d, Y (h:i a)', strtotime($announcement['created_date'])) ?></div>
                                          </div>
                                        </div>
                                        <br>
                                        <h5 class="card-title"><?= $announcement['title'] ?></h5>
                                        <p class="card-text"><?= $announcement['description'] ?></p>

                                        <!-- Display Subject Title in the upper right -->
                                        <div style="position: absolute; top: 0; right: 0; padding: 20px;">
                                          <?php if (isset($announcement['subject_title'])) { ?>
                                            <span style="background-color: #7B68EE; color: #fff; font-weight:bold ; padding: 3px 5px; border-radius: 10px; font-size:12px;">
                                              <?= $announcement['subject_title'] ?>
                                            </span>
                                          <?php } ?>
                                        </div>
                                      </div>
                                    </div>
                                  <?php }
                                }
                              } else { ?>
                              <div style="width:100%; text-align:center; padding:20px;">There is no announcement posted on this subject.</div>
                              <?php } ?>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-4" style="padding: 10px;">
                      <div class="card shadow">
                        <div class="card-list" style="padding: 20px;">
                          <div class="card-header">
                            <div class="d-flex justify-content-between">
                              <div style="font-weight: 700; font-size: 20px">Payment List</div>
                                <a href="<?= base_url('student/payment/list')?>" class="btn btn-primary text-light btn-sm">More Details</a>
                            </div>
                          </div>
                          <!-- Display Sales Information -->
                          <?php foreach ($sales as $key => $sale) { ?>
                            <div class="mt-3" style="background-color:;">
                                <p>Month: <?= $sale['month'] ?></p>
                                <p>Subject:
                                  <?php
                                    $subjectDetails = json_decode($sale['subject_detail'], true);

                                    if ($subjectDetails) {
                                      foreach ($subjectDetails as $subject) {
                                        // Fetch subject title from the 'subject' table using the subject ID
                                        $subject_info = $this->Subject_model->getOne(array('id' => $subject['subject_id'], 'is_deleted' => 0));
                                        $subject_title = $subject_info ? $subject_info['title'] : 'Unknown Subject';

                                        echo $subject_title . ', ';
                                      }
                                    } else {
                                        echo 'Unknown Subject';
                                      }
                                  ?>
                                </p>
                                <p>Total Amount: RM  <?= $sale['total_amount'] ?></p>
                                <p> Status:
                                  <span style="background-color: <?= $sale['status'] == 0 ? 'red' : '#CCCC00' ?>; padding: <?= $sale['status'] == 0 ? '5px' : '5px' ?>; border-radius: <?= $sale['status'] == 2 ? '5px;' : '5px' ?>; color:#fff;">
                                    <?= $sale['status'] == 0 ? 'Unpaid' : 'Padding' ?>
                                  </span>
                                </p>
                            </div>
                          <?php } ?>
                        </div>
                      </div>
                    </div>
                  </div>
              </div>
            </div>
          </div>
         

  <!-- Modal HTML -->
<div class="modal" id="myModal" tabindex="-1" hidden>
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Welcome Modal</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Welcome to the dashboard!</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>



    <script src="script.js"></script>

    <script>
    const labels = ["January", "February", "March", "April", "May", "June", "July"];
    const data = {
      labels: labels,
      datasets: [{
        label: 'My First Dataset',
        data: [65, 59, 80, 81, 56, 55, 40],
        backgroundColor: [
          'rgba(255, 99, 132, 0.2)',
          'rgba(255, 159, 64, 0.2)',
          'rgba(255, 205, 86, 0.2)',
          'rgba(75, 192, 192, 0.2)',
          'rgba(54, 162, 235, 0.2)',
          'rgba(153, 102, 255, 0.2)',
          'rgba(201, 203, 207, 0.2)'
        ],
        borderColor: [
          'rgb(255, 99, 132)',
          'rgb(255, 159, 64)',
          'rgb(255, 205, 86)',
          'rgb(75, 192, 192)',
          'rgb(54, 162, 235)',
          'rgb(153, 102, 255)',
          'rgb(201, 203, 207)'
        ],
        borderWidth: 1
      }]
    };

    const config = {
      type: 'bar',
      data: data,
      options: {
        scales: {
          y: {
            beginAtZero: true
          }
        }
      },
    };

    // Get the canvas element and initialize the chart
    const ctx = document.getElementById('myBarChart').getContext('2d');
    const myBarChart = new Chart(ctx, config);
  </script>