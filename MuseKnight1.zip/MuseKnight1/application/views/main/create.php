<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
</head>

<body>
    <div class="container" style="margin-top: 75px;">
        <div class="card shadow mb-3" style="margin-top: 25px;">
            <div class="card-header text-center">Create User</div>
            <div class="card-body">
                <form method="POST" id="create_form" action="<?=base_url('CRUD/store')?>">
                    <div class="form-group mb-2">
                        <label for="exampleInputEmail1" style="font-weight: 500;" class="mb-2">User Name</label>
                        <input type="text" id="User" class="form-control" name="name" placeholder="Enter User name">
                    </div>
                    <div class="form-group mb-2">
                        <label for="exampleInputEmail1" style="font-weight: 500;" class="mb-2">Email</label>
                        <input type="text" id="email" class="form-control" name="email" placeholder="Enter email address">
                    </div>
                    <div class="form-group mb-2">
                        <label for="exampleInputEmail1" style="font-weight: 500;" class="mb-2">Passwprd</label>
                        <input type="password" id="password" class="form-control" name="password" placeholder="Enter your password">
                    </div>
                </form>
            </div>
        </div>
        <div class="text-end mt-2">
            <a href="<?=base_url('CRUD/index')?>" class="btn btn-secondary text-white">Back</a>
            <button type="submit" id="create_form" form="create_form" class="px-5 btn btn-primary text-white">Submit</button>
        </div>
    </div>
</body>
</html>