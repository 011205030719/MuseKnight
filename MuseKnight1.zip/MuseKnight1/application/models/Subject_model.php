<?php
class Subject_model extends MY_Model {
    protected $table = 'subjects';
    public function __construct(){
        $this->set_table('subject');
    }
    public function get_where_in($field, $values) {
        $this->db->where_in($field, $values);
        $query = $this->db->get('subject');

        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return array();
        }
    }
    public function get_all() {
        // Query your database to get all subjects and return the result
        $query = $this->db->get('subject'); // Assuming 'subjects' is your subjects table name
        return $query->result_array(); // Assuming you want the result as an array
    }

    public function getSubjectDetails($subject_id) {
        $where = array('id' => $subject_id, 'is_deleted' => 0);
        $result = $this->get_where($where);

        if (!empty($result)) {
            return $result[0];
        } else {
            return array(); // Return an empty array if the subject is not found
        }
    }
       public function get_subjects_by_ids($subject_ids) {
        $this->db->where_in('id', $subject_ids);
        $query = $this->db->get('subject');

        if ($query->num_rows() > 0) {
            return $query->result_array();
        } else {
            return array();
        }
    }

    public function getSubjectName($subject_id) {
        $this->db->select('title');
        $this->db->where('id', $subject_id);
        $query = $this->db->get('subject');
    
        if ($query->num_rows() > 0) {
            $row = $query->row();
            return $row->title; 
        } else {
            return 'Unknown';
        }
    }
    public function getSubjectTitleById($subject_id) {
        $this->db->select('title');
        $this->db->where('id', $subject_id);
        $query = $this->db->get('subject');

        if ($query->num_rows() > 0) {
            $row = $query->row();
            return $row->title;
        } else {
            return null; // Subject not found
        }
    }
}
?>