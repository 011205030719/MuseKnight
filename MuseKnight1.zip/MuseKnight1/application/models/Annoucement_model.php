<?php
class Annoucement_model extends MY_Model
{
    public function __construct()
    {
        $this->set_table('annoucement');
        
        $this->load->library('email');
    }
    public function get_announcements_by_subject_ids($subject_ids)
    {
        $this->db->select('*');
        $this->db->from('annoucement');
        $this->db->where_in('subject_id', $subject_ids);
        $this->db->where('is_deleted', 0);
        return $this->db->get()->result_array();
    }

    public function get_matching_announcements($subject_id, $teacher_id)
{
    $this->db->select('*');
    $this->db->from('annoucement');
    $this->db->where('subject_id', $subject_id);
    $this->db->where('sender_id', $teacher_id); // Assuming sender_id should match teacher_id
    $this->db->where('is_deleted', 0);

    return $this->db->get()->result_array();
}
/////Admin announcemet latest 3 \\\\\\\\
public function get_latest_announcements_for_admin($limit = 3) {
    $this->db->select('annoucement.*, subject.title as subject_title'); // Select columns from both tables
    $this->db->from('annoucement');
    $this->db->join('subject', 'subject.id = annoucement.subject_id', 'left'); // Join with subject table
    $this->db->where('annoucement.is_deleted', 0);
    $this->db->order_by('annoucement.created_date', 'desc');
    $this->db->limit($limit);
    $query = $this->db->get();
    return $query->result_array();
}



// Add the following method to your Annoucement_model
public function get_latest_announcements_for_subject($subject_id, $limit = 3) {
    $this->db->select('*');
    $this->db->from($this->table_name);
    $this->db->where('subject_id', $subject_id);
    $this->db->where('is_deleted', 0);
    $this->db->order_by('created_date', 'desc');
    $this->db->limit($limit);
    $query = $this->db->get();
    return $query->result_array();
}

}