<?php

class Announcement extends MY_Controller {

    // Predefine function in controller
	public function __construct()
	{
        parent::__construct();
        // $this->data['invalid'] = 0;
        $this->data['folder_name'] = 'student';
        $this->load->model("Student_model");
        $this->load->model("StudentSubject_model");
        $this->load->model("Subject_model");
        $this->load->model("Teacher_model");
        $this->load->model("TeacherSubject_model");
        $this->load->model("Annoucement_model");
        $this->auth_validate();
	}

    public function subjectList()
    {
        $student_id = $this->session->userdata('user_id');
        $student_subjects = $this->StudentSubject_model->get_where(array('student_id' => $student_id, 'status'=>0, 'is_deleted' => 0));
        $teachers = $this->Teacher_model->getIDKeyArray('name',array('is_deleted' => 0));
        
        $subjects = [];
        $all_subjects = $this->Subject_model->getIDKeyArray();
        foreach($student_subjects as $student_subject){
            $time_range = $this->formatTimeRange($student_subject['time_range']);

            $add_subject = array(
                'subject_id'=> $student_subject['subject_id'],
                'title'=> $all_subjects[$student_subject['subject_id']],
                'teacherName'=> $teachers[$student_subject['teacher_id']],
                'grade_level'=> $student_subject['grade_level'],
                'time_range'=> $time_range,
                'day'=> $student_subject['day'],
            );
            $subjects[] = $add_subject;
        }

        $this->data['subjects'] = $subjects;
        $this->load->view("student/announcement/subject_list", $this->data);
    }
    private function formatTimeRange($time_range)
    {
        // Check if the delimiter '-' exists in the time range string
        if (strpos($time_range, '-') !== false) {
            list($start, $end) = explode('-', $time_range);
    
            $start_time = date('g:i A', strtotime($start));
            $end_time = date('g:i A', strtotime($end));
    
            return $start_time . ' - ' . $end_time;
        } else {
            // Handle the case when the delimiter is not found
            return $time_range;
        }
    }
    
    public function index($id)
    {
        $student_id = $this->session->userdata('user_id');

        // Subject
        $this->data['subject'] = $this->Subject_model->getOne(array('id' => $id, 'is_deleted' => 0));
        $current_student_subject = $this->StudentSubject_model->getOne(array('student_id'=>$student_id, 'subject_id' => $id, 'status'=>0, 'is_deleted' => 0));
        $student_ids = $this->StudentSubject_model->getIDKeyArray('student_id',array('subject_id' => $id, 'status'=>0, 'is_deleted' => 0));
        $this->data['students'] = $this->Student_model->get_wherein(array('is_deleted'=>0) , 'id', $student_ids);

        // Teacher
        $this->data['teachers'] = $this->TeacherSubject_model->get_where(array('subject_id' => $id, 'status'=>0, 'is_deleted' => 0));
        $this->data['teachers_Name'] = $this->Teacher_model->getIDKeyArray('name',array('is_deleted' => 0));

        // Annoucment
        $all_announcements = $this->Annoucement_model->get_where(array('subject_id' => $id, 'is_deleted' => 0));

        foreach ($all_announcements as $announcementKey => $announcement) {
            $sender_id = $announcement['sender_id'];
            $sender_type = $announcement['sender_type'];
            
            // Fetch the name based on sender_type and sender_id
            if ($sender_type == 'admin') {
                // For admin sender, you can directly use 'Admin' as the sender name
                $all_announcements[$announcementKey]['senderName'] = 'Admin';
            } elseif ($sender_type == 'teacher') {
                $sender_info = $this->Teacher_model->getOne(array('id' => $sender_id, 'is_deleted' => 0));
                if ($sender_info) {
                    // Assign the sender's name to the announcement
                    $all_announcements[$announcementKey]['senderName'] = $sender_info['name'];
                } else {
                    // Handle the case when the sender's info is not found
                    $all_announcements[$announcementKey]['senderName'] = 'Unknown name';
                }
            } else {
                // Handle additional sender types if needed
                // $sender_info = $this->AdditionalSenderModel->getOne(array('id' => $sender_id, 'is_deleted' => 0));
                // $all_announcements[$announcementKey]['senderName'] = $sender_info ? $sender_info['name'] : 'Unknown name';
            }
        }
        $this->data['announcements'] = $all_announcements;
        
        $this->load->view("student/announcement/list", $this->data);
    }

    public function subjectFile(){
        $this->load->view("student/announcement/subjectFile",$this->data);
    }

    public function add_annoucement_view()
    {
        $teacher_id = $this->session->userdata('user_id');
        $this->data['subjects'] = $this->Subject_model->get_where(array('is_deleted' => 0));

        $this->data['teacher_id'] = $teacher_id;
        $this->data['sender_type'] = 'teacher';
        $this->data['receiver_type'] = 'student';

        // Load the Annoucement_model to fetch announcements data
        $this->data['announcements'] = $this->Annoucement_model->get_where(array('is_deleted' => 0));

        $this->load->view("student/announcement/add_annoucement", $this->data);
    }


}