<?php $this->load->view("admin/nav"); ?>
<?php $this->load->view("layouts/header"); ?>


<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/dt/jq-2.1.4,jszip-2.5.0,pdfmake-0.1.18,dt-1.10.9,af-2.0.0,b-1.0.3,b-colvis-1.0.3,b-html5-1.0.3,b-print-1.0.3,se-1.0.1/datatables.min.css"/>
<style>
     .custom-module {
        margin-top: -10px;
        margin-bottom: 20px;
        background-color: #703be7;
        height: 40px;
        width: 250px;
        display: flex;
        justify-content: center;
        align-items: center;
        position: relative;
        border-radius: 25px;
        color: #fff;
        text-align: left;
        font-size: 18px;
    }

    .status {
        color: white;
        font-size: 12px;
        font-weight: 600;
        padding-top: 3px;
        padding-bottom: 5px;
        padding-left: 10px;
        padding-right: 10px;
        border-radius: 10px;
    }

    .table-container {
        overflow-x: auto;
    }

    /* Modify the existing table style */
    table {
        background-color: white;
        width: 100%; /* Set the width to 100% */
        table-layout: fixed; /* Set the table layout to fixed */
        overflow: auto;
        display: block;
    }

    /* Adjust the widths of your table columns as needed */
    table th,
    table td {
        padding: 5px;
        text-align: left;
    }
</style>


<div class="container-fluid" style="padding-left: 20%; padding-right: 5%; padding-top: 3%;">
    <div class="header" style=" width:100%;">
        <div style="position: sticky; top: 0; z-index: 1000; background-color:#E6E6FA; border: 0px solid rgba(100, 100, 100, 1); border-radius: 12px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); padding: 10px; margin: 1%;">
            <span>Home / </span>
            <a href="<?= base_url($folder_name.'/student/list') ?>" style="text-decoration:none; color:black;">Student List</a>
        </div>
    <div>

    <div style="text-align: end; margin-bottom:20px;">
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#createModal">Add New Student</button>
        <!-- Modal -->
        <div class="modal fade" id="createModal" tabindex="-1" role="dialog" aria-labelledby="createModalTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" style="max-width: 60%;" role="document">
                <div class="modal-content">
                    <form method="POST" id="create_form" action="<?=base_url('admin/student/store')?>">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle">Create New Student</h5>
                            <a style="padding-left: 15px; padding-right: 15px;" type="button" data-dismiss="modal" aria-label="Close">x</a>
                        </div>
                        <div class="modal-body">
                            <div class="row" style="text-align: start;" >
                                <div class="col-6 form-group mb-2">
                                    <label for="name" style="font-weight: 500;" class="mb-2">Name</label>
                                    <input required type="text" id="name" class="form-control" name="name" placeholder="Enter User name">
                                </div>
                                <div class="col-6 form-group mb-2">
                                    <label for="email" style="font-weight: 500;" class="mb-2">Email</label>
                                    <input required type="email" id="email" class="form-control" name="email" placeholder="Enter email address">
                                </div>
                                <div class="col-6 form-group mb-2">
                                    <label for="gender" style="font-weight: 500;" class="mb-2">Gender</label>
                                    <select name="gender" id="gender" class="form form-select">
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                    </select>

                                </div>
                                <div class="col-6 form-group mb-2">
                                    <label for="mobile" style="font-weight: 500;" class="mb-2">Mobile</label>
                                    <input required type="tel" id="mobile" class="form-control" name="mobile" placeholder="Enter mobile number" minlength="10" maxlength="11">
                                </div>

                                <div class="col-6 form-group mb-2">
                                    <label for="password" style="font-weight: 500;" class="mb-2">Password</label>
                                        <input required type="password" id="password" class="form-control" name="password" placeholder="Enter your password">
                                </div>
                                <div class="col-6 form-group mb-2">
                                    <label for="status" style="font-weight: 500;" class="mb-2">Status</label>
                                    <select name="status" id="status" class="form form-select">
                                        <option value="0">Active</option>
                                        <option value="1">Inactive</option>
                                    </select>
                                </div>
                                    
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Add Student</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="card shadow">
        <div style="padding: 30px;">
            <div style="overflow-x: auto;" class="table-container">
                <table id="lecturerTable"style="background-color: white; max-height: 400px; overflow-x: auto; display: block;" class="table table-bordered">
                    <thead>
                        
                        <tr style="border-bottom: 2px solid lightgray;">
                            <th style="padding:5px 40px; width: 5%;">#</th>
                            <th style="padding:5px 40px; width: 10%;">Serial</th>
                            <th style="padding:5px 40px; width: 15%;">Name</th>
                            <th style="padding:5px 40px; width: 10%;">Gender</th>
                            <th style="padding:5px 40px; width: 10%;">Email</th>
                            <th style="padding:5px 40px; width: 10%;">Mobile</th>
                            <th style="padding:5px 100px; width: 50%;">Subject</th>
                            <th style="padding:5px 40px; width: 10%;">Status</th>
                            <th style="padding:5px 40px; width: 20%;">Created Date</th>
                            <th style="padding:5px 100px; width: 50%;">Action</th>
                        </tr>
                    </thead>
                    <tbody >
                    <?php foreach($students as $key => $student){?>
                        <tr class="table_row">
                            <th scope="row"><?= $key + 1 ?></th>
                            <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $student['serial'] ?></td>
                            <td style="width:20%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $student['name'] ?></td>
                            <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $student['gender'] ?></td>
                            <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $student['email'] ?></td>
                            <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $student['mobile'] ?></td>
                            <td style="width: 50%; padding-left: 10px; padding-top: 8px; padding-bottom: 8px;">
                                <?php
                                $student_id = $student['id'];
                                $subject_titles = []; // Initialize an array to store subject titles

                                // Find the subject titles based on student_id in the student_subject array
                                foreach ($student_subjects as $student_subject) {
                                    if ($student_id == $student_subject['student_id'] && $student_subject['status'] != 1) {
                                        $subject_id = $student_subject['subject_id'];

                                        // Find the subject title based on subject_id from the subjects array
                                        foreach ($subjects as $subject) {
                                            if ($subject['id'] == $subject_id) {
                                                $subject_titles[] = $subject['title']; // Store subject title
                                            }
                                        }
                                    }
                                }

                                // Display the subject titles for the current student
                                echo implode(', ', $subject_titles);
                                ?>
                            </td>

                            </td>

                            <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                <?php if($student['status'] == 0){?>
                                    <span class="status" style="background-color:limegreen;">Active</span>
                                <?php }else{ ?>
                                    <span class="status" style="background-color:orange;">Inactive</span>
                                <?php } ?>
                            </td>
                            <td style="width:20%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= date('Y-m-d', strtotime($student['created_date'])) ?></td>
                            <td style="width:40%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                <a href="<?=base_url('admin/student/edit/'. $student['id'])?>" class="btn btn-success"><i class ="bi bi-pencil-square"></i></a>
                                <!-- <a href="<?=base_url('admin/profile/list/'. $student['id'])?>" class="btn btn-primary"><i class="bi bi-card-list"></i></a> -->
                                <a href="<?=base_url('admin/student/delete/'. $student['id'])?>" onclick="return confirmSubmit();" class="btn btn-danger"><i class="bi bi-trash3"></i></a>
                            </td>
                        </tr>
                    <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>







<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- DataTables and Bootstrap DataTables -->
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<!-- DataTables library -->
<script type="text/javascript" src="https://cdn.datatables.net/r/dt/jq-2.1.4,jszip-2.5.0,pdfmake-0.1.18,dt-1.10.9,af-2.0.0,b-1.0.3,b-colvis-1.0.3,b-html5-1.0.3,b-print-1.0.3,se-1.0.1/datatables.min.js"></script>

<!-- Your existing modal HTML -->

<script>
    $(document).ready(function() {
        // Attach click event to delete buttons
        $('.delete-btn').click(function () {
            // Get the teacher or student ID from the data-id attribute
            var itemId = $(this).data('id');
            var itemType = $(this).data('type'); // 'teacher' or 'student'

            // Set the form action based on the item type and ID
            var deleteUrl = 'admin/' + itemType + '/delete/' + itemId;
            $('#deleteForm').attr('action', deleteUrl);

            // Show the confirmation modal
            $('#deleteModal').modal('show');
        });

        $('#lecturerTable').DataTable({
            // Your DataTable configuration...
        });
    });

    function confirmSubmit() {
        // You can add additional logic here if needed
        return confirm('Are you sure you want to delete this student?');
    }
</script>
