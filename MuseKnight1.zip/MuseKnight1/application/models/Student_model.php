<?php
class Student_model extends MY_Model {
    public function __construct(){
        $this->set_table('student');
    }
    public function get_students_by_ids($student_id) {
        if (!empty($student_id)) {
            $this->db->where_in('id', $student_id);
            return $this->db->get('student')->result_array();
        } else {
            // Handle the case where $student_id is empty
            return array();
        }
    }
    

    public function getStudentEmailById($student_id) {
        $this->db->select('email');
        $this->db->where('id', $student_id);
        $query = $this->db->get('student');

        if ($query->num_rows() > 0) {
            $row = $query->row();
            return $row->email;
        } else {
            return null; // Student not found
        }
    }

    
    
}
?>