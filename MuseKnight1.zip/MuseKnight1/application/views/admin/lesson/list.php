<?php $this->load->view("admin/nav"); ?>
<?php $this->load->view("layouts/header"); ?>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/dt/jq-2.1.4,jszip-2.5.0,pdfmake-0.1.18,dt-1.10.9,af-2.0.0,b-1.0.3,b-colvis-1.0.3,b-html5-1.0.3,b-print-1.0.3,se-1.0.1/datatables.min.css"/>

<style>
    .custom-module{
        margin-top: -10px; 
        margin-bottom: 20px; 
        background-color: #703be7; 
        height: 40px; 
        width: 300px; 
        display: flex; 
        justify-content: center; 
        align-items: center; 
        position: relative; 
        border-radius: 25px; 
        color: #fff; 
        text-align: left;
        font-size: 18px;
    }
    .gender_status{
        color: white;
        font-size:12px;
        font-weight:600;
        padding-top:3px;
        padding-bottom:5px;
        padding-left:10px;
        padding-right:10px;
        border-radius:10px;
    }
    
    /* .custom-module:hover{
        background-color: #422387; 
    } */
</style>

<div class="container-fluid" style="padding-left: 20%; padding-right: 5%; padding-top: 1%;">
    <div class="header" style=" width:100%;">
        <div style="position: sticky; top: 0; z-index: 1000; background-color:#E6E6FA; border: 0px solid rgba(100, 100, 100, 1); border-radius: 12px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); padding: 10px; margin: 1%;">
            <span>Home / </span>
            <a href="<?= base_url($folder_name.'/lesson/list') ?>" style="text-decoration:none; color:black;">Lesson List</a>
        </div>
    <div>
    <div style="text-align: end; margin-bottom:20px;">
        <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#createLessonModal">Add New Lesson</button>
    
        
        <div class="modal fade" id="createLessonModal" tabindex="-1" role="dialog" aria-labelledby="createLessonModalTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" style="max-width: 60%;" role="document">
                <div class="modal-content">
                    <form method="POST" id="create_form" action="<?= base_url('admin/lesson/store') ?>">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle">Create New Lesson</h5>
                            <a style="padding-left: 15px; padding-right: 15px;" type="button" data-dismiss="modal" aria-label="Close">x</a>
                        </div>
                        <div class="modal-body">
                            <div class="row" style="text-align: start;" >
                                <div class="col-6 form-group mb-2">
                                    <label for="teacher_id" style="font-weight: 500;" class="mb-2">Teacher</label>
                                        <select name="teacher_id" id="teacher_id" class="form form-select">
                                            <option value="disabled selected">Select Teacher</option>
                                                <?php foreach ($teachers as $teacher) { ?>
                                            <option value="<?= $teacher['id'] ?>"><?= $teacher['name'] ?></option>
                                                <?php } ?>
                                        </select>
                                </div>
                                <div class="col-6 form-group mb-2">
                                    <label for="student_id" class="text-left">Student</label>
                                        <select name="student_id" id="student_id" class="form-select">
                                            <option value=""disabled selected>Select Student</option>
                                                <?php foreach ($students as $student) { ?>
                                                    <option value="<?= $student['id'] ?>"><?= $student['name'] ?></option>
                                                <?php } ?>
                                        </select>
                                </div>
                                <div class="col-6 form-group mb-2">
                                    <label for="subject_id">Subject</label>
                                        <select name="subject_id" id="subject_id" class="form-select">
                                            <option value=""disabled selected>Select Subject</option>
                                                <?php foreach ($subjects as $subject) { ?>
                                                    <option value="<?= $subject['id'] ?>"><?= $subject['title'] ?></option>
                                                <?php } ?>
                                        </select>
                                </div>
                                <div class="col-6 form-group mb-2">
                                    <label for="grade_level" style="font-weight: 500;" class="mb-2">Grade</label>
                                    <input required type="text" id="grade_level" class="form-control" name="grade_level" placeholder="Enter Current Grade">
                                </div>
                                <div class="col-6 form-group mb-2">
                                    <label for="fee" style="font-weight: 500;" class="mb-2">fee</label>
                                        <input required type="text" id="fee" class="form-control" name="fee" placeholder="Enter fee">
                                </div>

                                
                                <div class="col-6 form-group mb-2">
                                    <label for="day">Day</label>
                                        <select class="form-select" id="day" name="day">
                                            <option value="Monday">Monday</option>
                                            <option value="Tuesday">Tuesday</option>
                                            <option value="Wednesday">Wednesday</option>
                                            <option value="Thursday">Thursday</option>
                                            <option value="Friday">Friday</option>
                                            <option value="Saturday">Saturday</option>
                                            <option value="Sunday">Sunday</option>
                                        </select>
                                </div>

                                <div class="col-6 form-group mb-2">
                                    <label for="start_time">Start Time</label>
                                    <input type="time" class="form-control" id="start_time" name="start_time">
                                </div>
                                <div class="col-6 form-group mb-2">
                                    <label for="end_time">End Time</label>
                                    <input type="time" class="form-control" id="end_time" name="end_time">
                                </div>

                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Save changes</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div> -->
    </div>
    <div class="card shadow">
        <div style="padding: 30px;">
            <div style="overflow-x: auto;" class="table-container">
                <table id="lecturerTable"style="background-color: white; max-height: 400px; overflow-x: auto; display: block;" class="table table-bordered">
                <thead>
                    <tr>
                        <th style="padding:5px 40px; width: 5%;">#</th>
                        <th style="padding:5px 60px; width: 30%;">Teacher</th>
                        <th style="padding:5px 60px; width: 30%;">Student</th>
                        <th style="padding:5px 40px; width: 20%;">Subject</th>
                        <th style="padding:5px 40px; width: 20%;">Class Level</th>
                        <!-- <th style="padding:5px 40px; width: 20%;">Subject Fee</th> -->
                        <th style="padding:5px 60px; width: 30%;">Day</th>
                        <th style="padding:5px 80px; width: 40%;">Time Range</th>
                        <th style="padding:5px 100px; width: 50%;">Created Date</th>
                        <!-- <th style="padding:5px 100px; width: 50%;">Action</th> -->
                    
                    
                    </tr>
                </thead>
                <tbody >
                    <?php foreach($student_subjects as $key => $student_subject){?>
                        <tr class="table_row">
                            <th scope="row"><?= $key + 1 ?></th>
                            <td style="width:30%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                <?php 
                                $teacher_name = ''; // Initialize the teacher name
                                foreach ($teachers as $teacher) {
                                    if ($teacher['id'] == $student_subject['teacher_id']) {
                                        $teacher_name = $teacher['name'];
                                        break; // Exit the loop once teacher_name is found
                                    }
                                }
                                echo $teacher_name; // Display teacher's name
                                ?>
                            </td>


                            <td style="width:30%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                <?php 
                                    $lesson_student = '';
                                    foreach($students as $student){
                                        if($student['id'] == $student_subject['student_id']){
                                            $lesson_student = $student['name'];
                                        }
                                    }
                                    echo $lesson_student;  // Display subject title
                                ?>
                            </td>
                   
                            <td style="width:20%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                <?php
                                $subject_name = ''; // Initialize the subject name
                                foreach ($subjects as $subject) {
                                    if ($subject['id'] == $student_subject['subject_id']) {
                                        $subject_name = $subject['title'];
                                        break; // Exit the loop once subject_name is found
                                    }
                                }
                                echo $subject_name; // Display subject name
                                ?>
                            </td>

                            <td style="width:20%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                            <?php 
                                    $grade_level = '';
                                    foreach($students as $student){
                                        if($student['id'] == $student_subject['student_id']){
                                            $grade_level = $student_subject['grade_level'];
                                        }
                                    }
                                    echo $grade_level;  // Display subject title
                                ?>
                            </td>
<!-- 
                            <td style="width:20%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                <?php
                                // Use the current $student_subject for subject-related information
                                $lesson_id = $student_subject['lesson_id'];

                                // Find the grade_level based on lesson_id from the subjects array
                                $fees = '';
                                foreach ($lessons as $lesson) {
                                    if ($lesson['lesson_id'] == $lesson_id) {
                                        $fees = $lesson['fee'];
                                        break; // Exit the loop once grade_level is found
                                    }
                                }
                                echo $fees;
                                ?>
                            </td> -->
                            <td style="width:30%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $student_subject['day'] ?></td>
                            <td style="width:40%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $student_subject['time_range'] ?></td>
                            <td style="width:50%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= date('Y-m-d', strtotime($student_subject['created_date'])) ?></td>
                            <!-- <td style="width:50%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                <a href="<?=base_url('admin/lesson/edit/'. $student_subject['id'])?>" class="btn btn-success"><i class="bi bi-pencil-square"></i></a>
                                <a href="<?=base_url('admin/lesson/delete/'. $student_subject['id'])?>" class="btn btn-danger delete-btn" data-id="<?= $student_subject['id'] ?>"><i class="bi bi-trash3"></i></a>
                            </td> -->
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<!-- Add this modal HTML code at the end of your HTML body or in a separate file -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalTitle">Confirm Deletion</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this lesson?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <form id="deleteForm" method="post">
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- DataTables and Bootstrap DataTables -->
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<!-- DataTables library -->
<script type="text/javascript" src="https://cdn.datatables.net/r/dt/jq-2.1.4,jszip-2.5.0,pdfmake-0.1.18,dt-1.10.9,af-2.0.0,b-1.0.3,b-colvis-1.0.3,b-html5-1.0.3,b-print-1.0.3,se-1.0.1/datatables.min.js"></script>

<script>
      
    $(document).ready(function() {

        // Attach click event to delete buttons
        $('.delete-btn').click(function () {
            // Get the teacher ID from the data-id attribute
            var teacherId = $(this).data('id');

            // Set the teacher ID in the modal form action
            $('#deleteForm').attr('action', 'admin/teacher/delete/' + teacherId);

            // Show the confirmation modal
            $('#deleteModal').modal('show');
        });

        $('#lecturerTable').DataTable({
            dom: 'lBfrtip',
            lengthMenu: [10, 25, 50],
            searching: true,
            buttons: [
                {
                    extend: 'excel',
                    text: 'Download Data',
                    className: 'btn btn-outline-success',
                    init: function(api, node, config) {
                        $(node).removeClass('dt-button');
                        $(node).css({
                            'margin-left': '10%',
                            'margin-bottom': '10%',
                            'height': '30px',
                            'width': '150px',
                            'font-size': '17px',
                            'display': 'flex',
                            'align-items': 'center'
                        });
                    }
                }
            ]
        });
    });
    </script>
