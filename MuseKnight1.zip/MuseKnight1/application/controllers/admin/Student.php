<?php

class Student extends MY_Controller
{

    // Predefine function in controller
    public function __construct()
    {
        parent::__construct();
        // $this->data['invalid'] = 0;
        $this->data['folder_name'] = 'admin';
        $this->load->model("Student_model");
        $this->load->model("Subject_model");
        $this->load->model("StudentSubject_model");
        $this->load->model("TeacherSubject_model");
        $this->load->model("Sales_model");
        $this->load->model("Salary_model");
        $this->load->model("Teacher_model");
        $this->auth_validate();
        // Fetch and set teacher names in $this->data['subject titial']
        $subjects = $this->Subject_model->get_all(); // Replace with your actual method to get teachers
        $this->data['subject'] = [];
        foreach ($subjects as $subject) {
            $this->data['subject']= $subject['title'];
        }
        // Send email to selected students
        $this->load->library('PHPMailer_Lib');
    
    }

    public function index()
    {
        $this->data['students'] = $this->Student_model->get_where(array('is_deleted' => 0));
        $this->data['teachers'] = $this->Teacher_model->get_where(array('is_deleted' => 0));
        $this->data['student_subjects'] = $this->StudentSubject_model->get_where(array('is_deleted' => 0));
        $this->data['subjects'] = $this->Subject_model->get_where(array('is_deleted' => 0));



        $this->load->view("admin/student/list", $this->data);
    }

    public function store()
    {
        if ($this->input->post()) {
            // add student serial id
            $serials = $this->Student_model->getIDKeyArray('serial');
            if ($serials) {
                $largestNumber = 0;
                foreach ($serials as $str) {
                    $matches = [];
                    if (preg_match('/(\d+)/', $str, $matches)) {
                        $number = intval($matches[0]);
                        if ($number > $largestNumber) {
                            $largestNumber = $number;
                        }
                    }
                }
                $serial = 'ST' . str_pad(($largestNumber + 1), 5, '0', STR_PAD_LEFT);
            } else {
                $serial = 'ST00001';
            }

            // store data
            $sql = array(
                'serial' => $serial,
                'name' => $this->input->post('name'),
                'gender' => $this->input->post('gender'),
                'password' => $this->input->post('password'),
                'email' => $this->input->post('email'),
                'mobile' => $this->input->post('mobile'),
                'status' => $this->input->post('status'),
            );

            // Insert student data
            $student_id = $this->Student_model->insert($sql);

            // Create New Sales for new student
            // Check latest sales serial number
            $sales_serials = $this->Sales_model->getIDKeyArray('serial');
            if ($sales_serials) {
                $largestNumber = 0;
                foreach ($sales_serials as $str) {
                    $matches = [];
                    if (preg_match('/(\d+)/', $str, $matches)) {
                        $number = intval($matches[0]);
                        if ($number > $largestNumber) {
                            $largestNumber = $number;
                        }
                    }
                }
                $sale_serial = 'PM' . str_pad(($largestNumber + 1), 5, '0', STR_PAD_LEFT);
            } else {
                $sale_serial = 'PM00001';
            }

            $sale_sql = array(
                'serial' => $sale_serial,
                'student_id' => $student_id,
                'month' => date("F"),
            );

            // Insert student data
            $this->Sales_model->insert($sale_sql);

            redirect(base_url('admin/student/list')); // calling route
        }
    }


    public function addLesson()
    {
        if ($this->input->post()) {
            // Get the necessary form data
            $student_id = $this->input->post('student_id');
            $subject_id = $this->input->post('subject_id');
            $teacher_id = $this->input->post('teacher_id');
            $day = $this->input->post('day');
            $time_range = $this->input->post('time_range');
            $grade_level = $this->input->post('grade_level');
            $fee = $this->input->post('fee');

            // Fetch the teacher's commission rate from the teacher database
            $teacher_data = $this->Teacher_model->getOne(array('id' => $teacher_id));

            if ($teacher_data) {
                $commission_rate = $teacher_data['commission_rate'];
            } else {
                // Handle the case where the teacher is not found
                // You may want to set a default commission rate or show an error message
                $commission_rate = 0; // Set a default commission rate or handle the error as needed
            }
            if ($this->input->post()) {
                // Get the necessary form data
                $student_id = $this->input->post('student_id');
                $subject_id = $this->input->post('subject_id');
                $teacher_id = $this->input->post('teacher_id');
                $day = $this->input->post('day');
                $time_range = $this->input->post('time_range');
                $grade_level = $this->input->post('grade_level');
                $fee = $this->input->post('fee');
        
                // Check if the combination of student_id, subject_id, and grade_level already exists
                $existingLesson = $this->StudentSubject_model->getOne(array(
                    'student_id' => $student_id,
                    'subject_id' => $subject_id,
                    'grade_level' => $grade_level,
                ));
        
                if ($existingLesson) {
                    // Display an error message
                    $this->session->set_flashdata('error', 'This grade level for the selected subject already exists for the student.');
                    redirect(base_url('admin/student/list'));
                }
            }
            // Insert into the student_subject table
            $student_subject_data = array(
                'student_id' => $student_id,
                'subject_id' => $subject_id,
                'teacher_id' => $teacher_id,
                'day' => $day,
                'time_range' => $time_range,
                'grade_level' => $grade_level,
                'fee' => $fee,
                // Add other relevant data for the student_subject table
            );

            $this->StudentSubject_model->insert($student_subject_data);

      //////////////////// Send an email notification to the teacher\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\

 // Get form data
 $subject_id = $this->input->post('subject_id');
 $teacher_id = $this->input->post('teacher_id');
 $day = $this->input->post('day');
 $time_range = $this->input->post('time_range');
 $grade_level = $this->input->post('grade_level');
 $fee = $this->input->post('fee');
 
 // Get subject title based on the selection
$subject_title = $this->Subject_model->getSubjectTitleById($subject_id);

 // Get teacher email based on the selection
 $teacher_email = $this->Teacher_model->getTeacherEmailById($teacher_id);
 
 // Send email to the selected teacher
 if (!empty($teacher_email)) {
     $mail = $this->phpmailer_lib->load();
     // SMTP Configuration
     $mail->isSMTP();
     $mail->Host = 'smtp.gmail.com';
     $mail->SMTPAuth = true;
     $mail->Username = 'muijing0112@gmail.com';
     $mail->Password = 'hrqy kpzo jptn yaor';
     $mail->SMTPSecure = 'tls';
     $mail->Port = 587;

     // Email Configuration
     $mail->setFrom('muijing0112@gmail.com', 'MuseKnight');

         // Compose and send the email to the teacher
         $mail->addAddress($teacher_email);
         $mail->Subject = 'MuseKnight -  New Lesson Added!';
         $mail->Body = '
             <html>
             <head>
                 <style>
                     body {
                         font-family: Arial, sans-serif;
                         background-color: #f4f4f4;
                         color: #333;
                         margin: 0;
                         padding: 20px;
                     }

                     .container {
                         max-width: 600px;
                         margin: 0 auto;
                         background-color: #fff;
                         padding: 20px;
                         border-radius: 8px;
                         box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                     }

                     h1 {
                         color: #333;
                         text-align: center;
                     }

                     p {
                         margin-bottom: 15px;
                     }

                     a {
                         color: #007BFF;
                         text-decoration: none;
                         font-weight: bold;
                     }

                     a:hover {
                         text-decoration: underline;
                     }

                     .footer {
                         margin-top: 20px;
                         padding-top: 10px;
                         border-top: 1px solid #ccc;
                         text-align: center;
                     }
                 </style>
             </head>
             <body>
                 <div class="container">
                     <h1 style="color: #007BFF; text-align: center;">MuseKnight - New Student!</h1>
                     <p>
                         Dear Teacher,
                         <br>
                         A new student has been added for your subjects.
                     </p>

                     <p>
                         <strong>Subject:</strong> ' . $subject_title  . '
                         <br>
                         <strong>Day:</strong> ' . $day   . '
                         <br>
                         <strong>Time Range:</strong> ' . $time_range  . '
                         <br>
                         <strong>Grade Level:</strong> ' . $grade_level   . '
                     </p>

                     <p>
                         To view the new student, please visit the website at the following link:
                         <br>
                         <a href="http://museknight1.local/" target="_blank">http://museknight1.local/</a>
                     </p>

                     <p>
                        Thank you for your dedication.
                     </p>

                     <div class="footer">
                         Sincerely,
                         <br>
                         [Admin]
                         <br>
                         [MuseKnight]
                     </div>
                 </div>
             </body>
             </html>
         ';
         $mail->isHTML(true);
         if (!$mail->send()) {
            log_message('error', 'Email could not be sent to teacher ' . $teacher_id  . ': ' . $mail->ErrorInfo);
            echo json_encode(['status' => 'error', 'message' => 'Failed to send notification']);
        } else {
            echo json_encode(['status' => 'success', 'message' => 'Notification sent successfully']);
        }
    }

            ///////////////////////// Update the sales table\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
            $where_sales = array(
                'student_id' => $student_id,
                // 'month' => date("F"),
                'status' => 0,
                'is_deleted' => 0,
            );
            $student_current_sale = $this->Sales_model->getOne($where_sales);
            $new_student_subject = array(
                'subject_id' => $subject_id,
                'grade_level' => $grade_level,
                'fee' => $fee,
            );

            if ($student_current_sale) {
                // If a sales record exists, update the subject detail and total amount
                $student_subject_detail = json_decode($student_current_sale['subject_detail'], true);
                $student_subject_detail[] = $new_student_subject;
                $subject_detail = json_encode($student_subject_detail);

                $update_sales_sql = array(
                    'subject_detail' => $subject_detail,
                    'total_amount' => $student_current_sale['total_amount'] + $fee,
                );

                $this->Sales_model->update(array('id' => $student_current_sale['id']), $update_sales_sql);
            } else {
                // If no sales record exists, create a new one
                $subject_detail = '[' . json_encode($new_student_subject) . ']';

                $new_sales_data = array(
                    'student_id' => $student_id,
                    'subject_detail' => $subject_detail,
                    'total_amount' => $fee,
                    'month' => date("F"),
                    'status' => 0,
                    'is_deleted' => 0,
                );

                $this->Sales_model->insert($new_sales_data);
            }
            

            ////////////////////////// Update the teacher_salary table\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
            $where_teacher_salary = array(
                'teacher_id' => $teacher_id,
                'status' => 0,
                'is_deleted' => 0,
            );
            $teacher_current_salary = $this->Salary_model->getOne($where_teacher_salary);
            $new_teacher_earning = $fee * ($commission_rate / 100); // Calculate the teacher's earning

            if ($teacher_current_salary) {
                // If a salary record exists, update the total amount and subject-student details
                $subject_student_detail = json_decode($teacher_current_salary['subject_student'], true);
                $subject_student_detail[] = [
                    'subject_id' => $subject_id,
                    'grade_level' => $grade_level,
                    'student_id' => $student_id,
                    'fee' => $fee,
                ];

                $update_teacher_salary_sql = array(
                    'total_amount' => $teacher_current_salary['total_amount'] + $new_teacher_earning,
                    'subject_student' => json_encode($subject_student_detail),
                );

                $this->Salary_model->update(array('id' => $teacher_current_salary['id']), $update_teacher_salary_sql);
            } else {
                // If no salary record exists, create a new one
                $subject_student_detail = [
                    [
                        'subject_id' => $subject_id,
                        'grade_level' => $grade_level,
                        'student_id' => $student_id,
                        'fee' => $fee,
                    ]
                ];

                $new_teacher_salary_data = array(
                    'teacher_id' => $teacher_id,
                    'commission_rate' => $commission_rate,
                    'total_amount' => $new_teacher_earning,
                    'subject_student' => json_encode($subject_student_detail),
                    'month' => date("F"),
                    'status' => 0,
                    'is_deleted' => 0,
                );

                $this->Salary_model->insert($new_teacher_salary_data);
            }

            redirect(base_url('admin/student/list'));
        }
    }

    

    public function edit($id)
    {
        $this->data['student'] = $this->Student_model->getOne(array('id' => $id, 'is_deleted' => 0));
    
        // Retrieve all subjects
        $this->data['subjects'] = $this->Subject_model->get_where(array('is_deleted' => 0));
        $this->data['teachers'] = $this->Teacher_model->get_where(array('is_deleted' => 0));
        $this->data['teacher_subjects'] = $this->TeacherSubject_model->get_where(array('is_deleted' => 0));
        $this->data['student_subjects'] = $this->StudentSubject_model->get_where(array('student_id' => $id));
    
        // Create an associative array to store subject titles by subject_id
        $subjectTitles = array();
        foreach ($this->data['subjects'] as $subject) {
            $subjectTitles[$subject['id']] = $subject['title'];
        }
    
        // Pass the associative array to the view
        $this->data['subjectTitles'] = $subjectTitles;
     // Determine the default subject ID (you can modify this logic based on your requirements)
     $default_subject_id = isset($this->data['student_subjects'][0]['subject_id']) ? $this->data['student_subjects'][0]['subject_id'] : null;

     // Pass the default subject ID to the view
     $this->data['default_subject_id'] = $default_subject_id;
 
     $this->load->view("admin/student/edit", $this->data);
    }
    

    public function update($id)
    {
        if ($this->input->post()) {
            $sql = array(
                'name' => $this->input->post('name'),
                'password' => $this->input->post('password'),
                'gender' => $this->input->post('gender'),
                'email' => $this->input->post('email'),
                'mobile' => $this->input->post('mobile'),
                'status' => $this->input->post('status'),
                'modified_date' => date('Y-m-d H:i:s'),
            );

            $this->Student_model->update(array('id' => $id), $sql);

            redirect(base_url('admin/student/list')); // calling route

        }
    }

    public function delete($id)
    {
        // $this->User_model->delete(array('id'=>$id)); //delete database data
        $this->Student_model->update(array('id' => $id), array('is_deleted' => 1));
        redirect(base_url('admin/student/list')); // calling route
    }

    public function upGrade()
    {
        if ($this->input->post()) {
            // Get the subject ID and teacher ID from the form data
            $student_id = $this->input->post('student_id');
            $subject_id = $this->input->post('subject_id');
            $teacher_id = $this->input->post('teacher_id'); // Adjust accordingly
            $day = $this->input->post('day'); // Adjust accordingly
            $time_range = $this->input->post('time_range'); // Adjust accordingly
            $grade_level = $this->input->post('grade_level'); // Get the grade level from the form
            $fee = $this->input->post('fee'); // Get the grade level from the form

            // Check if the student already has the selected subject
            $existingSubject = $this->StudentSubject_model->getOne(array('student_id' => $student_id, 'subject_id' => $subject_id));
            if ($existingSubject) {
                // Display an error message
                $this->session->set_flashdata('error', 'Student already has this subject.');
                redirect(base_url('admin/student/list'));
            }
            // Retrieve the raw price for the subject from the 'subject' table
            $subject = $this->Subject_model->getOne(array('id' => $subject_id));
            $raw_price = $subject['fee'];

            // Calculate the final grade price by adding RM200 for each grade level
            $fee = $raw_price + ($grade_level * 30);

            // Now, insert into the student_subject table
            $student_subject_data = array(
                'student_id' => $student_id,
                'subject_id' => $subject_id,
                'teacher_id' => $teacher_id,
                'day' => $day,
                'time_range' => $time_range,
                'grade_level' => $grade_level, // Set the grade level from the form
                'fee' => $fee, // Set the calculated final grade price
                // Add other relevant data for the student_subject table
            );

            $this->StudentSubject_model->insert($student_subject_data);

            redirect(base_url('admin/student/list')); // calling route
        }
    }
    public function get_teachers_by_subject()
{
    if ($this->input->post('subject_id')) {
        $subjectId = $this->input->post('subject_id');
        $teachers = $this->Teacher_model->get_teachers_by_subject($subjectId); // Create this method in your Teacher_model
        echo json_encode($teachers);
    }
}

public function getFreeTimeSlots()
{
    try {
        // Retrieve data from the AJAX request
        $teacherId = $this->input->post('teacher_id');
        $day = $this->input->post('day');
        $studentId = $this->input->post('student_id');

        // Check if the teacher or student has any recorded time range
        $hasRecordedTimeRange = $this->StudentSubject_model->hasRecordedTimeRange($teacherId, $day);
        $hasStudentRecordedTimeRange = $this->StudentSubject_model->hasRecordedTimeRange($studentId, $day);

        // Define all possible time slots for the day
        $allTimeSlots = array(
            '09:00 - 10:00',
            '10:00 - 11:00',
            '11:00 - 12:00',
            '12:00 - 13:00',
            '13:00 - 14:00',
            '14:00 - 15:00',
            '15:00 - 16:00',
            '16:00 - 17:00',
            '17:00 - 18:00',
            '18:00 - 19:00',
            '19:00 - 20:00',
            '21:00 - 22:00',
        );

        // Check if the student has any recorded time range for the selected day
        $hasStudentRecordedTimeRangeForDay = $this->StudentSubject_model->hasRecordedTimeRangeForDay($studentId, $day);

        if (!$hasRecordedTimeRange && !$hasStudentRecordedTimeRange && !$hasStudentRecordedTimeRangeForDay) {
            // If no recorded time range for teacher or student on the selected day, provide all time slots
            $freeTimeSlots = $allTimeSlots;
        } else {
            // If there is a recorded time range, get occupied time ranges for the teacher, student, and student for the selected day
            $occupiedTeacherTimeRanges = $this->StudentSubject_model->getOccupiedTimeRanges($teacherId, $day);
            $occupiedStudentTimeRanges = $this->StudentSubject_model->getOccupiedTimeRanges($studentId, $day);
            $occupiedStudentTimeRangesForDay = $this->StudentSubject_model->getOccupiedTimeRangesForDay($studentId, $day);

            // Combine occupied time ranges for both teacher and student
            $occupiedTimeRanges = array_merge($occupiedTeacherTimeRanges, $occupiedStudentTimeRanges, $occupiedStudentTimeRangesForDay);

            // Filter out occupied time slots
            $freeTimeSlots = array_diff($allTimeSlots, $occupiedTimeRanges);
        }

        // Return the response as JSON
        $this->output->set_content_type('application/json')->set_output(json_encode(array_values($freeTimeSlots)));
    } catch (Exception $e) {
        // Log the exception
        log_message('error', 'Exception in getFreeTimeSlots: ' . $e->getMessage());

        // Return an error response
        $this->output->set_status_header(500)->set_output(json_encode(['error' => 'Internal Server Error']));
    }
}

}
