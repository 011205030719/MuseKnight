<?php $this->load->view("student/nav"); ?>
<?php $this->load->view("layouts/header"); ?>


<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/r/dt/jq-2.1.4,jszip-2.5.0,pdfmake-0.1.18,dt-1.10.9,af-2.0.0,b-1.0.3,b-colvis-1.0.3,b-html5-1.0.3,b-print-1.0.3,se-1.0.1/datatables.min.css"/>
<style>
        .payment-button {
        background-color: #FF5733; 
        color: white; 
    }


    .receipt-button {
        background-color: mediumspringgreen;
        color: white;
    }
     .custom-module {
        margin-top: -10px;
        margin-bottom: 20px;
        background-color: #703be7;
        height: 40px;
        width: 250px;
        display: flex;
        justify-content: center;
        align-items: center;
        position: relative;
        border-radius: 25px;
        color: #fff;
        text-align: left;
        font-size: 18px;
    }

    .status {
        color: white;
        font-size: 12px;
        font-weight: 600;
        padding-top: 3px;
        padding-bottom: 5px;
        padding-left: 10px;
        padding-right: 10px;
        border-radius: 10px;
    }

    .table-container {
        overflow-x: auto;
    }

    /* Modify the existing table style */
    table {
        background-color: white;
        width: 100%; /* Set the width to 100% */
        table-layout: fixed; /* Set the table layout to fixed */
        overflow: auto;
        display: block;
    }

    /* Adjust the widths of your table columns as needed */
    table th,
    table td {
        padding: 5px;
        text-align: left;
    }
</style>


<div class="container-fluid" style="padding-left: 20%; padding-right: 5%; padding-top: 3%;">

    
    <div class="card shadow">
        <div style="padding: 30px;">
            <div style="overflow-x: auto;" class="table-container">
                <table id="lecturerTable"style="background-color: white; max-height: 400px; overflow-x: auto; display: block;" class="table table-bordered">
                    <thead>
                        
                        <tr style="border-bottom: 2px solid lightgray;">
                            <th style="padding:5px 40px; width: 5%;">#</th>
                            <th style="padding:5px 40px; width: 10%;">Student ID</th>
                            <th style="padding:5px 40px; width: 10%;">Payment ID</th>
                            <th style="padding:5px 40px; width: 10%;">Subject</th>
                            <th style="padding:5px 40px; width: 10%;">Grade</th>
                            <th style="padding:5px 40px; width: 10%;">Month</th>
                            <th style="padding:5px 40px; width: 10%;">Fees</th>
                            <th style="padding:5px 40px; width: 10%;">Status</th>
                            <th style="padding:5px 40px; width: 10%;">Payment Date</th>
                            <th style="padding:5px 40px; width: 40%;">Action</th>
                        </tr>
                    </thead>
                        <tbody>
                            <?php foreach ($students as $student): ?>
                                <?php if ($student['id'] == $userdata['id']): ?>
                                    <?php
                                    // Fetch all subjects for the current student
                                    $student_subjects = $this->StudentSubject_model->getSubjectsByStudentId($student['id']);
                                    ?>

                                    <?php foreach ($student_subjects as $student_subject): ?>
                                        <?php
                                        $user_id = $student['id'];
                                        $subject_id = $student_subject['subject_id'];
                                        $grade_level = $student_subject['grade_level'];
                                        $fee = $student_subject['fee'];

                                        // Retrieve the serial based on both user and subject
                                        $payment_serial = $this->Sales_model->getPaymentSerialByUserAndSubject($user_id, $subject_id);
                                        $payment_serial = $payment_serial !== '' ? $payment_serial : 'No Payment Available';

                                        $subject_title = ''; // Define subject_title
                                        // Find the subject_title based on subject_id from the subjects array
                                        foreach ($subjects as $subject) {
                                            if ($subject['id'] == $subject_id) {
                                                $subject_title = $subject['title'];
                                                break; // Exit the loop once subject_title is found
                                            }
                                        }
                                        ?>
                                        
                                        <tr class="table_row">
                                            <td style="width:5%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $student['id'] ?></td>
                                            <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $student['serial'] ?></td>
                                            <td style="width:20%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $payment_serial ?></td>
                                            <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $subject_title ?></td>
                                            <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $grade_level ?></td>
                                            <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= date('F') ?></td>                        
                                            <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;"><?= $fee ?></td>
                                            <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                                <?php
                                                // Assuming $student['id'], $subject_id, and date('F') represent student_id, subject_id, and current month
                                                $status = $this->Sales_model->getPaymentStatus($userdata['id'], $subject_id, date('F'));

                                                if ($status == 0) {
                                                    echo '<span style="color: red;">Not Paid</span>';
                                                } elseif ($status == 1) {
                                                    echo '<span style="color: mediumspringgreen;">Paid</span>';
                                                } else {
                                                    echo '<span style="color: gray;">Unknown Status</span>';
                                                }
                                                ?>
                                            </td>
                                            <td style="width:10%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                                <?php
                                                // Get the correct payment date from the sales database for the specific subject
                                                $payment_date = $this->Sales_model->getPaymentDateForSubject($user_id, $subject_id);
                                                if ($payment_date) {
                                                    echo $payment_date;
                                                } else {
                                                    echo 'No Payment Date';
                                                }
                                                ?>
                                            </td>
                                            <td style="width:40%; padding-left:10px; padding-top:8px; padding-bottom:8px;">
                                                <?php foreach ($students as $student) : ?>
                                                    <?php
                                                    // Get the payment status for the current student
                                                    $paymentStatus = $this->Sales_model->getPaymentStatus($student['id'], $subject_id); // Replace subject_id with the subject ID you want to check
                                                    ?>

                                                    <?php if ($paymentStatus === 1) : ?>
                                                        <!-- Display the receipt button with the receipt-button class -->
                                                        <a href="#" class="btn receipt-button" data-toggle="modal" data-target="#exampleModalCenter" data-student-id="<?= $student['id'] ?>">History</a>
                                                    <?php elseif ($paymentStatus === 0) : ?>
                                                        <!-- Display the payment button with the payment-button class -->
                                                        <a href="<?= base_url('student/payment/gateway/' . $student['id']) ?>" class="btn payment-button">Pay Now</a>
                                                    <?php else : ?>
                                                        <!-- Handle other cases if needed -->
                                                    <?php endif; ?>
                                                <?php endforeach; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?> 
                            <?php endforeach; ?>
                        </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


    <!------------------------------------------model message-------------------------------------------->
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <form method="POST" id="create_form" action="<?=base_url('student/payment/store')?>">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">Tuition Invoice</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                    </div>

                    <div class="modal-body">
                        <div class="container">
                            <div class="row">
                                <div class="span4">
                                    <img src="<?= base_url('assets/img/MuseKnightLogo.png') ?>" class="img-rounded logo" style="max-width: 100px; max-height: 100px;">
                                        <address>
                                            <strong>MuseKnight</strong><br>
                                                35, Lajpat Nagar<br>
                                                Gurugram, Haryana-122001 
                                        </address>
                                </div>

                                <div class="span4 card" style="background-color: #f0f0f0; padding: 10px; width: 40%; position: absolute; top: 0; right: 3%;">
                                    <table class="invoice-head">
                                        <tbody>
                                            <tr>
                                                <td class="pull-right"><strong>Invoice #</strong></td>
                                                <td>
                                                    <?php
                                                    // Use the $payment_serial as the invoice number
                                                    echo isset($payment_serial) ? $payment_serial : 'No Payment Available';
                                                    ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td class="pull-right"><strong>Serial</strong></td>
                                                <td><?= $userdata['serial'] ?></td>
                                            </tr>
                                            <tr>
                                                <td class="pull-right"><strong>Student Name</strong></td>
                                                <td><?= $userdata['name'] ?></td>
                                            </tr>
                                            <tr>
                                                <td class="pull-right"><strong>Date</strong></td>
                                                <td><?= date('d/m/Y') ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                            </div>

                            <div class="row">
                                <div class="span8">
                                    <h2>Invoice</h2>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 span8 well invoice-body">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th class="text-center" style="width: 10%; padding: 5px 30px;">No</th>
                                                <th class="text-center" style="width: 30%; padding: 5px 60px;">Subject</th>
                                                <th class="text-center" style="width: 30%; padding: 5px 60px;">Grade</th>
                                                <th class="text-center" style="width: 30%; padding: 5px 70px;">Amount</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                if (isset($userdata['id'])) {
                                                    // Assuming $userdata['id'] contains the student_id
                                                    $student_id = $userdata['id'];

                                                    // Fetch the subject, grade, and tuition data associated with the student
                                                    $this->db->select('serial,subject.title, student_subject.grade_level, sales.subject_fee');
                                                    $this->db->from('sales');
                                                    $this->db->join('student_subject', 'sales.subject_id = student_subject.subject_id', 'left');
                                                    $this->db->join('subject', 'student_subject.subject_id = subject.id', 'left');
                                                    $this->db->where('sales.student_id', $student_id);
                                                    $this->db->where('sales.status', 1); // Assuming 1 represents a successful sale

                                                    $sales_query = $this->db->get();
                                                    $sales_details = $sales_query->result_array();

                                                    // Initialize total amount
                                                    $totalAmount = 0;

                                                    // Display the sales details
                                                    $counter = 1;
                                                    foreach ($sales_details as $sale) {
                                                        echo '<tr>';
                                                        echo '<td class="text-center">' . $counter . '</td>';
                                                        echo '<td class="text-center">' . (isset($sale['title']) ? $sale['title'] : 'Unknown Subject') . '</td>';
                                                        echo '<td class="text-center">' . (isset($sale['grade_level']) ? $sale['grade_level'] : '') . '</td>';
                                                        echo '<td class="text-center">' . (isset($sale['subject_fee']) ? 'RM ' . number_format($sale['subject_fee'], 2) : '') . '</td>';
                                                        echo '</tr>';

                                                        // Accumulate the amount
                                                        if (isset($sale['subject_fee'])) {
                                                            $totalAmount += $sale['subject_fee'];
                                                        }

                                                        $counter++;
                                                    }

                                                    // Display the total amount in the "Total" row
                                                    echo '<tr><td colspan="3" class="text-center"><strong>Total</strong></td>';
                                                    echo '<td class="text-center"><strong>RM ' . number_format($totalAmount, 2) . '</strong></td></tr>';
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary">Print</button>
                    </div>
            </div>
        </div>
    </div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- DataTables and Bootstrap DataTables -->
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<!-- DataTables library -->
<script type="text/javascript" src="https://cdn.datatables.net/r/dt/jq-2.1.4,jszip-2.5.0,pdfmake-0.1.18,dt-1.10.9,af-2.0.0,b-1.0.3,b-colvis-1.0.3,b-html5-1.0.3,b-print-1.0.3,se-1.0.1/datatables.min.js"></script>

<script>
    $(document).ready(function() {
        $('#lecturerTable').DataTable({
            dom: 'lBfrtip',
            lengthMenu: [10, 25, 50],
            searching: true,
            buttons: [
                {
                    extend: 'excel',
                    text: 'Download Data',
                    className: 'btn btn-outline-success',
                    init: function(api, node, config) {
                        $(node).removeClass('dt-button');
                        $(node).css({
                            'margin-left': '10%',
                            'margin-bottom': '10%',
                            'height': '30px',
                            'width': '150px',
                            'font-size': '17px',
                            'display': 'flex',
                            'align-items': 'center'
                        });
                    }
                }
            ]
        });
    });
    </script>