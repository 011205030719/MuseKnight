<?php if($is_print == false){ $this->load->view("teacher/nav"); } ?>
<?php $this->load->view("layouts/header"); ?>

<style>
  .update-status{
    display:flex;
    align-items: center;
    justify-content:space-between;
    margin:15px 0px;
    padding:10px 15px;
    font-size: 12px;
    border-radius:10px;
    width: 150%;
    background-color:rgb(100,100,100,0.2);
  }
  .update-button{
    border-radius:5px;
    padding:5px 10px;
    background-color:dodgerblue;
    color:white;
    font-size:10px;
    border:0;
    font-weight:600;
  }
  .update-button:hover{
    background-color: blue;
  }
  .print-invoice {
    margin-left: -15%;
    margin-right: 10%;
    padding-left:25%;
    padding-right:28%;
  }
  .invoice-layout {
    padding-left:25%;
    padding-right:28%;
  }
</style>
<div class="<?php echo $is_print == false ? 'invoice-layout':'print-invoice'; ?>">
  <?php if($is_print == false){ ?>
          <div style="padding:10px 0px; font-weight:600;">
              <span style="color:gray;">Home / </span>
              <a href="<?= base_url($folder_name.'/salary/list') ?>" style="text-decoration:none; color:black;">Teacher salary</a>
              <span>/ Invoice</span>
              </div>
  <?php } ?>
          <div class="card" style="margin-bottom:30px; width:150%;">
            <div class="card-body">
              <div class="container mt-3">
                <div class="row d-flex align-items-baseline">
                  <div class="col-xl-9">
                    
                      <p style="color: #7e8d9f;font-size: 20px;">Invoice >> <strong>ID: <?= $teacher['serial'] ?></strong></p>
                  </div>
                  <div class="col-xl-3 float-end">
                    <a class="btn btn-light text-capitalize border-0" data-mdb-ripple-color="dark" href="<?=base_url('teacher/salary/invoice/'.$salary['id'].'/'.true)?>" target="_blank"><i class="fas fa-print text-primary"></i> Print</a>
                    <a class="btn btn-light text-capitalize" data-mdb-ripple-color="dark"><i
                        class="far fa-file-pdf text-danger"></i> Export</a>
                  </div>
                  <hr>
                </div>

            <div class="container">
              <div class="col-md-12">
                <div class="text-center">
                  <i class="fab fa-mdb fa-4x ms-0" style="color:#5d9fc5 ;"></i>
                  <img src="<?= base_url('assets/img/MuseKnightLogo.png') ?>" class="img-rounded logo" style="max-width: 100px; max-height: 100px;">
                  <p class="pt-0">MuseKnight</p>
                </div>
              </div>


              <div class="row">
                <div class="col-xl-8">
                  <ul class="list-unstyled">
                    <li class="text-muted" style="margin-bottom:10px;">To:  <span style="color:#5d9fc5 ;"><?= $teacher['name'] ?></span></li>
                    <li class="text-muted">No 9, Jalan Teknologi,</li>
                    <li class="text-muted">Pju 5 Kota Damansara,</li>
                    <li class="text-muted">47810 Petaling Jaya,</li>
                    <li class="text-muted">Selangor</li>
                    <li class="text-muted" style="margin-top:10px;"><i class="fas fa-phone"></i> <?= $teacher['mobile'] ?></li>
                  </ul>
                </div>
                <div class="col-xl-4">
                  <p class="text-muted">Invoice</p>
                  <ul class="list-unstyled">
                    <li class="text-muted">
                      <i class="fas fa-circle" style="color:#84B0CA ;"></i><span class="fw-bold">ID: </span><?= $teacher['serial'] ?>
                    </li>
                    <li class="text-muted">
                      <i class="fas fa-circle" style="color:#84B0CA ;"></i><span class="fw-bold">Creation Date: </span><?= $teacher['created_date'] ?>
                    </li>
                    <li class="text-muted"><i class="fas fa-circle" style="color:#84B0CA ;"></i><span class="me-1 fw-bold">Status: </span>
                      <?php if($salary['status'] == 0){ ?>
                      <span class="badge bg-warning text-black fw-bold">Unpaid</span>
                      <?php }elseif($salary['status'] == 1){ ?>
                      <span class="badge bg-success text-white fw-bold">Paid</span>
                      <?php } ?>
                    </li>
                  </ul>
                </div>
              </div>

              <div class="row my-2 mx-1 justify-content-center">
                <table class="table table-striped table-borderless">
                  <thead style="background-color:#84B0CA ;" class="text-white">
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Student Name</th>
                      <th scope="col">Subject</th>
                      <th scope="col">Grade Level</th>
                      <th scope="col">Month</th>
                      <th scope="col">Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($subjects as $key => $subject) { ?>
                        <tr>
                            <th scope="row"><?= $key + 1 ?></th>
                            <td><?= $subject['student_name'] ?></td>
                            <td><?= $subject_title[$subject['subject_id']] ?></td>
                            <td><?= $subject['grade_level'] ?></td>
                            <td><?= $salary['month'] ?></td>
                            <td><?= $subject['fee'] ?></td>
                        </tr>
                    <?php } ?>
                </tbody>

                </table>
              </div>
              <div class="row">
                <div class="col-xl-8">
                  <p class="ms-3">Add additional notes and payment information</p>
                </div>
                <div class="col-xl-4">
                  <ul class="list-unstyled">
                    <li class="text-muted ms-3 mt-2"><span class="text-black me-4">Payment Date</span><?= $salary['receipt_date'] ? $salary['receipt_date'] : '-' ?></li>
                    <li class="text-muted ms-3"><span class="text-black me-4">Commission Rate</span><?= $teacher['commission_rate']?$teacher['commission_rate']:'0%' ?> %</li>
                    <?php
                        $totalAmount = 0;

                        foreach ($subjects as $subject) {
                            $totalAmount += $subject['fee'] * ($teacher['commission_rate']);
                        }
                        ?>
                        <li class="text-muted ms-3 mt-2"><span class="text-black me-4">Total Amount</span>RM <?= number_format($totalAmount, 2) ?></li>

                  </ul>
                </div>
              </div>
              <hr>
              <div class="row">
                <div class="col-xl-12">
                  <p>Invoice from MuseKnight.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

  <script>
    <?php if ($is_print == true) { ?>
      window.onload = function () {
          window.print();
      };
    <?php } ?>
</script>
