<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/userguide3/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
////////////////////////////////////////// Auth \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
$route['login'] = 'auth/login';
$route['login_validate'] = 'auth/login_validate';
$route['logout'] = 'auth/logout';

////////////////////////////////////////// Admin \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
$route['admin/dashboard'] = 'admin/dashboard/index';
// $route['admin/admin/list'] = 'admin/admin/index';
// $route['admin/admin/store'] = 'admin/admin/store';
// $route['admin/admin/edit/(:num)'] = 'admin/admin/edit/$1';
// $route['admin/admin/update/(:num)'] = 'admin/admin/update/$1';
// $route['admin/admin/delete/(:num)'] = 'admin/admin/delete/$1';

$route['admin/student/list'] = 'admin/student/index';
$route['admin/student/store']= 'admin/student/store';
$route['admin/student/details/(:num)'] = 'admin/student/details/$1';
$route['admin/student/edit/(:num)'] = 'admin/student/edit/$1';
$route['admin/student/update/(:num)'] = 'admin/student/update/$1';
$route['admin/student/delete/(:num)'] = 'admin/student/delete/$1';

$route['admin/teacher/list'] = 'admin/teacher/index';
$route['admin/teacher/store']= 'admin/teacher/store';
$route['admin/teacher/edit/(:num)'] = 'admin/teacher/edit/$1';
$route['admin/teacher/update/(:num)'] = 'admin/teacher/update/$1';
$route['admin/teacher/delete/(:num)'] = 'admin/teacher/delete/$1';

$route['admin/subject/list'] = 'admin/subject/index';
$route['admin/subject/store']= 'admin/subject/store';
$route['admin/subject/edit/(:num)'] = 'admin/subject/edit/$1';
$route['admin/subject/update/(:num)'] = 'admin/subject/update/$1';
$route['admin/subject/delete/(:num)'] = 'admin/subject/delete/$1';

$route['admin/lesson/list'] = 'admin/lesson/index';
$route['admin/lesson/store']= 'admin/lesson/store';
$route['admin/lesson/edit/(:num)'] = 'admin/lesson/edit/$1';
$route['admin/lesson/update/(:num)'] = 'admin/lesson/update/$1';
$route['admin/lesson/delete/(:num)'] = 'admin/lesson/delete/$1';

$route['admin/salary/list'] = 'admin/salary/index';
$route['admin/salary/store']= 'admin/salary/store';
$route['admin/salary/edit/(:num)'] = 'admin/salary/edit/$1';
$route['admin/salary/update/(:num)'] = 'admin/salary/update/$1';
$route['admin/salary/delete/(:num)'] = 'admin/salary/delete/$1';

$route['admin/payment/list'] = 'admin/payment/index';
$route['admin/payment/gateway/(:num)'] = 'admin/payment/gateway/$1';
$route['admin/payment/invoice/(:num)'] = 'admin/payment/invoice/$1';
$route['admin/payment/updateStatus/(:num)'] = 'admin/payment/updateStatus/$1';
$route['admin/payment/store']= 'admin/payment/store';

$route['admin/profile/list/(:num)'] = 'admin/profile/index';
$route['admin/profile/store']= 'admin/profile/store';
$route['admin/profile/edit/(:num)'] = 'admin/profile/edit/$1';
$route['admin/profile/update/(:num)'] = 'admin/profile/update/$1';

$route['admin/logout'] = 'admin/auth/logout';

////////////////////////////////////////// Student \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
$route['student/dashboard'] = 'student/dashboard/index';
$route['student/logout'] = 'student/auth/logout';

$route['student/announcement/subjectList'] = 'student/announcement/subjectList';
$route['student/announcement/list/(:num)'] = 'student/announcement/index/$1';
$route['student/announcement/subjectFile'] = 'student/announcement/subjectFile';

$route['student/payment/list'] = 'student/payment/index';
$route['student/payment/submit_payment'] = 'student/payment/SubmitPayment';
$route['student/payment/gateway/(:num)'] = 'student/payment/gateway';
$route['student/payment/store']= 'student/payment/store';

$route['student/profile/list/(:num)'] = 'student/profile/index';
$route['student/profile/store']= 'student/profile/store';
$route['student/profile/edit/(:num)'] = 'student/profile/edit/$1';
$route['student/profile/update/(:num)'] = 'student/profile/update/$1';

////////////////////////////////////////// Teacher \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
$route['teacher/dashboard'] = 'teacher/dashboard/index';
$route['teacher/logout'] = 'teacher/auth/logout';

$route['teacher/annoucement/list'] = 'teacher/annoucement/index';
$route['teacher/annoucement/subjectFile'] = 'teacher/annoucement/subjectFile';

$route['teacher/student/list'] = 'teacher/student/index';
$route['teacher/student/store']= 'teacher/student/store';
$route['teacher/student/edit/(:num)'] = 'teacher/student/edit/$1';
$route['teacher/student/update/(:num)'] = 'teacher/student/update/$1';

$route['teacher/salary/list'] = 'teacher/salary/index';
$route['teacher/salary/store']= 'teacher/salary/store';

$route['teacher/profile/list/(:num)'] = 'teacher/profile/index';
$route['teacher/profile/store']= 'teacher/profile/store';
$route['teacher/profile/edit/(:num)'] = 'teacher/profile/edit/$1';
$route['teacher/profile/update/(:num)'] = 'teacher/profile/update/$1';

$route['teacher/annoucement/getStudentsForSubject'] = 'teacher/annoucement/getStudentsForSubject';


////////////////////////////////////////// CRUD \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
$route['CRUD/index'] = 'CRUD/index'; // read all data
$route['CRUD/create'] = 'CRUD/create'; // create view
$route['CRUD/store/(:num)'] = 'CRUD/store/$1'; // store data
$route['CRUD/edit/(:num)'] = 'CRUD/edit/$1'; // read edit data
$route['CRUD/update/(:num)'] = 'CRUD/update/$1'; // update data
$route['CRUD/delete/(:num)'] = 'CRUD/delete/$1'; // delete data

# Default
$route['default_controller'] = 'auth/login';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
