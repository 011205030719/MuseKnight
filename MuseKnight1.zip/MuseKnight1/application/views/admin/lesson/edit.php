<?php $this->load->view("admin/nav"); ?>
<?php $this->load->view("layouts/header"); ?>

<div class="container-fluid" style="padding-left: 20%; padding-right: 5%; padding-top: 3%;">
    <form method="POST" id="edit_form" action="<?= base_url('admin/lesson/update/'.$student_subject['id']) ?>">
        <div style="text-align: end; margin-bottom:20px;">
            <a href="<?= base_url('admin/lesson/list') ?>" class="btn btn-secondary">Back</a>
            <button type="submit" class="btn btn-primary">Save Changes</button>
        </div>
        <div class="card shadow">
            <div style="padding: 30px;">
                <div class="row" style="text-align: start; margin-bottom:10px" >
                    <div class="col-6 form-group mb-2">
                        <label for="teacher_id" style="font-weight: 500;" class="mb-2">Teacher</label>
                        <select name="teacher_id" id="teacher_id" class="form form-select">
                            <option value=""disabled selected>Select Teacher</option>
                            <?php foreach ($teachers as $teacher) { ?>
                                <option value="<?= $teacher['id'] ?>" <?= ($student_subject['teacher_id'] == $teacher['id']) ? 'selected' : '' ?>>
                                    <?= $teacher['name'] ?>
                                </option>
                                
                            <?php } ?>
                        </select>
                    </div>
                    
                    <div class="col-6 form-group mb-2">
                        <label for="student_id" style="font-weight: 500;" class="mb-2">Student</label>
                        <select name="student_id" id="student_id" class="form form-select">
                            <option value=""disabled selected>Select Student</option>
                            <?php foreach ($students as $student) { ?>
                                <option value="<?= $student['id'] ?>" <?= ($student_subject['student_id'] == $student['id']) ? 'selected' : '' ?>>
                                    <?= $student['name'] ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="col-6 form-group mb-2">
                        <label for="subject_id" style="font-weight: 500;" class="mb-2">Subject</label>
                        <select name="subject_id" id="subject_id" class="form form-select">
                             <option value=""disabled selected>Select Subject</option>
                              <?php foreach ($subjects as $subject) { ?>
                                  <option value="<?= $subject['id'] ?>" <?= ($student_subject['subject_id'] == $subject['id']) ? 'selected' : '' ?>>
                                      <?= $subject['title'] ?>
                                  </option>
                               <?php } ?>
                        </select>
                    </div>
                    <!-- Add other lesson fields here -->
                    <div class="col-6 form-group mb-2">
                        <label for="grade_level" style="font-weight: 500;" class="mb-2">Grade</label>
                            <input required type="text" id="grade_level" class="form-control" name="grade_level" placeholder="Enter Current Grade">
                    </div>
                    <div class="col-6 form-group mb-2">
                        <label for="day" style="font-weight: 500;" class="mb-2">Day</label>
                        <input required type="text" id="day" class="form-control" name="day" value="<?= $student_subject['day'] ?>">
                    </div>
                    <div class="col-6 form-group mb-2">
                        <label for="start_time">Start Time</label>
                        <input type="time" class="form-control" id="start_time" name="start_time">
                    </div>
                    <div class="col-6 form-group mb-2">
                        <label for="end_time">End Time</label>
                        <input type="time" class="form-control" id="end_time" name="end_time">
                    </div>
                    <!-- Add other lesson fields here -->
                </div>
                <div style="text-align: end;">
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </div>
        </div>
    </form>
</div>
