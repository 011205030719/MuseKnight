<?php

class Teacher extends MY_Controller {

    // Predefine function in controller
	public function __construct()
	{
        parent::__construct();
        // $this->data['invalid'] = 0;
        $this->data['folder_name'] = 'admin';
        $this->load->model("Teacher_model");
        $this->load->model("Subject_model");
        $this->load->model("TeacherSubject_model");
        $this->auth_validate();
	}

    public function index(){
        $this->data['teachers'] = $this->Teacher_model->get_where(array('is_deleted' => 0));
    
        // Fetch subjects for each teacher and add them to the data array
        foreach ($this->data['teachers'] as &$teacher) {
            $teacher['subjects'] = $this->Teacher_model->getTeacherSubjects($teacher['id']);
        }
    
        $this->data['subjects'] = $this->Subject_model->get_where(array('is_deleted' => 0));
        $this->load->view("admin/teacher/list", $this->data);
    }
    

    public function store() {
        if ($this->input->post()) {
            // add teacher serial id
            $serials = $this->Teacher_model->getIDKeyArray('serial');
            if ($serials) {
                $largestNumber = 0;
                foreach ($serials as $str) {
                    $matches = [];
                    if (preg_match('/(\d+)/', $str, $matches)) {
                        $number = intval($matches[0]);
                        if ($number > $largestNumber) {
                            $largestNumber = $number;
                        }
                    }
                }
                $serial = 'TC' . str_pad(($largestNumber + 1), 5, '0', STR_PAD_LEFT);
            }else {
                $serial = 'TC00001';
            }
    
            // Upload PDF document
            $config['upload_path'] = FCPATH . 'assets/document/';
            $config['allowed_types'] = 'pdf';
            $config['max_size'] = 2048;  // You can adjust the max size as needed
            $this->load->library('upload', $config);

            if ($this->upload->do_upload('cert')) {
                $data = $this->upload->data();
                $cert_name = $data['file_name'];
            } else {
                $data = $this->upload->data();
                $cert_name = $data['file_name'];
            }

            // Store data in teacher table
            $teacherData = array(
                'serial' => $serial,
                'name' => $this->input->post('name'),
                'email' => $this->input->post('email'),
                'password' => $this->input->post('password'),
                'mobile' => $this->input->post('mobile'),
                'gender' => $this->input->post('gender') ?: 'Unknown',
                'status' => $this->input->post('status'),
                'commission_rate' => $this->input->post('commission_rate'),
                'bank' => $this->input->post('bank'),
                'account' => $this->input->post('account'),
                'cert' => $cert_name,  // Store the PDF filename in the 'cert' field
            );
            $teacherId = $this->Teacher_model->insert($teacherData);
    
            // Handle multiple subjects
            $selectedSubjects = $this->input->post('subject_id');
            if ($selectedSubjects && is_array($selectedSubjects)) {
                foreach ($selectedSubjects as $subjectId) {
                    $teacherSubjectData = array(
                        'subject_id' => $subjectId,
                        'teacher_id' => $teacherId,
                    );
                    $this->TeacherSubject_model->insert($teacherSubjectData);
                }
            }
    
            redirect(base_url('admin/teacher/list'));
        }
    }
    
    // Teacher.php controller
public function viewPDF($teacherId) {
    // Get the teacher information including the PDF filename
    $teacher = $this->Teacher_model->getTeacherById($teacherId);

    // Check if the teacher and the PDF file exist
    if ($teacher && $teacher['cert']) {
        $pdfPath = FCPATH . 'assets/document/' . $teacher['cert'];

        // Check if the file exists
        if (file_exists($pdfPath)) {
            header('Content-Type: application/pdf');
            header('Content-Disposition: inline; filename="' . $teacher['cert'] . '"');
            header('Content-Transfer-Encoding: binary');
            header('Accept-Ranges: bytes');
            readfile($pdfPath);
        } else {
            // PDF file not found
            show_404();
        }
    } else {
        // Teacher or PDF information not found
        show_404();
    }
}

    public function edit($id){
        $this->data['subjects'] = $this->Subject_model->get_where(array('is_deleted' => 0));
        $this->data['teacher_subjects'] = $this->TeacherSubject_model->get_where(array('teacher_id'=>$id,'is_deleted' => 0));
        $this->data['teacher'] = $this->Teacher_model->getOne(array('id'=>$id,'is_deleted'=>0));
        $this->load->view("admin/teacher/edit",$this->data);
    }
    public function update($id){
       
        if ($this->input->post()) {
            
            $sql = array(
                'name' => $this->input->post('name'),
                'email' => $this->input->post('email'),
                'password' => $this->input->post('password'),
                'mobile' => $this->input->post('mobile'),
                'gender' => $this->input->post('gender'),
                'status' => $this->input->post('status'),
                'commission_rate' => $this->input->post('commission_rate'),
                'bank' => $this->input->post('bank'),
                'account' => $this->input->post('account'),
                'modified_date' => date('Y-m-d H:i:s'),
            );
        }
            // Update the teacher's data
            $this->Teacher_model->update(array('id' => $id), $sql);
            redirect(base_url('admin/teacher/list')); // calling route
            
        }
    
        public function delete($id) {
            $this->Teacher_model->update(array('id' => $id), array('is_deleted' => 1));
            redirect(base_url('admin/teacher/list'));
        }    
}













