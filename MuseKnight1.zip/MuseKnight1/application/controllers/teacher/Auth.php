<?php
class Auth extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        $this->load->model('Teacher_model'); // Load the model.
    }
    
    public function login() {
        $this->load->view('login'); // Load the login view.
    }

    public function processLogin() {
        // Get the email and password from the form using CodeIgniter's input class.
        $email = $this->input->post('email');
        $password = $this->input->post('password');
        
        $teacher = $this->Teacher_model->getOne(array('email' => $email,));

        // if ($admin && password_verify($password, $admin['password'])) {
        if ($teacher && $password == $teacher['password']) {
            $this->session->set_userdata('user_role', 'teacher'); // Set user_role as 'admin'
            $this->session->set_userdata('user_id', $teacher['id']);
            redirect(base_url('teacher/home'));// Redirect to the teacher homepage.
        } else {
            // Login failed, show an error message and stay on the login page.
            $error_message = 'Invalid email or password.';
            echo "<script>alert('$error_message'); window.location = '" . base_url() . "';</script>";
        }
    }
    
    // public function navIdentify()
    // {
    //     $userRole = $this->session->userdata('user_role');
        
    //     switch ($userRole) {
    //         case 'admin':
    //             // Navigation menu for admin
    //             return '
    //                 <a href="' . base_url('auth/Admin_page') . '" class="nav__link"><i class="bx bxs-pie-chart-alt-2 nav__icon"></i> Dashboard </a>
    //                 <a href="' . base_url('auth/subject') . '" class="nav__link"><i class="bx bxs-book-reader nav__icon"></i> Subject</a>
    //                 <a href="' . base_url('auth/addTeacher') . '" class="nav__link"><i class="bx bx-user-plus nav__icon"></i> Add Teacher</a>
    //                 <a href="' . base_url('auth/teacherSalary') . '" class="nav__link"><i class="bx bx-money-withdraw nav__icon"></i> Teacher Salary</a>
    //                 <a href="' . base_url('auth/addStudent') . '" class="nav__link"><i class="bx bx-group nav__icon"></i> Add Student</a>
    //                 <a href="' . base_url('auth/studentFees') . '" class="nav__link"><i class="bx bx-credit-card nav__icon"></i> Student Fees</a>
    //                 <a href="' . base_url('auth/timeTable') . '" class="nav__link"><i class="bx bx-table nav__icon"></i> TimeTable</a>
    //                 <a href="' . base_url('auth/myProfile') . '" class="nav__link"><i class="bx bx-user-circle nav__icon"></i> My Profile</a>
    //             ';
    //             break;
                
    //         case 'student':
    //             // Navigation menu for students
    //             return '
    //                 <ul class="nav__list">
    //                     <li><a href="' . base_url('auth/student_page') . '">Dashboard</a></li>
    //                     <!-- Add other student-specific menu items here -->
    //                 </ul>
    //             ';
    //             break;

    //         case 'teacher':
    //             // Navigation menu for management
    //             return '
    //                 <ul class="nav__list">
    //                     <li><a href="' . base_url('auth/teacher_page') . '">Dashboard</a></li>
    //                     <!-- Add other management-specific menu items here -->
    //                 </ul>
    //             ';
    //             break;
    //     }
    // }
}
