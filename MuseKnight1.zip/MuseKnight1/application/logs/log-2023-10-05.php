<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-10-05 09:51:39 --> UTF-8 Support Enabled
DEBUG - 2023-10-05 09:51:40 --> UTF-8 Support Enabled
DEBUG - 2023-10-05 09:51:41 --> UTF-8 Support Enabled
DEBUG - 2023-10-05 09:51:41 --> UTF-8 Support Enabled
