<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
</head>

<body>
<div class="container" style="margin-top: 75px;">
    <div class="card shadow mb-3" style="margin-top: 25px;">
        <div class="card-header text-center">Edit User</div>
        <form class="card-body" method="POST" id="edit_form" action="<?=base_url('CRUD/update/'.$user['id'])?>">
            <div class="form-group row">
                <label for="staticEmail" class="col-sm-2 col-form-label">User Name</label>
                <div class="col-sm-10">
                    <input type="text" id="name" name="name" class="form-control" value="<?= $user['name']?>">
                </div>
            </div>
            <div class="form-group row">
                <label for="staticEmail" class="col-sm-2 col-form-label">Email Address</label>
                <div class="col-sm-10">
                    <input type="text" id="email" name="email" class="form-control" value="<?= $user['email']?>">
                </div>
            </div>
            <div class="form-group row">
                <label for="staticEmail" class="col-sm-2 col-form-label">Password</label>
                <div class="col-sm-10">
                    <input type="password" id="password" name="password" class="form-control" value="" placeholder="Enter a new password">
                </div>
            </div>
            <div class="form-group row mt-2">
                <label for="staticEmail" class="col-sm-2 col-form-label">Created DateTime</label>
                <div class="col-sm-10">
                <input type="text" readonly style="color: gray;" class="form-control" value="<?= $user['created_date']?>">
                </div>
            </div>
        </form>
    </div>
    <div class="text-end mt-2">
        <a href="<?=base_url('CRUD/index')?>" class="btn btn-secondary text-white">Back</a>
        <button type="submit" form="edit_form" class="px-5 btn btn-primary text-white">Submit</button>
    </div>
</div>
</body>
</html>