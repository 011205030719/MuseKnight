<?php

class Salary extends MY_Controller {

    // Predefine function in controller
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('tuition');
        $this->data['folder_name'] = 'teacher';
        $this->load->model("Sales_model");
        $this->load->model("Salary_model");
        $this->load->model("StudentSubject_model");
        $this->load->model("TeacherSubject_model");
        $this->load->model("Teacher_model");
        $this->load->model("Student_model");
        $this->load->model("Subject_model");
        $this->auth_validate();
    }
    

    public function index() {
        $teacher_id = $this->session->userdata('user_id'); // Replace with your actual session key

    // Fetch salary records for the logged-in teacher
    $this->data['salarys'] = $this->Salary_model->get_where(array('teacher_id' => $teacher_id, 'is_deleted' => 0));
        // Fetch all students
        $this->data['students'] = $this->Student_model->get_where(array('is_deleted' => 0));
        $this->data['salarys'] = $this->Salary_model->get_where(array('is_deleted' => 0));
        $this->data['teachers'] = $this->Teacher_model->get_where(array('is_deleted' => 0));
    
        // Fetch all subjects
        $this->data['subjects'] = $this->Subject_model->get_where(array('is_deleted' => 0));
    
        // Fetch all student_subjects
        $this->data['student_subjects'] = $this->StudentSubject_model->get_where(array('is_deleted' => 0));
        $this->data['teacher_subjects'] = $this->TeacherSubject_model->get_where(array('is_deleted' => 0));
    
        // Additional data fetching if needed
        $this->data['sales'] = $this->Sales_model->get_where(array('is_deleted' => 0));
        $this->data['salarys'] = $this->Salary_model->get_where(array('is_deleted' => 0));
        $this->data['teacher_id'] = $teacher_id;
        // Load the view
        $this->load->view("teacher/salary/list", $this->data);
    }    
    
    
    public function store() {
        if ($this->input->post()) {
            $student_id = $this->input->post('student_id');
            $teacher_id = $this->input->post('teacher_id');
            $subject_id = $this->input->post('subject_id');
            $student_subject_id = $this->input->post('student_subject_id');
            $teacher_subject_id = $this->input->post('teacher_subject_id');
    
            // Retrieve the teacher_subject record from the database
        $teacher_subject = $this->TeacherSubject_model->getOne(array('id' => $teacher_subject_id, 'is_deleted' => 0));

        if (!$teacher_subject) {
            redirect(base_url('teacher/payment/invoice?error=teacher_subject_not_found'));
            return;
        }

        $subject_id = $teacher_subject['subject_id'];

        // Retrieve the subject name from the "subject" table based on the subject_id
        $subject = $this->Subject_model->getOne(array('id' => $subject_id, 'is_deleted' => 0));

        if (!$subject) {
            redirect(base_url('teacher/payment/invoice?error=subject_not_found'));
            return;
        }

        $subject_name = $subject['title'];
    
            $total_amount = $this->input->post('total_amount');
    
            // Store data in student_subject table
            $salary_data = array(
                'teacher_id' => $teacher_id,
                'teacher_subject_id' => $teacher_subject_id,
                'subject_id' => $subject_id,
            );
    
            $salary_id = $this->Salary_model->insert($salary_data);
    
            // Retrieve the subject_id from the student_subject record
            $teacher_id = $this->Salary_model->getOne(array('id' => $salary_id, 'is_deleted' => 0))['teacher_id'];
            // Store data in salary table
            $salarys_data = array(
                'teacher_id' => $teacher_id,
                'commmission_rate' => $commmission_rate, // Use the correct subject_id from the student_subject record
                'total_amount' => $total_amount, // Use the correct subject_id from the student_subject record
                'month' => '', // Add handling as required
            );
    
            $this->Salary_model->insert($salarys_data);
    
            redirect(base_url('teacher/salary/list')); // Redirect to the lesson list page
        }
    }

    public function edit($id) {
        $this->data['salary'] = $this->Salary_model->getOne(array('id' => $id, 'is_deleted' => 0));

        // Fetch the student_subject data for the specific student
        $this->data['teacher_subject'] = $this->TeacherSubject_model->get_where(array('student_id' => $id));

        // Retrieve all subjects
        $this->data['subjects'] = $this->Subject_model->get_where(array('is_deleted' => 0));
        $this->data['salarys'] = $this->Salary_model->get_where(array('is_deleted' => 0));
        $this->data['teachers'] = $this->Teacher_model->get_where(array('is_deleted' => 0));
        $this->data['teacher_subjects'] = $this->TeacherSubject_model->get_where(array('is_deleted' => 0));
        
        $this->load->view("teacher/student/edit", $this->data);
    }

    // public function SubmitPayment() {
    //     $user_id = $this->session->userdata('user_id');
    //     // Upload Image
    //     $config['upload_path'] = FCPATH. 'assets/img/payment_invoice/';
    //     $config['allowed_types'] = 'jpg|jpeg|png';
    //     $config['max_size'] = 2048;
    //     $this->load->library('upload', $config);
    
    //     if ($this->upload->do_upload('receipt')) {
    //         $data = $this->upload->data();
    //         $receipt_name = $data['file_name'];
    
    //         $sql = array(
    //             'receipt_date' => date("Y-m-d H:i:s"),
    //             'status' => 2, // Pending
    //             'receipt' => $receipt_name,
    //             'modified_date' => date("Y-m-d H:i:s")
    //         );
    
    //         // Insert the data into the teacher_salary table
    //         $this->Salary_model->insert($sql);
    
    //         // Redirect to the appropriate page
    //         redirect(base_url('admin/salary/list'));
    //     } else {
    //         $error = array('error' => $this->upload->display_errors());
    //         var_dump($error);
    //         throw new Exception("Error!");
    //     }
    // }

    public function SubmitPayment() {
        $user_id = $this->session->userdata('user_id');
        // Upload Image
        $config['upload_path'] = FCPATH. 'assets/img/payment_invoice/';
        $config['allowed_types'] = 'jpg|jpeg|png';
        $config['max_size'] = 2048;
        $this->load->library('upload', $config);
    
        if ($this->upload->do_upload('receipt')) {
            $data = $this->upload->data();
            $receipt_name = $data['file_name'];
    
            $teacher_id = $this->input->post('teacher_id'); // Get the teacher_id from the form
            $status = 1; // Assuming the status should be set to 'Pending'
    
            // Check if a record with the same teacher_id already exists in the 'salary' table
            $existingSalary = $this->Salary_model->getOne(array('teacher_id' => $teacher_id));
    
            if ($existingSalary) {
                // Update the existing record
                $sql = array(
                    'receipt_date' => date("Y-m-d H:i:s"),
                    'status' => $status,
                    'receipt' => $receipt_name,
                    'modified_date' => date("Y-m-d H:i:s")
                );
    
                $this->Salary_model->update(array('id' => $existingSalary['id']), $sql);
            } else {
                // Insert a new record
                $sql = array(
                    'teacher_id' => $teacher_id,
                    'receipt_date' => date("Y-m-d H:i:s"),
                    'status' => $status,
                    'receipt' => $receipt_name,
                    'modified_date' => date("Y-m-d H:i:s")
                );
    
                $this->Salary_model->insert($sql);
            }
    
            // Redirect to the appropriate page
            redirect(base_url('teacher/salary/list'));
        } else {
            $error = array('error' => $this->upload->display_errors());
            var_dump($error);
            throw new Exception("Error!");
        }
    }  
    
    public function update($id){
        if ($this->input->post()) {
            $sql = array(
                'name' => $this->input->post('name'),
                'password' => $this->input->post('password'),
                'gender' => $this->input->post('gender'),
                'email' => $this->input->post('email'),
                'mobile' => $this->input->post('mobile'),
                'status' => $this->input->post('status'),
                'modified_date' => date('Y-m-d H:i:s'),
            );

            $this->Student_model->update(array('id'=>$id), $sql);

            redirect(base_url('teacher/student/list')); // calling route
            
        }
    }
    public function invoice($id, $is_print = false) {
        $this->data['salary'] = $this->Salary_model->getOne(array('id' => $id, 'is_deleted' => 0));
        $this->data['subjects'] = json_decode($this->data['salary']['subject_student'],true);
        $this->data['teacher'] = $this->Teacher_model->getOne(array('id' => $this->data['salary']['teacher_id'], 'is_deleted' => 0));
        $this->data['subject_title'] = $this->Subject_model->getIDKeyArray();
        $this->data['is_print'] = $is_print;

         // Fetch student names based on student_id
         foreach ($this->data['subjects'] as &$subject) {
            $student_id = $subject['student_id'];
            $student = $this->Student_model->getOne(array('id' => $student_id, 'is_deleted' => 0));
            $subject['student_name'] = $student['name'];
        }
        $this->load->view("teacher/salary/invoice", $this->data);
    } 
 
    
    
    
    public function updateStatus($id) {
        $this->data['sale'] = $this->Sales_model->update(array('id' => $id, 'is_deleted' => 0),array('status'=>1));
        redirect(base_url('admin/salary/invoice/'.$id)); // calling route
    }
    
    public function calculateTotalTuition() {
        $user_id = $this->session->userdata('user_id');
        $sales = $this->Sales_model->getSalesForStudent($user_id);
        return calculateTotalTuition($sales);
    }
    
    
    
}
