<?php

class Profile extends MY_Controller {

    // Predefine function in controller
	public function __construct()
	{
        parent::__construct();
        // $this->data['invalid'] = 0;
        $this->data['folder_name'] = 'admin';
        $this->load->model("Admin_model");
        $this->load->model("Subject_model"); 
        $this->auth_validate();
	}

    public function index(){
        $this->data['admins'] = $this->Admin_model->get_where(array('is_deleted'=>0));
        $this->load->view("admin/profile/list",$this->data);
    }

    public function store()
{
    if ($this->input->post()) {
        // add student serial id
        $serials = $this->Student_model->getIDKeyArray('serial');
        if ($serials) {
            $largestNumber = 0;
            foreach ($serials as $str) {
                $matches = [];
                if (preg_match('/(\d+)/', $str, $matches)) {
                    $number = intval($matches[0]);
                    if ($number > $largestNumber) {
                        $largestNumber = $number;
                    }
                }
            }
            $serial = 'AD' . str_pad(($largestNumber + 1), 5, '0', STR_PAD_LEFT);
        }

        // store data
        $sql = array(
            'serial' => $serial,
            'name' => $this->input->post('name'),
            'password' => $this->input->post('password'),
            'email' => $this->input->post('email'),
            'mobile' => $this->input->post('mobile'),
            'status' => $this->input->post('status'),
        );

        $this->Student_model->insert($sql);
        redirect(base_url('admin/profile/list')); // calling route
    }
}


    public function edit($id){
        $this->data['admins'] = $this->Admin_model->getOne(array('id'=>$id,'is_deleted'=>0));
        $this->load->view("admin/profile/edit",$this->data);
    }

    public function update_password($id){
        if ($this->input->is_ajax_request()) {
            $new_password = $this->input->post('new_password');
    
            // Check password format
            if (!$this->isValidPasswordFormat($new_password)) {
                // Password format is incorrect, send an error response
                echo json_encode(array('status' => 'error', 'message' => 'Incorrect password format.'));
                return;
            }
    
            // Update the password in the database
            $sql = array(
                'password' => $new_password,
                'modified_date' => date('Y-m-d H:i:s'),
            );
    
            $this->Student_model->update(array('id'=>$id), $sql);
    
            // Send a success response
            echo json_encode(array('status' => 'success', 'message' => 'Password updated successfully.'));
        } else {
            // Non-AJAX request, handle accordingly
            show_404(); // or redirect, or display an error page
        }
    }
    
    private function isValidPasswordFormat($password) {
        // Implement your password format validation logic here
        // For example, check length, presence of letters and numbers, etc.
        return strlen($password) >= 8 && preg_match('/[a-zA-Z]/', $password) && preg_match('/\d/', $password);
    }
    
    
    
    public function delete($id){
        // $this->User_model->delete(array('id'=>$id)); //delete database data
        $this->Admin_model->update(array('id'=>$id), array('is_deleted'=>1));
        redirect(base_url('admin/profile/list')); // calling route
    }
}
