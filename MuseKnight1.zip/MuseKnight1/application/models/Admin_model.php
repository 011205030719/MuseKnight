<?php
class Admin_model extends MY_Model {
    public function __construct(){
        $this->set_table('admin');
    }
}
?>