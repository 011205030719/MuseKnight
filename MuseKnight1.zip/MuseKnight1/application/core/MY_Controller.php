<?php

class MY_Controller extends CI_Controller
{
    public $data = array();

    public function __construct()
	{
        parent::__construct();
        $this->load->model('Admin_model');
        $this->load->model('Student_model');
        $this->load->model('Teacher_model');
        $this->load->model('Subject_model');
	}
    public function auth_validate(){
        $auth_validate = $this->session->userdata('is_login');
        if($auth_validate !== true){
            redirect(base_url('login'));
        }else{
            $this->data['module'] = $this->session->userdata('module');
            $auth_id = $this->session->userdata('user_id');
            $this->data['userdata'] = $this->{$this->data['module'].'_model'}->getOne(array('id' => $auth_id,'is_deleted' => 0));
        }
    }
    public function reset_password($id){
        $this->data['student'] = $this->Student_model->getOne(array('id'=>$id,'is_deleted'=>0));
        $this->data['teacher'] = $this->Teacher_model->getOne(array('id'=>$id,'is_deleted'=>0));
        $this->data['admin'] = $this->Teacher_model->getOne(array('id'=>$id,'is_deleted'=>0));
        $this->load->view("student/profile/reset_password",$this->data);
        $this->load->view("teacher/profile/reset_password",$this->data);
        $this->load->view("admin/profile/reset_password",$this->data);
    }

    
    
}