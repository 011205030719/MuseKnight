<?php $this->load->view("admin/nav"); ?>
<?php $this->load->view("layouts/header"); ?>

<style>

</style>

<div class="container   " style="padding-left:20%;">
    <div class="header" style=" width:100%;">
        <div style="position: sticky; top: 0; z-index: 1000; background-color:#E6E6FA; border: 0px solid rgba(100, 100, 100, 1); border-radius: 12px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); padding: 10px; margin: 1%;">
            <span>Home / </span>
            <a href="<?= base_url($folder_name.'/annoucement/subjectList') ?>" style="text-decoration:none; color:black;">Subject List / </a>
            <a href="<?= base_url($folder_name.'/annoucement/list')?>" style="text-decoration:none; color:black;"><?= $subject ['title']?></a>
            <span>/ Announcement</span>
        </div>
    </div>

        <div class="container">
            <div class="card mt-5">
                <div class="card-header bg-body-tertiary">
                    <a class="navbar-brand" href="<?= base_url($folder_name . '/annoucement/list') ?>">
                        Add New Announcement
                    </a>
                </div>
                <!-- <div class="card bg-dark text-white"style="width:87%;">
                <img class="card-img" src="<?= base_url('assets/img/piano_sub.jpg') ?>" alt="Card image" style="height: 380px; width: 100%;">
                    <div class="card-img-overlay">
                        <h5 class="card-title-p">Piano Annoucement</h5>
                    </div>
                </div> -->

                <div class="card-body">
                    <form action="<?= base_url('admin/annoucement/addAnnoucement') ?>" method="post">
                        <div class="mb-3">
                            
                        <input type="hidden" name="sender_id" value="<?php echo isset($userdata['user_id']) ? $userdata['user_id'] : ''; ?>">

                            <input type="hidden" name="sender_type" value="<?php echo $sender_type; ?>">
                        </div>
                        <!-- Inside your form -->
                        <div class="mb-3">
                            <label for="subject" class="form-label">Subject</label>
                            <input type="hidden" name="subject_id" value="<?= $subject_id ?>">
                            <input readonly type="text" id="subject" class="form-control bg-light" name="subject_title" value="<?= $subject['title'] ?>">
                        </div>

                        <div class="mb-3">
                            <label for="title" class="form-label">Title</label>
                            <input required type="text" class="form-control" id="title" name="title">
                        </div>

                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea required class="form-control" id="description" name="description" rows="4"></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="select_all" class="form-label">Select All </label>
                            <input required class="form-check-input" type="checkbox" id="select_all" name="select_all">
                        </div>

                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>


                </div>
            </div>
        </div>
</div>