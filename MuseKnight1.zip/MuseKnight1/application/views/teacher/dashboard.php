<?php $this->load->view("teacher/nav"); ?>
<?php $this->load->view("layouts/header"); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
      .custom-module{
        margin-top: -10px; 
        margin-bottom: 20px; 
        background-color: #703be7; 
        height: 40px; 
        width: 350px; 
        display: flex; 
        justify-content: center; 
        align-items: center; 
        position: relative; 
        border-radius: 25px; 
        color: #fff; 
        text-align: left;
        font-size: 18px;
    }

    .custom-module:hover{
        background-color: #422387; 
    }

    .custom-hover:hover{
        background: linear-gradient(135deg, rgb(206, 159, 252) 10%, rgb(115, 103, 240) 100%);
        color: #fff;
        transform: translateY(-15px); /* Move the column up by 5 pixels on hover */
      transition: transform 0.3s ease;
    }
    .element {
    border: 0px solid rgba(100, 100, 100, 1);
    border-radius: 12px;
    color: rgba(255, 255, 255, 0.5);
  }
    .status {
        color: white;
        font-size: 12px;
        font-weight: 600;
        padding-top: 3px;
        padding-bottom: 5px;
        padding-left: 10px;
        padding-right: 10px;
        border-radius: 10px;
    }
    
</style>

          <div class="dashboard" style="padding-left:20%;">
            <div class="container-fluid">
              <div class="card-header">
                <div style="position: sticky; top: 0; z-index: 1000; background-color:#E6E6FA; border: 0px solid rgba(100, 100, 100, 1); border-radius: 12px; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); padding: 10px; margin: 1%;">
                  <span style="color:gray;">Home / </span>
                  <a href="<?= base_url($folder_name.'/annoucement') ?>" style="text-decoration:none; color:black;">Dashboard</a>
                </div>
                <div class="card">
                  <div class="card-body element" style="background-color: rgba(6, 47, 209, 0.05);">
                    <div class="row">
                      <div class="col-md-8">
                        <h1 style="color: black; font-family:Lucida Handwriting, cursive; margin-top:6%; ">Hi  <?= $userdata['name'] ?></h1>
                        <h3 style="color: black; font-family:URW Chancery L, cursive; margin-top:3%; ">Embark on a Musical Odyssey with MuseKnight</h3>
                        <p style="color: black; font-size:medium; font-style:italic; margin-top: 5%;" >Unleash the power of our web-based management system, dedicated to enriching your musical journey at MuseKnight. Streamlined for both new and returning students, it's your gateway to a seamless learning experience.</p>
                      </div>
                      <div class="col-md-4">
                        <img src="<?= base_url('assets/img/first.png') ?>" class="img-fluid" alt="Image">
                      </div>
                    </div>
                  </div>
                </div>

                <!-- <div class="row">
                  <div class="col-4" style="padding: 20px; margin:auto;">
                    <div class="card shadow custom-hover" style="padding: 20px;">
                      <div class="card-item">
                        <div>
                          <div>0</div>
                          <div>Salarys</div>
                        </div>
                        <div><i class="bi bi-person-badge-fill" style="font-size: 30px;"></i></div>
                      </div>
                    </div>
                  </div>
                  <div class="col-4" style="padding: 20px;margin:auto;">
                    <div class="card shadow custom-hover" style="padding: 20px;">
                      <div class="card-item">
                        <div>
                          <div>0</div>
                          <div>Total Teacher</div>
                        </div>
                        <div><i class="bi bi-person" style="font-size: 30px;"></i></div>
                      </div>
                    </div>
                  </div>
                  <div class="col-4" style="padding: 20px;margin:auto;">
                    <div class="card shadow custom-hover" style="padding: 20px;">
                      <div class="card-item">
                        <div>
                          <div>0</div>
                          <div>Sales</div>
                        </div>
                        <div><i class="bi bi-cash-coin" style="font-size: 30px;"></i></div>
                      </div>
                    </div>
                  </div>
                </div> -->

                <!-- <div class="container">
                  <div style="width: 80%; margin: auto;">
                    <canvas id="myBarChart"></canvas>
                  </div>
                </div> -->
                  <!----------------------------------------------------------posted announcement---------------------------------------------------------->
                  <div class="row">
                    <div class="col-8" style="padding: 10px;">
                      <div class="card shadow">
                        <div class="card-list" style="padding: 20px;">
                          <div class="card-header">
                            <div class="d-flex justify-content-between">
                              <div style="font-weight: 700; font-size: 20px">Announcement</div>
                                <a href="<?= base_url('teacher/annoucement/subjectList')?>" class="btn btn-primary text-light btn-sm">More Details</a>
                            </div>
                          </div>
                          <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade show active" id="annoucment" role="tabpanel" aria-labelledby="annoucment-tab">
                              <?php if($latest_announcements) {
                                foreach ($latest_announcements as $subjectId => $announcements) {
                                  foreach ($announcements as $announcement) { ?>
                                    <div class="card announcement-card" style="border-radius: 5px; position: relative; margin-top:1%;">
                                      <div class="card-body">
                                        <div style="display:flex; justify-content:start; align-items:center;">
                                          <div style="width: 50px; height: 50px; border-radius: 50%; background-color: #3498db; text-align: center; line-height: 50px; color: #fff; font-size:10px;"><?= $announcement['sender_type'] ?></div>
                                          <div style="margin-left:10px;">
                                            <div style="font-size:15px; font-weight:600;"><?= $announcement['senderName'] ?></div>
                                            <div style="font-size:12px;"><?= date('M d, Y (h:i a)', strtotime($announcement['created_date'])) ?></div>
                                          </div>
                                        </div>
                                        <br>
                                        <h5 class="card-title"><?= $announcement['title'] ?></h5>
                                        <p class="card-text"><?= $announcement['description'] ?></p>

                                        <!-- Display Subject Title in the upper right -->
                                        <div style="position: absolute; top: 0; right: 0; padding: 20px;">
                                          <?php if (isset($announcement['subject_title'])) { ?>
                                            <span style="background-color: #7B68EE; color: #fff; font-weight:bold ; padding: 3px 5px; border-radius: 10px; font-size:12px;">
                                              <?= $announcement['subject_title'] ?>
                                            </span>
                                          <?php } ?>
                                        </div>
                                      </div>
                                    </div>
                                  <?php }
                                }
                              } else { ?>
                              <div style="width:100%; text-align:center; padding:20px;">There is no announcement posted on this subject.</div>
                              <?php } ?>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-4" style="padding: 10px;">
                      <div class="card shadow">
                        <div class="card-list" style="padding: 20px;">
                          <div class="card-header">
                            <div class="d-flex justify-content-between">
                              <div style="font-weight: 700; font-size: 20px">Salary List</div>
                                <a href="<?= base_url('teacher/salary/list')?>" class="btn btn-primary text-light btn-sm">More Details</a>
                            </div>
                             <!-- Display Sales Information -->
                          <?php
                            $teacherId = $this->session->userdata('user_id');

                            // Get the current month
                            $currentMonth = date('F');

                            foreach ($current_month_salary as $key => $salary) {
                                echo '<div class="mt-3">';
                                echo '<p>Month: ' . $salary['month'] . '</p>';
                                echo '<p>Subject: ';

                                // Fetch all teacher subjects associated with the teacher for the current month
                                $teacherSubjects = $this->TeacherSubject_model->get_where(array('teacher_id' => $teacherId, 'is_deleted' => 0));

                                if ($teacherSubjects) {
                                    $totalFee = 0; // Initialize the total fee for this teacher salary

                                    foreach ($teacherSubjects as $teacherSubject) {
                                        // Fetch subject title from the 'subject' table using the subject ID
                                        $subject_info = $this->Subject_model->getOne(array('id' => $teacherSubject['subject_id'], 'is_deleted' => 0));
                                        $subject_title = $subject_info ? $subject_info['title'] : 'Unknown Subject';

                                        echo $subject_title . ', ';

                                        // Fetch all student subjects associated with the teacher subject (no need for month filter)
                                        $studentSubjects = $this->StudentSubject_model->get_where(array('teacher_id' => $teacherId, 'subject_id' => $teacherSubject['subject_id'], 'is_deleted' => 0));

                                        foreach ($studentSubjects as $subject) {
                                            // Accumulate the total fee for this teacher salary
                                            $totalFee += $subject['fee'];
                                        }
                                    }

                                    // Calculate the total amount by multiplying the total fee with the commission rate
                                    $totalAmount = $totalFee * $salary['commission_rate'];
                                } else {
                                    echo 'Unknown Subject';
                                    $totalAmount = 0; // If no subject, set total amount to 0
                                }

                                echo '</p>';
                                echo '<p>Total Amount: RM ' . number_format($totalAmount, 2) . '</p>';
                                echo '<p>Status: ';
                                echo '<span style="background-color: ' . ($salary['status'] == 0 ? 'red' : 'green') . '; padding: ' . ($salary['status'] == 1 ? '5px' : '5px') . '; border-radius: ' . ($salary['status'] == 2 ? '5px;' : '5px') . '; color:#fff;">';
                                echo $salary['status'] == 0 ? 'Unpaid' : 'Paid';
                                echo '</span>';
                                echo '</p>';
                                echo '</div>';
                            }
                        ?>
                          </div>
                         


                        </div>
                      </div>
                    </div>
                  </div>
              </div>
            </div>
          </div>


    <script src="script.js"></script>

    <script>
    const labels = ["January", "February", "March", "April", "May", "June", "July"];
    const data = {
      labels: labels,
      datasets: [{
        label: 'My First Dataset',
        data: [65, 59, 80, 81, 56, 55, 40],
        backgroundColor: [
          'rgba(255, 99, 132, 0.2)',
          'rgba(255, 159, 64, 0.2)',
          'rgba(255, 205, 86, 0.2)',
          'rgba(75, 192, 192, 0.2)',
          'rgba(54, 162, 235, 0.2)',
          'rgba(153, 102, 255, 0.2)',
          'rgba(201, 203, 207, 0.2)'
        ],
        borderColor: [
          'rgb(255, 99, 132)',
          'rgb(255, 159, 64)',
          'rgb(255, 205, 86)',
          'rgb(75, 192, 192)',
          'rgb(54, 162, 235)',
          'rgb(153, 102, 255)',
          'rgb(201, 203, 207)'
        ],
        borderWidth: 1
      }]
    };

    const config = {
      type: 'bar',
      data: data,
      options: {
        scales: {
          y: {
            beginAtZero: true
          }
        }
      },
    };

    // Get the canvas element and initialize the chart
    const ctx = document.getElementById('myBarChart').getContext('2d');
    const myBarChart = new Chart(ctx, config);
  </script>