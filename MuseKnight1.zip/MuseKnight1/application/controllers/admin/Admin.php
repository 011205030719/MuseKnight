<?php

class Admin extends MY_Controller {

    // Predefine function in controller
	public function __construct()
	{
        parent::__construct();
        // $this->data['invalid'] = 0;
        $this->data['folder_name'] = 'admin';
        $this->load->model("Admin_model");
        $this->auth_validate();
	}

    public function index(){
        $this->data['admins'] = $this->Admin_model->get_where(array('is_deleted'=>0));
        $this->load->view("admin/admin/list",$this->data);
    }

    public function store(){
        if ($this->input->post()) {
            
            // add Admin serial id
            $serials = $this->Admin_model->getIDKeyArray('serial');
            if($serials){
                $largestNumber = 0;
                foreach ($serials as $str) {
                    $matches = [];
                    if (preg_match('/(\d+)/', $str, $matches)) {
                        $number = intval($matches[0]);
                        if ($number > $largestNumber) {
                            $largestNumber = $number;
                        }
                    }
                }
                $serial = 'AD' . str_pad(($largestNumber + 1), 5, '0', STR_PAD_LEFT);
            }

            // store data
            $sql = array(
                'serial' => $serial,
                'name' => $this->input->post('name'),
                'password' => $this->input->post('password'),
                'email' => $this->input->post('email'),
                'mobile' => $this->input->post('mobile'),
                'status' => $this->input->post('status'),
            );

            $this->Admin_model->insert($sql);
            redirect(base_url('admin/admin/list')); // calling route
        }
    }
    public function edit($id){
        $this->data['admin'] = $this->Admin_model->getOne(array('id'=>$id,'is_deleted'=>0));
        $this->load->view("admin/admin/edit",$this->data);
    }
    public function update($id){
        if ($this->input->post()) {
            $sql = array(
                'name' => $this->input->post('name'),
                'password' => $this->input->post('password'),
                'email' => $this->input->post('email'),
                'mobile' => $this->input->post('mobile'),
                'status' => $this->input->post('status'),
                'modified_date' => date('Y-m-d H:i:s'),
            );

            $this->Admin_model->update(array('id'=>$id), $sql);

            redirect(base_url('admin/admin/list')); // calling route
            
        }
    }
}
